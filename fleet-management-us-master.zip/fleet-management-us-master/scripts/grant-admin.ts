import { config } from "dotenv";
import { Pool } from "pg";

config({ path: ".env.local" });
config();

const email = process.argv[2]?.trim().toLowerCase();
if (!email || email.length > 320 || !email.includes("@")) {
  throw new Error("Usage: npm run admin:grant -- admin@example.com");
}

const connectionString = process.env.DATABASE_URL;
if (!connectionString) throw new Error("DATABASE_URL is required.");

const pool = new Pool({ connectionString, max: 1 });
try {
  await pool.query("begin");
  const user = await pool.query<{ id: string; email: string }>(
    "select id, email from auth.users where lower(email) = $1 limit 1",
    [email],
  );
  if (!user.rows[0]) {
    throw new Error(`No Supabase Auth user exists for ${email}. Create it first.`);
  }

  await pool.query(
    `insert into public.admin_users (user_id, email)
     values ($1, $2)
     on conflict (user_id) do update
     set email = excluded.email, active = true, updated_at = now()`,
    [user.rows[0].id, user.rows[0].email],
  );
  await pool.query("commit");
  console.log(`Admin access granted to ${user.rows[0].email}.`);
} catch (error) {
  await pool.query("rollback");
  throw error;
} finally {
  await pool.end();
}
