import assert from "node:assert/strict";
import { createHmac, randomUUID } from "node:crypto";
import { config } from "dotenv";
import { Pool } from "pg";
import { validateCarrierApplication } from "../src/lib/carrier-application.ts";

config({path:".env.local",quiet:true});config({quiet:true});
if(!process.env.DATABASE_URL)throw new Error("DATABASE_URL is required.");
const pool=new Pool({connectionString:process.env.DATABASE_URL,max:2,connectionTimeoutMillis:15000});
const token=randomUUID();
const label=`verification-${token}`;
const db=await pool.connect();
const pass=(name:string)=>console.log(`PASS: ${name}`);
try {
  await db.query("BEGIN");
  await db.query("UPDATE cms_site_settings SET tagline=$1,updated_at=now() WHERE id=1",[label]);
  await db.query("UPDATE cms_about_content SET heading=$1,enabled=false,updated_at=now() WHERE id=1",[label]);
  assert.equal((await db.query("SELECT tagline FROM cms_site_settings WHERE id=1")).rows[0].tagline,label);
  assert.deepEqual((await db.query("SELECT heading,enabled FROM cms_about_content WHERE id=1")).rows[0],{heading:label,enabled:false});
  pass("site settings and About fields persist across database queries (transaction)");
  // All CMS test records and publication changes are rolled back; never visible publicly.
  const {rows:[service]}=await db.query<{id:number;slug:string}>(`INSERT INTO cms_services (num,slug,icon,title,description,cta_href,detail,sort_order,status) VALUES ($1,$2,'fa-truck','Verification only','Verification only',$3,'{"heading":"Check","intro":"Check","sections":[]}',9999,'draft') RETURNING id,slug`,[token.slice(0,20),label,`/services/${label}`]);
  await db.query("UPDATE cms_services SET title='Changed verification', status='published' WHERE id=$1",[service.id]);
  assert.equal((await db.query("SELECT title FROM cms_services WHERE slug=$1 AND status='published' AND deleted_at IS NULL",[label])).rows[0].title,"Changed verification");
  await db.query("SAVEPOINT duplicate_check");
  await assert.rejects(db.query("UPDATE cms_services SET slug=$1 WHERE id=(SELECT id FROM cms_services WHERE id<>$2 LIMIT 1)",[label,service.id]),(error:unknown)=>(error as {code?:string}).code==="23505");
  await db.query("ROLLBACK TO SAVEPOINT duplicate_check");
  await db.query("UPDATE cms_services SET status='draft',deleted_at=now() WHERE id=$1",[service.id]);
  assert.equal((await db.query("SELECT id FROM cms_services WHERE slug=$1 AND status='published' AND deleted_at IS NULL",[label])).rowCount,0);
  pass("service persistence, publication, archive and duplicate-slug constraint (transaction)");

  const {rows:[asset]}=await db.query<{path:string}>("SELECT path FROM cms_media_assets WHERE deleted_at IS NULL LIMIT 1");
  assert.ok(asset);
  const {rows:[truck]}=await db.query<{id:number}>(`INSERT INTO cms_truck_types (num,slug,icon,name,spec,image,intro,best_for,common_freight,equipment_notes,sort_order,status) VALUES ($1,$2,'fa-truck','Verification','Test',$3,'Test','Test','[]','Test',9999,'draft') RETURNING id`,[token.slice(0,20),label,asset.path]);
  await db.query("UPDATE cms_truck_types SET status='published',image=$2 WHERE id=$1",[truck.id,asset.path]);
  assert.equal((await db.query("SELECT image FROM cms_truck_types WHERE id=$1 AND status='published'",[truck.id])).rows[0].image,asset.path);
  await db.query("UPDATE cms_truck_types SET status='draft',deleted_at=now() WHERE id=$1",[truck.id]);
  await db.query("UPDATE cms_hero_content SET images=jsonb_build_array($1::text) WHERE id=1",[asset.path]);
  assert.deepEqual((await db.query("SELECT images FROM cms_hero_content WHERE id=1")).rows[0].images,[asset.path]);
  pass("truck CRUD and hero media selection persist across queries (transaction)");

  const {rows:[review]}=await db.query<{id:number;status:string}>("INSERT INTO cms_testimonials (name,quote,role,initials,sort_order,internal_notes) VALUES ($1,'Verification only; never published outside this transaction','Test','VT',9999,'PRIVATE VERIFICATION NOTE') RETURNING id,status",[label]);
  assert.equal(review.status,"pending");
  for(const status of ["published","pending","rejected","archived"]){
    await db.query("UPDATE cms_testimonials SET status=$2 WHERE id=$1",[review.id,status]);
    assert.equal((await db.query("SELECT id FROM cms_testimonials WHERE id=$1 AND status='published' AND deleted_at IS NULL",[review.id])).rowCount,status==="published"?1:0);
  }
  await db.query("SAVEPOINT rating_check");
  await assert.rejects(db.query("UPDATE cms_testimonials SET rating=6 WHERE id=$1",[review.id]),(error:unknown)=>(error as {code?:string}).code==="23514");
  await db.query("ROLLBACK TO SAVEPOINT rating_check");
  pass("pending review default, moderation visibility, rating constraint (transaction)");

  const application=validateCarrierApplication({fullName:label,phone:"5551234567",email:`${token}@example.invalid`,truckType:"Dry Van",zip:"60607"},new Set(["Dry Van"]));
  assert.ok(application.ok);
  const {rows:[lead]}=await db.query<{id:number}>("INSERT INTO carrier_applications (full_name,phone,email,truck_type,current_zip) VALUES ($1,$2,$3,$4,$5) RETURNING id",[application.data.fullName,application.data.phone,application.data.email,application.data.truckType,application.data.currentZip]);
  for(const status of ["contacted","qualified","onboarding","closed","rejected"]){
    await db.query("UPDATE carrier_applications SET status=$2,internal_notes='private' WHERE id=$1",[lead.id,status]);
    assert.equal((await db.query("SELECT status FROM carrier_applications WHERE id=$1",[lead.id])).rows[0].status,status);
  }
  await db.query("UPDATE carrier_applications SET deleted_at=now() WHERE id=$1",[lead.id]);
  assert.equal((await db.query("SELECT id FROM carrier_applications WHERE id=$1 AND deleted_at IS NULL",[lead.id])).rowCount,0);
  await db.query("INSERT INTO admin_audit_records(action,entity_type,entity_id,summary,actor) VALUES ('verification','carrier_application',$1,'Verification only','verification')",[String(lead.id)]);
  assert.equal((await db.query("SELECT id FROM admin_audit_records WHERE entity_id=$1 AND action='verification'",[String(lead.id)])).rowCount,1);
  pass("lead statuses, notes, archive and audit persistence (transaction)");

  const {rows:security}=await db.query<{relname:string;relrowsecurity:boolean;can_read:boolean}>(`SELECT c.relname,c.relrowsecurity,has_table_privilege('anon',c.oid,'SELECT') OR has_table_privilege('authenticated',c.oid,'SELECT') AS can_read FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind='r' AND (c.relname LIKE 'cms_%' OR c.relname IN ('carrier_applications','admin_users','admin_audit_records','public_rate_limits'))`);
  assert.equal(security.length,26);
  assert.ok(security.every(row=>row.relrowsecurity&&!row.can_read));
  pass("all 26 CMS/private tables deny browser-role reads and enable RLS");
  await db.query("ROLLBACK");
  assert.equal((await db.query("SELECT id FROM cms_services WHERE slug=$1",[label])).rowCount,0);
  pass("verification CMS records rolled back; no test testimonials published");

  const base=process.env.VERIFY_BASE_URL;
  if(base){
    const {rows:[serviceRoute]}=await db.query<{slug:string}>("SELECT slug FROM cms_services WHERE status='published' AND deleted_at IS NULL LIMIT 1");
    const {rows:[truckRoute]}=await db.query<{slug:string;name:string}>("SELECT slug,name FROM cms_truck_types WHERE status='published' AND deleted_at IS NULL LIMIT 1");
    for(const path of ["/","/blogs",`/services/${serviceRoute.slug}`,`/truck-types/${truckRoute.slug}`]){
      const response:Response=await fetch(new URL(path,base));assert.equal(response.status,200,path);const html=await response.text();assert.ok(!html.includes("PRIVATE VERIFICATION NOTE"));
    }
    pass("production homepage and published service/truck HTTP routes render");
    for(const path of [`/services/${label}`,`/truck-types/${label}`])assert.equal((await fetch(new URL(path,base))).status,404);
    const admin=await fetch(new URL("/admin",base),{redirect:"manual"});
    assert.ok([303,307,308].includes(admin.status));assert.ok(admin.headers.get("location")?.includes("/admin/login"));
    pass("unknown slugs return 404; unauthenticated admin access redirects to login");
    const html=(path:string)=>fetch(new URL(path,base),{cache:"no-store",signal:AbortSignal.timeout(15000)}).then(response=>response.text());
    let serviceId:number|undefined;let reviewId:number|undefined;
    try{
      serviceId=(await db.query<{id:number}>(`INSERT INTO cms_services(num,slug,icon,title,description,cta_href,detail,sort_order,status,created_by,updated_by) VALUES($1,$2,'fa-truck','HTTP service','HTTP service',$3,$4,9999,'published','verification','verification') RETURNING id`,[token.slice(0,20),label,`/services/${label}`,JSON.stringify({heading:"HTTP service detail",intro:"HTTP intro",sections:[]})])).rows[0].id;
      assert.ok((await html("/")).includes("HTTP service"),"published service card missing");assert.ok((await html(`/services/${label}`)).includes("HTTP SERVICE DETAIL"),"published service detail missing");
      await db.query("UPDATE cms_services SET title='HTTP service edited',detail=$2,updated_at=now() WHERE id=$1",[serviceId,JSON.stringify({heading:"HTTP detail edited",intro:"HTTP intro",sections:[]})]);
      assert.ok((await html("/")).includes("HTTP service edited"),"edited service card missing");assert.ok((await html(`/services/${label}`)).includes("HTTP DETAIL EDITED"),"edited service detail missing");
      await db.query("UPDATE cms_services SET status='draft' WHERE id=$1",[serviceId]);assert.equal((await fetch(new URL(`/services/${label}`,base))).status,404);
      reviewId=(await db.query<{id:number}>("INSERT INTO cms_testimonials(name,quote,role,initials,sort_order,status,created_by,updated_by) VALUES($1,$2,'Carrier','VT',9999,'published','verification','verification') RETURNING id",[label,`HTTP review ${token}`])).rows[0].id;
      assert.ok((await html("/")).includes(`HTTP review ${token}`),"published review missing");await db.query("UPDATE cms_testimonials SET quote=$2,updated_at=now() WHERE id=$1",[reviewId,`HTTP review edited ${token}`]);assert.ok((await html("/")).includes(`HTTP review edited ${token}`),"edited review missing");
      await db.query("UPDATE cms_testimonials SET status='pending' WHERE id=$1",[reviewId]);assert.equal((await html("/")).includes(`HTTP review edited ${token}`),false);
      pass("committed service and review publication/edit/unpublish changes reached public HTTP pages");
    }finally{
      if(reviewId)await db.query("DELETE FROM cms_testimonials WHERE id=$1 AND created_by='verification'",[reviewId]);if(serviceId)await db.query("DELETE FROM cms_services WHERE id=$1 AND created_by='verification'",[serviceId]);
    }
    const post=(data:unknown)=>fetch(new URL("/api/carrier-applications",base),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
    assert.equal((await post({fullName:""})).status,400);
    // One tagged, non-public test lead proves a committed write via the actual HTTP backend.
    const testEmail=`${token}@example.invalid`;
    const secret=process.env.RATE_LIMIT_SECRET||process.env.DATABASE_URL!;
    const sourceHash=createHmac("sha256",secret).update("shared").digest("hex");
    const emailHash=createHmac("sha256",secret).update(testEmail.toLowerCase()).digest("hex");
    const priorLimits=(await db.query("SELECT action,key_hash,window_started_at,request_count FROM public_rate_limits WHERE (action='public_source' AND key_hash=$1) OR (action='carrier_application' AND key_hash=$2)",[sourceHash,emailHash])).rows;
    try {
      const response=await post({fullName:label,phone:"5551234567",email:testEmail,truckType:truckRoute.name,zip:"60607",message:"Automated verification; this test record will be removed."});
      assert.equal(response.status,201);
      const result=await response.json() as {ok:boolean;id:number};assert.equal(result.ok,true);
      const persisted=await pool.query("SELECT id,status FROM carrier_applications WHERE id=$1 AND email=$2",[result.id,testEmail]);
      assert.equal(persisted.rowCount,1);assert.equal(persisted.rows[0].status,"new");
      pass("valid HTTP application committed and visible on independent DB connection; invalid rejected");
    } finally {
      await db.query("DELETE FROM carrier_applications WHERE email=$1 AND full_name=$2",[testEmail,label]);
      await db.query("DELETE FROM public_rate_limits WHERE (action='public_source' AND key_hash=$1) OR (action='carrier_application' AND key_hash=$2)",[sourceHash,emailHash]);
      for(const row of priorLimits)await db.query("INSERT INTO public_rate_limits(action,key_hash,window_started_at,request_count) VALUES($1,$2,$3,$4)",[row.action,row.key_hash,row.window_started_at,row.request_count]);
      pass("exact tagged HTTP test lead removed; real leads untouched");
    }
  } else console.log("SKIP: HTTP verification (set VERIFY_BASE_URL to the local production server).");
  console.log("NOT VERIFIED: authenticated browser CMS actions and Supabase uploads require configured Auth and an approved account.");
} catch(error) {
  await db.query("ROLLBACK");
  console.error(error instanceof assert.AssertionError ? error.message : "Database/HTTP verification failed; inspect configuration and connectivity.");
  process.exitCode=1;
} finally { db.release();await pool.end(); }
