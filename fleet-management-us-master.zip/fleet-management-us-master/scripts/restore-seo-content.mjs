import { config } from "dotenv";
import { readFile } from "node:fs/promises";
import { isDeepStrictEqual } from "node:util";
import pg from "pg";

config({ path: ".env.local", quiet: true });
config({ quiet: true });
const path = process.argv.find(value => value.startsWith("--backup="))?.slice(9);
if (!path) throw new Error("Provide --backup=.local/seo-content-backup-....json. Default is dry run; --apply restores content.");
const apply = process.argv.includes("--apply");
const backup = JSON.parse(await readFile(path, "utf8"));
const baseline = JSON.parse(await readFile(new URL("./seo-content-baseline.json", import.meta.url), "utf8"));
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 1, connectionTimeoutMillis: 15000 });
const client = await pool.connect();
try {
  await client.query("BEGIN");
  for (const item of backup.changes) {
    const columns = Object.keys(item.before);
    if (!baseline[item.table] || !columns.every(key => /^[a-z_][a-z0-9_]*$/.test(key) && Object.hasOwn(baseline[item.table].find(row => row.id === item.id) ?? {}, key))) throw new Error("Backup does not match the audited fields");
    const { rows } = await client.query(`SELECT ${columns.map(key => `"${key}"`).join(",")} FROM "${item.table}" WHERE id=$1 FOR UPDATE`, [item.id]);
    if (isDeepStrictEqual(rows[0], item.before)) continue;
    if (!isDeepStrictEqual(rows[0], item.after)) throw new Error(`Content changed after SEO update: ${item.table} ${item.id}. Refusing to overwrite.`);
    if (apply) {
      const values = columns.map(key => item.before[key] !== null && typeof item.before[key] === "object" ? JSON.stringify(item.before[key]) : item.before[key]);
      await client.query(`UPDATE "${item.table}" SET ${columns.map((key, i) => `"${key}"=$${i + 1}`).join(",")},updated_at=now(),updated_by='seo-aeo-rollback' WHERE id=$${columns.length + 1}`, [...values, item.id]);
    }
  }
  for (const item of backup.insertedBlogs) {
    const { rows } = await client.query("SELECT status,updated_by FROM cms_blog_posts WHERE id=$1 AND slug=$2 FOR UPDATE", [item.id, item.slug]);
    if (rows[0]?.status === "draft") continue;
    if (rows[0]?.updated_by !== "seo-aeo-2026-10") throw new Error(`Article changed after publication: ${item.slug}. Refusing to unpublish.`);
    if (apply) await client.query("UPDATE cms_blog_posts SET status='draft',updated_at=now(),updated_by='seo-aeo-rollback' WHERE id=$1", [item.id]);
  }
  await client.query(apply ? "COMMIT" : "ROLLBACK");
  console.log(`${apply ? "RESTORED" : "DRY RUN"}: ${backup.changes.length} fields/records; ${backup.insertedBlogs.length} articles would return to draft. No rows deleted.`);
} catch (error) { await client.query("ROLLBACK"); throw error; }
finally { client.release(); await pool.end(); }
