import assert from "node:assert/strict";
import { config } from "dotenv";
import { Client } from "pg";

config({ path: ".env.local" });
const client = new Client({ connectionString: process.env.DATABASE_URL });
await client.connect();
const slug = `blog-verification-${Date.now()}`;
try {
  await client.query("BEGIN");
  const inserted = await client.query<{id:number}>("INSERT INTO cms_blog_posts(title,slug,body,author,category,tags,status,reading_time,created_by,updated_by) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$9) RETURNING id", ["Draft test",slug,"# Body","Verifier","Operations",JSON.stringify(["test"]),"draft",2,"verification"]);
  const id = inserted.rows[0].id;
  assert.equal((await client.query("SELECT 1 FROM cms_blog_posts WHERE slug=$1 AND status='published'",[slug])).rowCount,0,"draft must be hidden");
  await client.query("UPDATE cms_blog_posts SET status='published',published_at=now() WHERE id=$1",[id]);
  assert.equal((await client.query("SELECT 1 FROM cms_blog_posts WHERE slug=$1 AND status='published'",[slug])).rowCount,1,"published post must be visible");
  await client.query("UPDATE cms_blog_posts SET title=$1,body=$2 WHERE id=$3",["Edited test","## Edited",id]);
  assert.deepEqual((await client.query("SELECT title,body FROM cms_blog_posts WHERE id=$1",[id])).rows[0],{title:"Edited test",body:"## Edited"});
  await client.query("SAVEPOINT duplicate_check"); let duplicateRejected=false;
  try { await client.query("INSERT INTO cms_blog_posts(title,slug,body,author,category,reading_time) VALUES($1,$2,$3,$4,$5,$6)",["Duplicate",slug,"x","Verifier","Ops",1]); }
  catch (error) { duplicateRejected=(error as {code?:string}).code==="23505"; await client.query("ROLLBACK TO SAVEPOINT duplicate_check"); }
  assert.equal(duplicateRejected,true,"duplicate slug must be rejected");
  await client.query("UPDATE cms_blog_posts SET status='archived' WHERE id=$1",[id]);
  assert.equal((await client.query("SELECT 1 FROM cms_blog_posts WHERE slug=$1 AND status='published'",[slug])).rowCount,0,"archived post must be hidden");
  await client.query("ROLLBACK");
  console.log("Blog database workflow verified.");
  const base=process.env.VERIFY_BASE_URL;
  if(base){
    const uploaded=(await client.query<{path:string}>("SELECT path FROM cms_media_assets WHERE storage_key IS NOT NULL AND deleted_at IS NULL LIMIT 1")).rows[0];assert.ok(uploaded,"a real uploaded media object is required");
    const title=`HTTP ${slug}`;let committedId:number|undefined;
    try{
      committedId=(await client.query<{id:number}>("INSERT INTO cms_blog_posts(title,slug,body,featured_image,featured_image_alt,author,category,status,reading_time,created_by,updated_by) VALUES($1,$2,$3,$4,$5,$6,$7,'draft',1,'verification','verification') RETURNING id",[title,slug,"# HTTP body",uploaded.path,"Verification image","Verifier","Operations"])).rows[0].id;
      const draftHtml=await fetch(new URL("/blogs",base),{cache:"no-store",signal:AbortSignal.timeout(15000)}).then(response=>response.text());assert.equal(draftHtml.includes(title),false,"draft leaked publicly");
      await client.query("UPDATE cms_blog_posts SET status='published',published_at=now() WHERE id=$1",[committedId]);
      const listing=await fetch(new URL("/blogs",base),{cache:"no-store",signal:AbortSignal.timeout(15000)});assert.equal(listing.status,200);assert.ok((await listing.text()).includes(title));
      const detail=await fetch(new URL(`/blogs/${slug}`,base),{cache:"no-store",signal:AbortSignal.timeout(15000)});assert.equal(detail.status,200);const html=await detail.text();assert.ok(html.includes("HTTP body"));assert.ok(html.includes(uploaded.path.replaceAll("&","&amp;"))||html.includes(uploaded.path));
      await client.query("UPDATE cms_blog_posts SET title='HTTP edited',body='## HTTP edited body',featured_image='https://example.com/external.webp',updated_at=now() WHERE id=$1",[committedId]);
      const saved=(await client.query("SELECT title,body,featured_image FROM cms_blog_posts WHERE id=$1",[committedId])).rows[0];assert.deepEqual(saved,{title:"HTTP edited",body:"## HTTP edited body",featured_image:"https://example.com/external.webp"});
      const editedHtml=await fetch(new URL(`/blogs/${slug}`,base),{cache:"no-store",signal:AbortSignal.timeout(15000)}).then(response=>response.text());assert.ok(editedHtml.includes("HTTP edited body"));assert.ok(editedHtml.includes("https://example.com/external.webp"));
      await client.query("UPDATE cms_blog_posts SET status='archived' WHERE id=$1",[committedId]);
      assert.equal((await fetch(new URL(`/blogs/${slug}`,base),{cache:"no-store",signal:AbortSignal.timeout(15000)})).status,404);
      console.log("Blog HTTP publication, edit, archive, uploaded-image reference, and external URL persistence verified.");
    }finally{if(committedId)await client.query("DELETE FROM cms_blog_posts WHERE id=$1 AND created_by='verification'",[committedId]);}
  }
} catch(error) {
  await client.query("ROLLBACK");
  throw error;
} finally {
  await client.end();
}
