import { config } from "dotenv";
import { asc, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { SITE_CONTENT } from "../src/data/content.ts";
import { mediaAssets, navigationLinks, services, testimonials, truckTypes } from "../src/db/schema.ts";

config({ path: ".env.local" });
config();
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required.");
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 1 });
const db = drizzle(pool);
const stable = (value: unknown): string => JSON.stringify(value, (_key, nested) => nested && typeof nested === "object" && !Array.isArray(nested) ? Object.fromEntries(Object.entries(nested).sort(([a],[b])=>a.localeCompare(b))) : nested);
try {
  const [nav, serviceRows, truckRows, reviewRows, media] = await Promise.all([
    db.select({ label: navigationLinks.label, href: navigationLinks.href }).from(navigationLinks).where(isNull(navigationLinks.deletedAt)).orderBy(asc(navigationLinks.sortOrder)),
    db.select({ slug: services.slug, num: services.num, title: services.title, detail: services.detail }).from(services).where(isNull(services.deletedAt)).orderBy(asc(services.sortOrder)),
    db.select({ slug: truckTypes.slug, num: truckTypes.num, name: truckTypes.name, image: truckTypes.image }).from(truckTypes).where(isNull(truckTypes.deletedAt)).orderBy(asc(truckTypes.sortOrder)),
    db.select({ quote: testimonials.quote, name: testimonials.name, role: testimonials.role, equipment: testimonials.equipment, location: testimonials.location, tenure: testimonials.tenure, initials: testimonials.initials, rating: testimonials.rating, status: testimonials.status, createdBy: testimonials.createdBy }).from(testimonials).where(isNull(testimonials.deletedAt)).orderBy(asc(testimonials.sortOrder)),
    db.select({ path: mediaAssets.path }).from(mediaAssets).where(isNull(mediaAssets.deletedAt)),
  ]);
  const checks = [
    ["navigation preserved", stable(nav) === stable(SITE_CONTENT.navLinks)],
    ["service identity/order preserved", stable(serviceRows.map(({slug,num,title})=>({slug,num,title}))) === stable(SITE_CONTENT.services.map(({slug,num,title})=>({slug,num,title})))],
    ["service detail content preserved", stable(serviceRows.map(({detail})=>detail)) === stable(SITE_CONTENT.services.map(({detail})=>detail))],
    ["truck records are populated from the database", truckRows.length > 0 && truckRows.every(row=>row.slug&&row.num&&row.name&&row.image)],
    ["unverified seed testimonials are held for review", reviewRows.every(row=>row.createdBy!=="seed"||row.status!=="published")],
    ["all source images registered", [SITE_CONTENT.aboutImage,...SITE_CONTENT.truckTypes.map(({image})=>image)].every(path=>media.some(asset=>asset.path===path))],
    ["service slugs unique", new Set(serviceRows.map(({slug})=>slug)).size === serviceRows.length],
    ["truck slugs unique", new Set(truckRows.map(({slug})=>slug)).size === truckRows.length],
  ] as const;
  for (const [label, passed] of checks) console.log(`${passed ? "PASS" : "FAIL"}: ${label}`);
  if (checks.some(([,passed])=>!passed)) process.exitCode=1;
} finally { await pool.end(); }
