import assert from "node:assert/strict";
import { config } from "dotenv";
import { Pool } from "pg";

config({path:".env.local",quiet:true});config({quiet:true});
for(const name of ["DATABASE_URL","NEXT_PUBLIC_SUPABASE_URL","NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY"])assert.ok(process.env[name],`${name} is required`);
const pool=new Pool({connectionString:process.env.DATABASE_URL,max:1,connectionTimeoutMillis:15000});
const tables=["carrier_applications","cms_site_settings","cms_hero_content","cms_section_copy","cms_about_content","cms_contact_settings","cms_navigation_links","cms_social_links","cms_hero_statistics","cms_about_features","cms_services","cms_truck_types","cms_pricing_items","cms_agreement_items","cms_agreement_document","cms_slug_redirects","cms_onboarding_steps","cms_testimonials","cms_contact_cards","cms_blog_posts","cms_marquee_items","cms_media_assets","admin_audit_records","admin_users","public_rate_limits","cms_agreement_revisions"];
try{
  const counts:Record<string,number>={};
  for(const table of tables)counts[table]=Number((await pool.query(`SELECT count(*) AS count FROM ${table}`)).rows[0].count);
  for(const table of ["cms_site_settings","cms_hero_content","cms_section_copy","cms_about_content","cms_contact_settings","cms_agreement_document"])assert.equal(counts[table],1,`${table} singleton missing or duplicated`);
  for(const [table,column] of [["cms_services","slug"],["cms_truck_types","slug"],["cms_blog_posts","slug"],["cms_testimonials","name,quote"]])assert.equal((await pool.query(`SELECT ${column},count(*) FROM ${table} GROUP BY ${column} HAVING count(*)>1`)).rowCount,0,`${table} contains duplicate identities`);
  const security=await pool.query<{relname:string;relrowsecurity:boolean;browser_write:boolean}>(`SELECT c.relname,c.relrowsecurity,has_table_privilege('anon',c.oid,'INSERT,UPDATE,DELETE') OR has_table_privilege('authenticated',c.oid,'INSERT,UPDATE,DELETE') browser_write FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname=ANY($1)`,[tables]);
  assert.equal(security.rowCount,tables.length,"expected public tables are missing");assert.ok(security.rows.every(row=>row.relrowsecurity&&!row.browser_write),"RLS or browser write privileges are unsafe");
  const bucket=(await pool.query<{public:boolean;file_size_limit:number;allowed_mime_types:string[]}>("SELECT public,file_size_limit,allowed_mime_types FROM storage.buckets WHERE id='cms-media'")).rows[0];
  assert.ok(bucket,"cms-media bucket missing");assert.equal(Number(bucket.file_size_limit),5*1024*1024);assert.deepEqual(bucket.allowed_mime_types.sort(),["image/jpeg","image/png","image/webp"].sort());
  const policies=await pool.query<{policyname:string}>("SELECT policyname FROM pg_policies WHERE schemaname='storage' AND tablename='objects' AND policyname LIKE 'CMS admins may % media'");assert.equal(policies.rowCount,4,"storage admin policies are incomplete");
  const storage=await pool.query<{objects:number;metadata:number;missing:number}>(`SELECT (SELECT count(*)::int FROM storage.objects WHERE bucket_id='cms-media') objects,(SELECT count(*)::int FROM cms_media_assets WHERE storage_key IS NOT NULL AND deleted_at IS NULL) metadata,(SELECT count(*)::int FROM cms_media_assets m LEFT JOIN storage.objects o ON o.bucket_id='cms-media' AND o.name=m.storage_key WHERE m.storage_key IS NOT NULL AND m.deleted_at IS NULL AND o.id IS NULL) missing`);
  assert.equal(storage.rows[0].missing,0,"uploaded media metadata points to missing storage objects");
  const mediaSources=await pool.query<{source:string;count:number}>("SELECT source,count(*)::int count FROM cms_media_assets WHERE deleted_at IS NULL GROUP BY source ORDER BY source");
  const invalidCloudinary=Number((await pool.query("SELECT count(*) FROM cms_media_assets WHERE source='cloudinary' AND (cloudinary_public_id IS NULL OR path NOT LIKE 'https://res.cloudinary.com/%')")).rows[0].count);
  assert.equal(invalidCloudinary,0,"Cloudinary media metadata is incomplete");
  const referencedUploaded=Number((await pool.query(`SELECT count(*) FROM cms_media_assets m WHERE m.storage_key IS NOT NULL AND m.deleted_at IS NULL AND (EXISTS(SELECT 1 FROM cms_hero_content WHERE images @> jsonb_build_array(m.path)) OR EXISTS(SELECT 1 FROM cms_about_content WHERE image=m.path) OR EXISTS(SELECT 1 FROM cms_services WHERE image=m.path AND deleted_at IS NULL) OR EXISTS(SELECT 1 FROM cms_truck_types WHERE image=m.path AND deleted_at IS NULL) OR EXISTS(SELECT 1 FROM cms_testimonials WHERE avatar_path=m.path AND deleted_at IS NULL) OR EXISTS(SELECT 1 FROM cms_blog_posts WHERE featured_image=m.path))`)).rows[0].count);
  console.log(JSON.stringify({connection:"ok",tables:counts,mediaSources:mediaSources.rows,bucket:{name:"cms-media",public:bucket.public,fileSizeLimit:bucket.file_size_limit,allowedMimeTypes:bucket.allowed_mime_types},storage:{...storage.rows[0],referencedUploaded},rlsTables:security.rowCount,storagePolicies:policies.rows.map(row=>row.policyname)},null,2));
}finally{await pool.end();}
