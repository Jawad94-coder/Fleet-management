import { config } from "dotenv";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { eq, sql } from "drizzle-orm";
import { SITE_CONTENT } from "../src/data/content.ts";
import { DEFAULT_AGREEMENT } from "../src/data/agreement.ts";
import { DEFAULT_SECTION_COPY } from "../src/data/section-copy.ts";
import {
  aboutContent,
  aboutFeatures,
  agreementItems,
  agreementDocument,
  contactCards,
  contactSettings,
  heroContent,
  heroStatistics,
  marqueeItems,
  mediaAssets,
  navigationLinks,
  onboardingSteps,
  pricingItems,
  services,
  sectionCopy,
  siteSettings,
  socialLinks,
  testimonials,
  truckTypes,
} from "../src/db/schema.ts";

config({ path: ".env.local" });
config();

const connectionString = process.env.DATABASE_URL;
if (!connectionString) throw new Error("DATABASE_URL is required to seed CMS content.");

const pool = new Pool({ connectionString, max: 1 });
const db = drizzle(pool);

try {
  await db.transaction(async (tx) => {
    await tx.insert(siteSettings).values({ id: 1, ...SITE_CONTENT.company }).onConflictDoNothing();
    await tx.insert(heroContent).values({
      id: 1,
      heading: "Professional Truck Dispatch Services",
      headingAccent: "for US Owner-Operators",
      showAuthority: false,
      tagline: SITE_CONTENT.heroTagline,
      description: SITE_CONTENT.heroDescription,
      images:["/images/hero-fleet.webp","/images/hero-fleet-highway.webp","/images/hero-fleet-terminal.webp"],
      imageAlts:["Commercial truck fleet","Commercial truck on the highway","Fleet terminal"],
    }).onConflictDoNothing();
    await tx.insert(aboutContent).values({
      id: 1,
      heading: "SUPPORT FOR YOUR",
      headingAccent: "TRUCKING OPERATION.",
      establishedText: "",
      yearsLabel: "",
      image: SITE_CONTENT.aboutImage,
      years: SITE_CONTENT.aboutYears,
      description1: SITE_CONTENT.aboutDescription1,
      description2: SITE_CONTENT.aboutDescription2,
    }).onConflictDoNothing();
    await tx.insert(contactSettings).values({
      id: 1,
      dispatchStatusText: "CARRIER ENQUIRIES",
      afterHoursText: "Confirm service hours and escalation contacts during onboarding.",
      description: SITE_CONTENT.contactDescription,
      dispatchResponseTime: SITE_CONTENT.dispatchResponseTime,
    }).onConflictDoNothing();
    await tx.insert(agreementDocument).values({ id: 1, ...DEFAULT_AGREEMENT }).onConflictDoNothing();
    await tx.insert(sectionCopy).values({ id: 1, content: DEFAULT_SECTION_COPY }).onConflictDoNothing();
    await tx.update(siteSettings).set({seoTitle:SITE_CONTENT.company.seoTitle,seoDescription:SITE_CONTENT.company.seoDescription}).where(sql`${siteSettings.id}=1 AND (${siteSettings.seoTitle}='Fleet Management US - Your Partner for Reliable Trucking Operations' OR ${siteSettings.seoTitle} LIKE '%Ã%')`);
    await tx.update(sectionCopy).set({content:sql`${JSON.stringify(DEFAULT_SECTION_COPY)}::jsonb || ${sectionCopy.content}`}).where(eq(sectionCopy.id,1));
    await tx.update(heroContent).set({images:["/images/hero-fleet.webp","/images/hero-fleet-highway.webp","/images/hero-fleet-terminal.webp"],imageAlts:["Commercial truck fleet","Commercial truck on the highway","Fleet terminal"]}).where(sql`jsonb_array_length(${heroContent.images}) = 0`);
    await tx.update(siteSettings).set({address:SITE_CONTENT.company.address,city:SITE_CONTENT.company.city}).where(sql`${siteSettings.id}=1 AND ${siteSettings.address}=${"1420 W Randolph St, Suite 400"} AND ${siteSettings.city}=${"Chicago, IL 60607"}`);
    await tx.update(socialLinks).set({href:SITE_CONTENT.socialLinks[0].href}).where(sql`${socialLinks.label}=${"Facebook"} AND ${socialLinks.href}=${"#"}`);
    await tx.update(socialLinks).set({href:SITE_CONTENT.socialLinks[2].href}).where(sql`${socialLinks.label}=${"Instagram"} AND ${socialLinks.href}=${"#"}`);
    await tx.update(socialLinks).set({href:SITE_CONTENT.socialLinks[4].href}).where(sql`${socialLinks.label}=${"X"} AND ${socialLinks.href}=${"#"}`);
    await tx.update(socialLinks).set({href:SITE_CONTENT.socialLinks[5].href}).where(sql`${socialLinks.label}=${"Quora"} AND ${socialLinks.href}=${"#"}`);
    await tx.update(contactCards).set({value:`${SITE_CONTENT.company.address}\n${SITE_CONTENT.company.city}`,href:SITE_CONTENT.contactCards[3].href}).where(sql`${contactCards.label}=${"Office Address"} AND (${contactCards.value}=${"1420 W Randolph St, Suite 400\nChicago, IL 60607"} OR ${contactCards.value}=${`${SITE_CONTENT.company.address}\n${SITE_CONTENT.company.city}`})`);

    if (SITE_CONTENT.navLinks.length) {
      await tx.insert(navigationLinks).values(SITE_CONTENT.navLinks.map((link, sortOrder) => ({ ...link, sortOrder }))).onConflictDoNothing();
    }
    if (SITE_CONTENT.socialLinks.length) {
      await tx.insert(socialLinks).values(SITE_CONTENT.socialLinks.map((link, sortOrder) => ({ ...link, sortOrder }))).onConflictDoNothing();
    }
    if (SITE_CONTENT.heroStats.length) {
      await tx.insert(heroStatistics).values(SITE_CONTENT.heroStats.map((stat, sortOrder) => ({ ...stat, accent: stat.accent ?? false, sortOrder }))).onConflictDoNothing();
    }
    if (SITE_CONTENT.aboutFeatures.length) {
      await tx.insert(aboutFeatures).values(SITE_CONTENT.aboutFeatures.map((feature, sortOrder) => ({ ...feature, accent: feature.accent ?? false, sortOrder }))).onConflictDoNothing();
    }
    if (SITE_CONTENT.services.length) {
      await tx.insert(services).values(SITE_CONTENT.services.map((service, sortOrder) => ({
        num: service.num,
        slug: service.slug,
        icon: service.icon,
        title: service.title,
        description: service.desc,
        ctaLabel: DEFAULT_SECTION_COPY.servicesLinkLabel,
        ctaHref: `/services/${service.slug}`,
        detail: service.detail,
        sortOrder,
      }))).onConflictDoNothing();
    }
    if (SITE_CONTENT.truckTypes.length) {
      await tx.insert(truckTypes).values(SITE_CONTENT.truckTypes.map((truck, sortOrder) => ({ ...truck, imageAlt:`${truck.name} commercial fleet equipment`, sortOrder }))).onConflictDoNothing();
    }
    if (SITE_CONTENT.pricing.length) {
      await tx.insert(pricingItems).values(SITE_CONTENT.pricing.map((item, sortOrder) => ({ ...item, agreementSuffix: "agreementSuffix" in item ? item.agreementSuffix : null, sortOrder }))).onConflictDoNothing();
    }
    if (SITE_CONTENT.agreementSummary.length) {
      await tx.insert(agreementItems).values(SITE_CONTENT.agreementSummary.map((item, sortOrder) => ({ ...item, sortOrder }))).onConflictDoNothing();
    }
    if (SITE_CONTENT.steps.length) {
      await tx.insert(onboardingSteps).values(SITE_CONTENT.steps.map((step, sortOrder) => ({
        num: step.num,
        label: step.label,
        title: step.title,
        description: step.desc,
        sortOrder,
      }))).onConflictDoNothing();
    }
    if (SITE_CONTENT.contactCards.length) {
      await tx.insert(contactCards).values(SITE_CONTENT.contactCards.map((card, sortOrder) => ({ ...card, href: "href" in card ? card.href : null, sortOrder }))).onConflictDoNothing();
    }
    if (SITE_CONTENT.marqueeItems.length) {
      await tx.insert(marqueeItems).values(SITE_CONTENT.marqueeItems.map((label, sortOrder) => ({ label, sortOrder }))).onConflictDoNothing();
    }
    if (SITE_CONTENT.testimonials.length) {
      await tx.insert(testimonials).values(SITE_CONTENT.testimonials.map((testimonial, sortOrder) => ({
        ...testimonial,
        rating: 5,
        featured: false,
        sortOrder,
        status: "published" as const,
      }))).onConflictDoNothing();
    }

    const imagePaths = [...new Set([SITE_CONTENT.company.logo,SITE_CONTENT.aboutImage,"/images/hero-fleet.webp","/images/hero-fleet-highway.webp","/images/hero-fleet-terminal.webp", ...SITE_CONTENT.truckTypes.map((truck) => truck.image)])];
    await tx.insert(mediaAssets).values(imagePaths.map((path) => ({
      path,
      fileName: path.split("/").at(-1) ?? path,
      mimeType: path.endsWith(".png") ? "image/png" : path.endsWith(".webp") ? "image/webp" : "image/jpeg",
    }))).onConflictDoNothing();

    // Older CMS rows may reference images created before the media library existed.
    await tx.execute(sql`
      INSERT INTO "cms_media_assets" ("path", "file_name", "mime_type", "source")
      SELECT DISTINCT
        refs.path,
        CASE WHEN refs.path LIKE '/%' THEN regexp_replace(refs.path, '^.*/', '') ELSE 'External CMS image' END,
        CASE
          WHEN lower(refs.path) ~ '\\.png([?#].*)?$' THEN 'image/png'
          WHEN lower(refs.path) ~ '\\.webp([?#].*)?$' THEN 'image/webp'
          WHEN lower(refs.path) ~ '\\.avif([?#].*)?$' THEN 'image/avif'
          WHEN lower(refs.path) ~ '\\.gif([?#].*)?$' THEN 'image/gif'
          WHEN lower(refs.path) ~ '\\.svg([?#].*)?$' THEN 'image/svg+xml'
          ELSE 'image/jpeg'
        END,
        CASE WHEN refs.path LIKE '/%' THEN 'local' ELSE 'external' END
      FROM (
        SELECT "logo" AS path FROM "cms_site_settings"
        UNION SELECT "image" FROM "cms_about_content"
        UNION SELECT jsonb_array_elements_text("images") FROM "cms_hero_content"
        UNION SELECT "image" FROM "cms_services" WHERE "image" IS NOT NULL
        UNION SELECT "image" FROM "cms_truck_types"
        UNION SELECT "avatar_path" FROM "cms_testimonials" WHERE "avatar_path" IS NOT NULL
        UNION SELECT "featured_image" FROM "cms_blog_posts" WHERE "featured_image" IS NOT NULL
      ) AS refs
      WHERE refs.path <> ''
      ON CONFLICT ("path") DO NOTHING
    `);
  });

  console.log("CMS seed complete. Existing rows were preserved.");
} finally {
  await pool.end();
}
