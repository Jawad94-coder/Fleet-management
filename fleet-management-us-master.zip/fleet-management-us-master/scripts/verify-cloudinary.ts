import assert from "node:assert/strict";
import { config } from "dotenv";
import { Pool } from "pg";
import { removeMediaObject, uploadMediaObject, validateMediaFile } from "../src/lib/storage/media.ts";

config({path:".env.local",quiet:true});
const pool=new Pool({connectionString:process.env.DATABASE_URL,max:1});
const png=Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=","base64");
const file=new File([png],"cloudinary-verification.png",{type:"image/png"});
let publicId="";let mediaId:number|undefined;let blogId:number|undefined;let rendered=false;
try{
  const stale=(await pool.query<{cloudinary_public_id:string}>("SELECT cloudinary_public_id FROM cms_media_assets WHERE created_by='verification' AND cloudinary_public_id IS NOT NULL")).rows;
  await pool.query("DELETE FROM cms_blog_posts WHERE created_by='verification'");
  await pool.query("DELETE FROM cms_media_assets WHERE created_by='verification'");
  for(const asset of stale)await removeMediaObject(asset.cloudinary_public_id);
  const uploaded=await uploadMediaObject(file,await validateMediaFile(file),"blogs");publicId=uploaded.publicId;
  assert.ok(publicId.startsWith("fleet-management-us/blogs/"));assert.match(uploaded.publicUrl,/^https:\/\/res\.cloudinary\.com\//);
  mediaId=(await pool.query<{id:number}>("INSERT INTO cms_media_assets(path,file_name,mime_type,cloudinary_public_id,source,size_bytes,width,height,alt_text,created_by,updated_by) VALUES($1,$2,$3,$4,'cloudinary',$5,$6,$7,$8,'verification','verification') RETURNING id",[uploaded.publicUrl,file.name,file.type,publicId,uploaded.sizeBytes,uploaded.width,uploaded.height,"Verification pixel"])).rows[0].id;
  const persisted=(await pool.query("SELECT path,cloudinary_public_id,source FROM cms_media_assets WHERE id=$1",[mediaId])).rows[0];assert.deepEqual(persisted,{path:uploaded.publicUrl,cloudinary_public_id:publicId,source:"cloudinary"});
  const base=process.env.VERIFY_BASE_URL;
  if(base){const slug=`cloudinary-verification-${Date.now()}`;blogId=(await pool.query<{id:number}>("INSERT INTO cms_blog_posts(title,slug,body,featured_image,featured_image_alt,author,category,status,published_at,reading_time,created_by,updated_by) VALUES('Cloudinary verification',$1,'# Cloudinary verification',$2,'Verification pixel','Verifier','Operations','published',now(),1,'verification','verification') RETURNING id",[slug,uploaded.publicUrl])).rows[0].id;const response=await fetch(new URL(`/blogs/${slug}`,base),{cache:"no-store",signal:AbortSignal.timeout(60000)});assert.equal(response.status,200);assert.ok((await response.text()).includes(uploaded.publicUrl));rendered=true;}
}finally{
  if(blogId)await pool.query("DELETE FROM cms_blog_posts WHERE id=$1 AND created_by='verification'",[blogId]);
  if(mediaId)await pool.query("DELETE FROM cms_media_assets WHERE id=$1 AND created_by='verification'",[mediaId]);
  if(publicId)await removeMediaObject(publicId);
  await pool.end();
}
console.log(rendered?"Cloudinary signed upload, folder, Supabase metadata, public rendering, and cleanup verified.":"Cloudinary signed upload, folder, Supabase metadata, and cleanup verified.");
