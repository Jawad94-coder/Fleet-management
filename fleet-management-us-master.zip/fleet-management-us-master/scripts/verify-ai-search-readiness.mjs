import { mkdir, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import { pathToFileURL } from "node:url";
import { request as httpRequest } from "node:http";

export const canonicalOrigin = "https://www.fleetmanagementus.com";
export const searchCrawlers = ["Googlebot", "bingbot", "OAI-SearchBot", "PerplexityBot", "Claude-SearchBot"];
export const retrievalAgents = ["ChatGPT-User", "Perplexity-User", "Claude-User"];
export const trainingCrawlers = ["GPTBot", "ClaudeBot"];
export const sameUrl = (left, right) => { try { return new URL(left).href === new URL(right).href; } catch { return false; } };

// Covers robots group selection, wildcard paths, terminal $, and Allow ties.
export function robotsAllowed(text, agent, path) {
  const groups = [];
  let group = { agents: [], rules: [] };
  let startedRules = false;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.split("#")[0].trim();
    const match = /^([^:]+):\s*(.*)$/.exec(line);
    if (!match) continue;
    const [, field, value] = match;
    if (field.toLowerCase() === "user-agent") {
      if (startedRules) { groups.push(group); group = { agents: [], rules: [] }; startedRules = false; }
      group.agents.push(value.toLowerCase());
    } else if (/^(allow|disallow)$/i.test(field) && group.agents.length) {
      startedRules = true;
      if (value) group.rules.push({ allow: field.toLowerCase() === "allow", path: value });
    }
  }
  groups.push(group);
  const scored = groups.map(value => ({ ...value, score: Math.max(-1, ...value.agents.map(token => token === "*" ? 0 : agent.toLowerCase().includes(token) ? token.length : -1)) }));
  const best = Math.max(-1, ...scored.map(group => group.score));
  const rules = scored.filter(group => group.score === best && best >= 0).flatMap(group => group.rules).filter(rule => {
    const terminal = rule.path.endsWith("$");
    const pattern = (terminal ? rule.path.slice(0, -1) : rule.path).split("*").map(part => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join(".*");
    return new RegExp(`^${pattern}${terminal ? "$" : ""}`).test(path);
  }).sort((a, b) => b.path.replace(/[*$]/g, "").length - a.path.replace(/[*$]/g, "").length || Number(b.allow) - Number(a.allow));
  return rules[0]?.allow ?? true;
}

export function decode(value) {
  return value.replace(/&(?:amp|quot|apos|lt|gt|#\d+|#x[\da-f]+);/gi, entity => {
    const named = { "&amp;": "&", "&quot;": '"', "&apos;": "'", "&lt;": "<", "&gt;": ">" };
    if (named[entity.toLowerCase()]) return named[entity.toLowerCase()];
    const point = entity[2].toLowerCase() === "x" ? parseInt(entity.slice(3, -1), 16) : Number(entity.slice(2, -1));
    return point <= 0x10ffff ? String.fromCodePoint(point) : entity;
  });
}

export function attrs(tag) {
  return Object.fromEntries([...tag.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)].map(match => [match[1].toLowerCase(), decode(match[2] ?? match[3])]));
}
export function pageFacts(html) {
  const clean = html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "").replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, "");
  const meta = [...clean.matchAll(/<meta\b[^>]*>/gi)].map(match => attrs(match[0]));
  const links = [...clean.matchAll(/<link\b[^>]*>/gi)].map(match => attrs(match[0]));
  const main = /<main\b[^>]*>([\s\S]*?)<\/main>/i.exec(clean)?.[1] ?? "";
  return {
    title: decode(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(clean)?.[1] ?? ""),
    description: meta.find(item => item.name === "description")?.content,
    canonicals: links.filter(item => item.rel === "canonical").map(item => item.href),
    ogUrl: meta.find(item => item.property === "og:url")?.content,
    ogTitle: meta.find(item => item.property === "og:title")?.content,
    twitterTitle: meta.find(item => item.name === "twitter:title")?.content,
    robots: meta.filter(item => /^(robots|googlebot|bingbot)$/i.test(item.name ?? "")).map(item => item.content).join(","),
    viewport: meta.find(item => item.name === "viewport")?.content,
    h1s: [...main.matchAll(/<h1\b[^>]*>([\s\S]*?)<\/h1>/gi)].map(match => decode(match[1].replace(/<[^>]+>/g, "")).replace(/\s+/g, " ").trim()),
    headings: [...main.matchAll(/<h([2-3])\b/gi)].length,
    mainText: decode(main.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim(),
    visibleText: decode(clean.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim(),
    anchors: [...clean.matchAll(/<a\b[^>]*>/gi)].map(match => attrs(match[0]).href).filter(Boolean),
    ids: new Set([...clean.matchAll(/\bid=["']([^"']+)["']/g)].map(match => match[1])),
    jsonLd: [...html.matchAll(/<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)].flatMap(match => { const value = JSON.parse(match[1]); return Array.isArray(value) ? value : [value]; }),
  };
}

async function verify() {
  const argument = name => process.argv.find(value => value.startsWith(`${name}=`))?.slice(name.length + 1);
  const base = (argument("--base") ?? "http://127.0.0.1:3100").replace(/\/$/, "");
  const output = argument("--output") ?? ".local/ai-search-verification.json";
  const local = ["localhost", "127.0.0.1"].includes(new URL(base).hostname);
  const results = [];
  const record = (check, passed, evidence) => { results.push({ check, passed, evidence }); if (!passed) console.error(`FAIL ${check}: ${evidence}`); };
  const request = async (path, headers = {}) => {
    const response = await fetch(new URL(path, base), { redirect: "manual", headers, signal: AbortSignal.timeout(30000) });
    return { status: response.status, location: response.headers.get("location"), type: response.headers.get("content-type"), xRobots: response.headers.get("x-robots-tag"), html: await response.text() };
  };
  const robots = await request("/robots.txt");
  record("robots response", robots.status === 200 && /text\/plain/.test(robots.type), `${robots.status} ${robots.type}`);
  record("robots sitemap reference", robots.html.includes(`${canonicalOrigin}/sitemap.xml`), "Canonical sitemap declared");
  const sitemap = await request("/sitemap.xml");
  record("sitemap response", sitemap.status === 200 && /xml/.test(sitemap.type), `${sitemap.status} ${sitemap.type}`);
  const entries = [...sitemap.html.matchAll(/<url>([\s\S]*?)<\/url>/g)].map(match => ({ url: decode(/<loc>(.*?)<\/loc>/.exec(match[1])?.[1] ?? ""), lastmod: /<lastmod>(.*?)<\/lastmod>/.exec(match[1])?.[1] }));
  record("sitemap unique canonical URLs", entries.length > 0 && new Set(entries.map(item => item.url)).size === entries.length && entries.every(item => item.url.startsWith(`${canonicalOrigin}/`)), `${entries.length} entries`);
  record("sitemap timestamps", entries.every(item => !item.lastmod || Number.isFinite(Date.parse(item.lastmod)) && Date.parse(item.lastmod) <= Date.now() + 60000), "lastmod parseable and not in future");
  const required = ["/", "/blogs", ...["mc-leasing", "dispatch-services", "load-assistance", "factoring-support", "insurance-support", "back-office-support", "carrier-setup-assistance"].map(slug => `/services/${slug}`), ...["box-truck", "dry-van", "reefer", "flatbed", "hotshot"].map(slug => `/truck-types/${slug}`)];
  for (const path of required) record(`sitemap membership ${path}`, entries.some(item => new URL(item.url).pathname === path), path);
  const pages = new Map();
  for (const entry of entries) {
    const path = new URL(entry.url).pathname;
    const response = await request(path);
    record(`HTTP ${path}`, response.status === 200 && /text\/html/.test(response.type), `${response.status} ${response.type}`);
    if (response.status !== 200) continue;
    let facts;
    try { facts = pageFacts(response.html); } catch (error) { record(`JSON-LD ${path}`, false, error.message); continue; }
    pages.set(path, facts);
    record(`canonical ${path}`, facts.canonicals.length === 1 && sameUrl(facts.canonicals[0], entry.url), facts.canonicals.join(","));
    record(`indexability ${path}`, !/\b(noindex|none|nosnippet)\b/i.test(`${facts.robots},${response.xRobots ?? ""}`), `${facts.robots}; X-Robots-Tag=${response.xRobots}`);
    record(`social metadata ${path}`, sameUrl(facts.ogUrl, entry.url) && !!facts.ogTitle && !!facts.twitterTitle && facts.ogTitle === facts.twitterTitle, `${facts.ogUrl}; ${facts.ogTitle}; ${facts.twitterTitle}`);
    record(`title/description ${path}`, facts.title.length > 0 && !!facts.description, facts.title);
    record(`one H1 ${path}`, facts.h1s.length === 1 && !!facts.h1s[0], JSON.stringify(facts.h1s));
    record(`initial HTML ${path}`, facts.mainText.length >= 250 && facts.headings > 0 && /Fleet Management US/i.test(response.html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "")), `${facts.mainText.length} characters; ${facts.headings} H2/H3 headings`);
    record(`no template instructions ${path}`, !/ALL FIELDS EDITABLE|Add or remove truck types|All fields below are editable|\(888\) 555-0142|EST\.\s*2014/.test(facts.visibleText), "Scanned visible HTML including navigation/footer");
    record(`mobile HTML signals ${path}`, /width=device-width/.test(facts.viewport ?? "") && /<html[^>]+lang=["']en["']/i.test(response.html), facts.viewport);
    record(`JSON-LD ${path}`, facts.jsonLd.length > 0 && facts.jsonLd.every(item => item["@context"] === "https://schema.org" && !!item["@type"]), `${facts.jsonLd.map(item => item["@type"]).join(", ")}; syntax parsed (not Google eligibility validation)`);
    record(`schema factual baseline ${path}`, facts.jsonLd.every(item => !["LocalBusiness", "AggregateRating", "Review"].includes(item["@type"]) && !item.aggregateRating && !item.review && !item.foundingDate), "No unverified local entity, ratings or founding date");
    for (const agent of [...searchCrawlers, ...retrievalAgents]) {
      record(`robots ${agent} ${path}`, robotsAllowed(robots.html, agent, path), "Robots policy only; retrieval agents may handle robots differently");
      if (!process.argv.includes("--skip-agent-http")) {
        const simulated = await request(path, { "User-Agent": agent });
        const simulatedMain = pageFacts(simulated.html).mainText;
        record(`simulated UA ${agent} ${path}`, simulated.status === 200 && simulatedMain === facts.mainText && !/noindex|none/i.test(simulated.xRobots ?? ""), `${simulated.status}; equivalent initial content=${simulatedMain === facts.mainText}`);
      }
    }
  }
  for (const agent of searchCrawlers) {
    record(`private robots ${agent}`, !robotsAllowed(robots.html, agent, "/admin/") && !robotsAllowed(robots.html, agent, "/admin") && !robotsAllowed(robots.html, agent, "/api/carrier-applications"), "Admin root, subtree and API excluded; robots is not authentication");
  }
  const titles = [...pages.values()].map(page => page.title);
  const descriptions = [...pages.values()].map(page => page.description);
  record("unique titles", new Set(titles).size === titles.length, `${titles.length} titles`);
  record("unique descriptions", new Set(descriptions).size === descriptions.length, `${descriptions.length} descriptions`);
  const incoming = new Set();
  const extra = new Map();
  for (const [path, facts] of pages) {
    for (const href of facts.anchors) {
      if (/^(mailto|tel):/.test(href)) continue;
      const target = new URL(href, `${canonicalOrigin}${path}`);
      if (![canonicalOrigin, "https://fleetmanagementus.com", base].includes(target.origin)) continue;
      record(`preferred internal host ${path} → ${href}`, target.hostname !== "fleetmanagementus.com", href);
      if (target.pathname !== path) incoming.add(target.pathname);
      const known = pages.get(target.pathname);
      if (known && target.hash) record(`anchor ${path} → ${href}`, known.ids.has(decodeURIComponent(target.hash.slice(1))), target.hash);
      if (!known && !extra.has(target.pathname)) extra.set(target.pathname, await request(target.pathname));
    }
  }
  for (const [path, response] of extra) record(`linked route ${path}`, response.status === 200, `${response.status}`);
  for (const path of pages.keys()) if (path !== "/") record(`inbound discovery ${path}`, incoming.has(path), "At least one link from a different indexable page");
  for (const path of ["/?seo_check=1", "/services/dispatch-services?seo_check=1", "/blogs/reduce-empty-miles-with-dispatch-planning?seo_check=1"]) {
    // Node fetch ignores a custom Host header; use http.request for the local host-routing test.
    const response = local ? await new Promise((resolve, reject) => {
      const r = httpRequest(new URL(path, base), { headers: { Host: "fleetmanagementus.com" } }, result => {
        result.resume();
        resolve({ status: result.statusCode, location: result.headers.location });
      });
      r.setTimeout(30000, () => r.destroy(new Error("Host redirect request timed out")));
      r.on("error", reject);
      r.end();
    }) : await (async () => {
      const r = await fetch(`https://fleetmanagementus.com${path}`, { redirect: "manual", signal: AbortSignal.timeout(30000) });
      return { status: r.status, location: r.headers.get("location") };
    })();
    record(`permanent host redirect ${path}`, [301, 308].includes(response.status) && sameUrl(response.location, `${canonicalOrigin}${path}`), `${response.status} → ${response.location}`);
    if (sameUrl(response.location, `${canonicalOrigin}${path}`)) {
      const destination = await request(path);
      record(`one hop/no loop ${path}`, destination.status === 200 && !destination.location, `${destination.status}`);
    }
  }
  const privateResponse = await request("/admin");
  record("admin access control", [301, 302, 303, 307, 308, 401, 403].includes(privateResponse.status) && !privateResponse.html.includes("Admin Dashboard"), `${privateResponse.status} → ${privateResponse.location}`);
  const login = await request("/admin/login");
  record("admin noindex", /noindex/i.test(`${login.xRobots ?? ""},${pageFacts(login.html).robots}`), `${login.xRobots}; login robots=${pageFacts(login.html).robots}`);
  const missing = await request("/seo-verification-missing-page");
  record("unknown page status", missing.status === 404, `${missing.status}`);
  const draft = await request("/truck-dispatch-services-lahore");
  record("unverified Lahore page unpublished", draft.status === 404 && !entries.some(item => item.url.endsWith("/truck-dispatch-services-lahore")), `${draft.status}; excluded from sitemap`);
  const invalidForm = await fetch(new URL("/api/carrier-applications", base), { method: "POST", headers: { "Content-Type": "application/json", Origin: base }, body: "{}", signal: AbortSignal.timeout(30000) });
  record("enquiry API rejects incomplete input", invalidForm.status === 400, `${invalidForm.status}; invalid payload only, no lead submitted`);
  const summary = { date: new Date().toISOString(), base, pages: pages.size, passed: results.filter(item => item.passed).length, failed: results.filter(item => !item.passed).length, trainingPreferences: Object.fromEntries(trainingCrawlers.map(agent => [agent, robotsAllowed(robots.html, agent, "/")])), caveats: ["Simulated agents do not prove genuine crawler visits, indexing or citations.", "Responsive HTML signals are not visual mobile QA or Core Web Vitals.", "JSON parsing is not Google Rich Results Test validation."], results };
  await mkdir(dirname(output), { recursive: true });
  await writeFile(output, JSON.stringify(summary, null, 2));
  console.log(`${summary.pages} pages; ${summary.passed} passed; ${summary.failed} failed. Evidence: ${output}`);
  if (summary.failed) process.exitCode = 1;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) await verify();
