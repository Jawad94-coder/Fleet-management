import test from "node:test";
import assert from "node:assert/strict";
import { robotsAllowed, pageFacts, sameUrl } from "./verify-ai-search-readiness.mjs";

test("robots chooses specific groups, merges equal groups and respects longest Allow", () => {
  const rules = "User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /api/\n\nUser-agent: OAI-SearchBot\nDisallow: /private/*\nAllow: /private/public$\n\nUser-agent: OAI-SearchBot\nDisallow: /also-private\n";
  assert.equal(robotsAllowed(rules, "Googlebot", "/services/dispatch-services"), true);
  assert.equal(robotsAllowed(rules, "Googlebot", "/admin"), false);
  assert.equal(robotsAllowed(rules, "Claude-SearchBot", "/api/test"), false);
  assert.equal(robotsAllowed(rules, "OAI-SearchBot", "/private/no"), false);
  assert.equal(robotsAllowed(rules, "OAI-SearchBot", "/private/public"), true);
  assert.equal(robotsAllowed(rules, "OAI-SearchBot", "/private/public/extra"), false);
  assert.equal(robotsAllowed(rules, "OAI-SearchBot", "/also-private"), false);
  assert.equal(robotsAllowed("User-agent: *\nDisallow: /same\nAllow: /same", "bingbot", "/same"), true);
  assert.equal(robotsAllowed("User-agent: GPTBot\nDisallow:\nUser-agent: *\nDisallow: /", "Googlebot", "/services"), false);
});

test("HTML checks exclude hydration text and parse metadata and JSON-LD", () => {
  assert.equal(sameUrl("https://www.fleetmanagementus.com", "https://www.fleetmanagementus.com/"), true);
  assert.equal(sameUrl("https://fleetmanagementus.com/", "https://www.fleetmanagementus.com/"), false);
  assert.equal(sameUrl("https://www.fleetmanagementus.com/services/a", "https://www.fleetmanagementus.com/services/b"), false);
  assert.equal(sameUrl("https://www.fleetmanagementus.com?seo_check=1", "https://www.fleetmanagementus.com/?seo_check=1"), true);
  assert.equal(sameUrl("https://www.fleetmanagementus.com/", "https://www.fleetmanagementus.com/?seo_check=1"), false);
  const html = `<html lang="en"><head><title>Truck &amp; dispatch</title><meta content="Description" name="description"><link href="https://www.fleetmanagementus.com/" rel="canonical"></head><body><main><h1>A <span>service</span></h1><h2>What is included?</h2><p>Visible answer.</p><a href="/blogs?a=1&amp;b=2">Guides</a></main><script>"<h1>Hydration only</h1>"</script><script type="application/ld+json">{"@context":"https://schema.org","@type":"Service"}</script></body></html>`;
  const facts = pageFacts(html);
  assert.deepEqual(facts.h1s, ["A service"]);
  assert.equal(facts.title, "Truck & dispatch");
  assert.equal(facts.description, "Description");
  assert.deepEqual(facts.anchors, ["/blogs?a=1&b=2"]);
  assert.equal(facts.mainText.includes("Hydration"), false);
  assert.equal(facts.jsonLd[0]["@type"], "Service");
  assert.throws(() => pageFacts(`<script type="application/ld+json">{invalid}</script>`));
});
