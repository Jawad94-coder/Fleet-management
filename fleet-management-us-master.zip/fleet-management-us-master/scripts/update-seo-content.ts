import { config } from "dotenv";
import { readFile, mkdir, writeFile } from "node:fs/promises";
import { isDeepStrictEqual } from "node:util";
import { Pool } from "pg";
import { SITE_CONTENT } from "../src/data/content.ts";
import { DEFAULT_SECTION_COPY } from "../src/data/section-copy.ts";
import { DEFAULT_AGREEMENT } from "../src/data/agreement.ts";
import { SEO_ARTICLES, EMPTY_MILES_ADDITION } from "../src/data/seo-articles.ts";

config({ path: ".env.local", quiet: true });
config({ quiet: true });
const apply = process.argv.includes("--apply");
const baseline = JSON.parse(await readFile(new URL("./seo-content-baseline.json", import.meta.url), "utf8")) as Record<string, Array<Record<string, unknown> & { id: number }>>;
type Change = { table: string; id: number; before: Record<string, unknown>; after: Record<string, unknown> };
const plan: Change[] = [];
function change(table: string, row: { id: number } & Record<string, unknown>, after: Record<string, unknown>) {
  const before = Object.fromEntries(Object.keys(after).map(key => [key, row[key]]));
  if (!isDeepStrictEqual(before, after)) plan.push({ table, id: row.id, before, after });
}
const company = SITE_CONTENT.company;
change("cms_site_settings", baseline.cms_site_settings[0], {
  phone: company.phone, phone_href: company.phoneHref,
  email: company.email, email_href: company.emailHref, hours: company.hours,
  seo_title: company.seoTitle, seo_description: company.seoDescription,
});
change("cms_hero_content", baseline.cms_hero_content[0], {
  heading: "Professional Truck Dispatch Services", heading_accent: "for US Owner-Operators",
  description: SITE_CONTENT.heroDescription, tagline: SITE_CONTENT.heroTagline,
  show_authority: false, primary_cta_label: "Discuss dispatch support",
});
for (const [index, row] of baseline.cms_hero_statistics.entries()) {
  const stat = SITE_CONTENT.heroStats[index];
  change("cms_hero_statistics", row, { value: stat.value, label: stat.label, accent: stat.accent ?? false });
}
change("cms_about_content", baseline.cms_about_content[0], {
  heading: "SUPPORT FOR YOUR", heading_accent: "TRUCKING OPERATION.",
  established_text: "", years: "", years_label: "",
  description_1: SITE_CONTENT.aboutDescription1, description_2: SITE_CONTENT.aboutDescription2,
});
for (const [index, row] of baseline.cms_about_features.entries()) {
  const feature = SITE_CONTENT.aboutFeatures[index];
  change("cms_about_features", row, { title: feature.title, description: feature.description });
}
for (const row of baseline.cms_services) {
  const service = SITE_CONTENT.services.find(item => item.slug === row.slug);
  if (service) change("cms_services", row, { description: service.desc, detail: service.detail, seo_title: service.seoTitle, seo_description: service.seoDescription });
}
for (const row of baseline.cms_truck_types) {
  change("cms_truck_types", row, { weekly_gross_min: null, weekly_gross_max: null, avg_miles_per_week: null });
}
for (const [index, row] of baseline.cms_pricing_items.entries()) {
  const price = SITE_CONTENT.pricing[index];
  change("cms_pricing_items", row, { name: price.name, value: price.value, unit: price.unit, description: price.description, agreement_suffix: null });
}
change("cms_contact_settings", baseline.cms_contact_settings[0], {
  description: SITE_CONTENT.contactDescription, dispatch_response_time: "",
  dispatch_status_text: "CARRIER ENQUIRIES", after_hours_text: "Confirm service hours and escalation contacts during onboarding.",
});
for (const row of baseline.cms_contact_cards) {
  if (row.label === "Email") change("cms_contact_cards", row, { value: company.email, href: company.emailHref });
  if (row.label === "Phone") change("cms_contact_cards", row, { value: company.phone, href: company.phoneHref });
}
// Merge the changed editorial fields; keep unrelated CMS customizations.
const oldCopy = baseline.cms_section_copy[0].content as Record<string, unknown>;
const copyKeys = ["trucksDescription", "howCtaDescription", "agreementDescription", "pricingNote", "blogsSeoTitle", "blogsSeoDescription", "agreementEditableLabel", "agreementModalKicker", "truckCustomDescription", "truckRevenueLabel"] as const;
change("cms_section_copy", baseline.cms_section_copy[0], { content: { ...oldCopy, ...Object.fromEntries(copyKeys.map(key => [key, DEFAULT_SECTION_COPY[key]])) } });
for (const row of baseline.cms_onboarding_steps) {
  const step = SITE_CONTENT.steps.find(item => item.num === row.num);
  if (step) change("cms_onboarding_steps", row, { description: step.desc });
}
for (const row of baseline.cms_agreement_items) {
  const item = SITE_CONTENT.agreementSummary.find(item => item.num === row.num);
  if (item) change("cms_agreement_items", row, { description: item.description });
}
const { carrierSignatureLabel, carrierSignatureHelp, companySignatureLabel, companySignatureHelp, ...document } = DEFAULT_AGREEMENT;
change("cms_agreement_document", baseline.cms_agreement_document[0], {
  ...document, carrier_signature_label: carrierSignatureLabel, carrier_signature_help: carrierSignatureHelp,
  company_signature_label: companySignatureLabel, company_signature_help: companySignatureHelp,
});
for (const row of baseline.cms_testimonials) {
  if (row.created_by === "seed") change("cms_testimonials", row, { status: "pending" });
}
for (const row of baseline.cms_blog_posts) {
  const body = String(row.body);
  if (row.slug === "reduce-empty-miles-with-dispatch-planning") {
    change("cms_blog_posts", row, { body: `Dispatch planning can help reduce avoidable empty travel by evaluating pickup distance, delivery timing and outbound freight before booking. Measure the result with actual trip records; no specific reduction is guaranteed.\n\n${body}${EMPTY_MILES_ADDITION}` });
  } else if (row.slug === "practical-fleet-management-checklist") {
    change("cms_blog_posts", row, { body: `${body}\n\n# Connect your dispatch and paperwork workflow\n\nCompare [dispatch responsibilities](/services/dispatch-services), [back-office support](/services/back-office-support) and [carrier onboarding](/services/carrier-setup-assistance) to define the work your operation needs. [Send a carrier enquiry](/#contact) with your equipment and lane details.` });
  }
}

if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required.");
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 1, connectionTimeoutMillis: 15000 });
const client = await pool.connect();
const backup: { changes: Change[]; insertedBlogs: Array<{ id: number; slug: string }> } = { changes: [], insertedBlogs: [] };
let conflicts = 0;
try {
  await client.query("BEGIN");
  for (const item of plan) {
    const columns = Object.keys(item.after);
    // Identifiers are restricted to the checked-in plan, never request input.
    if (![item.table, ...columns].every(value => /^[a-z_][a-z0-9_]*$/.test(value))) throw new Error("Invalid plan identifier");
    const { rows } = await client.query(`SELECT ${columns.map(key => `"${key}"`).join(",")} FROM "${item.table}" WHERE id=$1 FOR UPDATE`, [item.id]);
    const current = rows[0];
    if (isDeepStrictEqual(current, item.after)) continue;
    if (!isDeepStrictEqual(current, item.before)) { console.error(`CONFLICT ${item.table} id=${item.id}; no overwrite`); conflicts++; continue; }
    backup.changes.push(item);
    if (apply) {
      const values = columns.map(key => typeof item.after[key] === "object" && item.after[key] !== null ? JSON.stringify(item.after[key]) : item.after[key]);
      await client.query(`UPDATE "${item.table}" SET ${columns.map((key, i) => `"${key}"=$${i + 1}`).join(",")},updated_at=now(),updated_by='seo-aeo-2026-10' WHERE id=$${columns.length + 1}`, [...values, item.id]);
    }
  }
  for (const article of SEO_ARTICLES) {
    const existing = await client.query("SELECT id FROM cms_blog_posts WHERE slug=$1", [article.slug]);
    if (existing.rowCount) continue;
    if (apply) {
      const { rows } = await client.query(`INSERT INTO cms_blog_posts (title,slug,excerpt,body,category,tags,reading_time,featured_image,featured_image_alt,seo_title,seo_description,author,status,published_at,created_by,updated_by) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'','published',now(),'seo-aeo-2026-10','seo-aeo-2026-10') RETURNING id`, [article.title, article.slug, article.excerpt, article.body, article.category, JSON.stringify(article.tags), article.readingTime, article.featuredImage, article.featuredImageAlt, article.seoTitle, article.seoDescription]);
      backup.insertedBlogs.push({ id: rows[0].id, slug: article.slug });
    } else console.log(`WOULD INSERT /blogs/${article.slug}`);
  }
  if (conflicts) throw new Error(`${conflicts} content conflicts; transaction rolled back.`);
  if (apply) {
    await mkdir(".local", { recursive: true });
    const path = `.local/seo-content-backup-${Date.now()}.json`;
    await writeFile(path, JSON.stringify(backup, null, 2));
    await client.query("COMMIT");
    console.log(`APPLIED ${backup.changes.length} guarded updates; ${backup.insertedBlogs.length} articles. Backup: ${path}`);
  } else {
    await client.query("ROLLBACK");
    console.log(`DRY RUN: ${backup.changes.length} guarded updates; no database changes. Use --apply to execute.`);
  }
} catch (error) {
  await client.query("ROLLBACK");
  throw error;
} finally { client.release(); await pool.end(); }
