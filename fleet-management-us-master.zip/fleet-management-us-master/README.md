# Fleet Management US

A responsive, single-page trucking operations website built with Next.js. The site presents Fleet Management US services for carriers and truck owners, including dispatch, MC leasing, load assistance, factoring, insurance, compliance, and back-office support.

## Website Features

- Sticky desktop and mobile navigation with active-section tracking
- Responsive hero section with service calls to action and fleet statistics
- Company overview and nationwide operations highlights
- Seven fleet-management service cards
- Supported truck-type showcase
- Carrier agreement summary and pricing information
- Five-step carrier onboarding process
- Contact and carrier application form
- Full agreement modal and toast notifications
- Smooth scrolling and responsive motion effects

The public content and carrier applications are stored in PostgreSQL through Drizzle ORM. Supabase Auth protects the admin panel at `/admin`, which provides database-driven reporting, carrier lead management, and review CRUD.

## SEO and AI-search verification

See [the implementation report](./SEO_AEO_IMPLEMENTATION_REPORT.md) and [the crawlability gate](./AI_SEARCH_CRAWLABILITY_REPORT.md) for verified changes, business facts awaiting confirmation and release evidence. The Lahore commercial page is an unpublished review draft until the business supplies its operating details.

```powershell
npm run seo:content # Guarded CMS update: dry run, not a database reset
npm run build
npm run start -- --hostname 127.0.0.1 --port 3100
npm run seo:verify -- --base=http://127.0.0.1:3100 --output=.local/local-final.json
npm run seo:verify -- --base=https://www.fleetmanagementus.com --output=.local/live-final.json
```

`seo:content -- --apply` saves a local backup and applies only audited, unchanged fields. It has already been applied to the configured database for this implementation; a repeat dry run should report zero updates. Do not rerun the seed to apply SEO edits to an existing CMS. The restore script refuses to overwrite later editorial changes; consult the implementation report before using it.

Deploy the source to Hostinger's Node.js application, retaining the existing environment variables. The application must receive the original request hostname for its apex-to-www redirect; otherwise configure that redirect at Hostinger's domain layer and retest. A successful local gate is not a successful live deployment. The verification script uses simulated user agents and cannot establish genuine crawler visits, indexing or AI citations.

## Design System

The interface uses a dark industrial visual style designed for a US trucking company.

| Role | Value |
| --- | --- |
| Background | `#0a0a0a`, `#0d0d0d` |
| Surface | `#141414`, `#1a1a1a` |
| Accent | `#FF6B00` |
| Primary text | `#f0f0f0` |
| Dim text | `#9a9a9a` |
| Muted text | `#6a6a6a` |
| Headings | Anton |
| Navigation and labels | Oswald |
| Body copy | Inter |

Mobile-specific spacing and line-height adjustments keep headings and content readable without changing the desktop design.

## Tech Stack

- Next.js 16 with the App Router
- React 19
- TypeScript
- Tailwind CSS 3
- Lightweight native icon symbols
- Google Fonts

## Getting Started

Requirements:

- Node.js 20.9 or newer
- npm

Install dependencies and start the development server:

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Available Scripts

```bash
npm run dev     # Start the development server
npm run build   # Create an optimized production build
npm run start   # Run the production build
npm run lint    # Run ESLint
npm run typecheck # Check TypeScript
npm test        # Run server validation tests
npm run db:generate # Generate a Drizzle migration
npm run db:migrate  # Apply committed migrations
npm run db:seed     # Idempotently import the original site content
```

## Project Structure

```text
app/
  globals.css       Global design system and shared effects
  layout.tsx        Metadata, fonts, icons, and root layout
  page.tsx          Database-backed public page entry
  admin/            Protected admin routes and server actions
src/
  components/       Website sections and reusable UI components
  data/             Original site content retained as the seed source
  db/               Drizzle schema and shared PostgreSQL client
  lib/cms/          Typed public CMS queries and validation
  hooks/            Active-section tracking hook
scripts/
  seed-cms.ts       Idempotent content migration
drizzle/            Versioned SQL migrations
```

The `@/*` TypeScript alias maps to `src/*`, so components and hooks can be imported as `@/components/...` and `@/hooks/...`.

## Main Components

- `TopBar`, `Navbar`, and `MobileNav` — site navigation
- `Hero` and `MarqueeBanner` — introduction and service highlights
- `About`, `Services`, and `TruckTypes` — company and capability content
- `AgreementPricing`, `AgreementModal`, and `HowItWorks` — carrier terms and onboarding
- `Contact`, `Toast`, and `Footer` — lead capture and footer content

## Customization

- Use the protected admin modules for implemented editing workflows. `src/data/content.ts` remains the migration source and must not be deleted yet.
- Update shared colors, effects, and responsive rules in `app/globals.css`.
- Update page title and description in `app/layout.tsx`.

## Production

Create `.env.local` from `.env.example` and set:

- `DATABASE_URL` to the Supabase PostgreSQL transaction-pooler connection string.
- `NEXT_PUBLIC_SUPABASE_URL` to the Supabase project URL.
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` to the project publishable key.

Apply the database migration, then seed the original content:

```bash
npm run db:migrate
npm run db:seed
```

Create an email/password user in Supabase Authentication, then approve that
user in the database:

```bash
npm run admin:grant -- admin@example.com
```

Add the same variables to the Vercel project. The Supabase URL and publishable
key are designed to be public; `DATABASE_URL` must remain server-only. Supabase
stores and refreshes the admin session in cookies. Every protected page and
mutation verifies both the Auth user and the active `admin_users` database row.

The seed uses stable singleton IDs and unique entity keys, so it can be run
repeatedly without inserting duplicates. It intentionally does not overwrite
later admin edits.

The current admin routes are `/admin`, `/admin/content`, `/admin/services`,
`/admin/truck-types`, `/admin/pricing`, `/admin/reviews`, `/admin/media`,
`/admin/leads`, `/admin/settings`, and `/admin/audit`. CMS editing, moderation,
lead management, audit logging and media safety are implemented. See
[systemflow.md](./systemflow.md) for the current architecture and operational flows.

The SMS consent copy is implementation text and should be reviewed by legal
counsel before production use.

## Build

Create and run a local production build:

```bash
npm run build
npm run start
```

The application can be deployed to any platform that supports Next.js, including Vercel.
