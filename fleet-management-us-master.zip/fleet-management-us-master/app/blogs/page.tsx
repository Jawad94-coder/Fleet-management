import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { CmsProvider } from "@/components/CmsProvider";
import Footer from "@/components/layout/Footer";
import SubpageBreadcrumb from "@/components/layout/SubpageBreadcrumb";
import SubpageNavbar from "@/components/layout/SubpageNavbar";
import TopBar from "@/components/layout/TopBar";
import { getPublishedBlogs } from "@/lib/blog-queries";
import { getSiteContent } from "@/lib/cms/queries";
import { bypassImageOptimization } from "@/lib/image";
import { absoluteUrl, breadcrumbJsonLd, pageMetadata } from "@/lib/seo";
import JsonLd from "@/components/seo/JsonLd";

export const revalidate = 300;
export async function generateMetadata():Promise<Metadata>{const{sectionCopy:copy}=await getSiteContent();return pageMetadata(copy.blogsSeoTitle,copy.blogsSeoDescription,"/blogs");}

export default async function BlogsPage() {
  const [posts,content]=await Promise.all([getPublishedBlogs(),getSiteContent()]);
  const copy=content.sectionCopy;return <CmsProvider content={content}><TopBar/><SubpageNavbar/><SubpageBreadcrumb parentHref="/#home" parentLabel={copy.breadcrumbHomeLabel} currentLabel={copy.blogBreadcrumbLabel} rootOnly/><main>
    <JsonLd data={breadcrumbJsonLd([{name:content.company.name,item:absoluteUrl("/")},{name:"Trucking guides",item:absoluteUrl("/blogs")}])}/>
    <section className="relative overflow-hidden border-b border-[#1a1a1a] py-10 sm:py-14"><div className="absolute inset-0 grid-bg opacity-50"/><div className="relative site-container"><span className="section-label">{copy.blogsLabel}</span><h1 className="mt-6 font-display text-5xl leading-none sm:text-7xl lg:text-8xl">{copy.blogsHeading} <span className="accent-text">{copy.blogsHeadingAccent}</span></h1><p className="mt-6 max-w-2xl text-lg leading-relaxed text-[#9a9a9a]">{copy.blogsDescription}</p></div></section>
    <section className="bg-[#0d0d0d] py-16 sm:py-24"><div className="site-container">{posts.length===0?<div className="border border-dashed border-[#363636] px-6 py-20 text-center"><i className="fas fa-newspaper text-3xl text-[#4a4a4a]" aria-hidden="true"/><h2 className="mt-4 font-display text-3xl">{copy.blogsEmptyTitle}</h2><p className="mt-3 text-[#9a9a9a]">{copy.blogsEmptyDescription}</p></div>:<div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">{posts.map(post=><article key={post.id} className="group flex flex-col border border-[#242424] bg-[#141414] transition hover:border-[#454545]">{post.featuredImage&&<Link href={`/blogs/${post.slug}`} aria-label={`${copy.blogsReadMoreLabel} ${post.title}`} className="relative block h-56 overflow-hidden bg-[#0a0a0a]"><Image src={post.featuredImage} alt={post.featuredImageAlt?.trim() || `${post.title} featured image`} fill sizes="(max-width: 768px) 100vw, (max-width: 1280px) 50vw, 33vw" unoptimized={bypassImageOptimization(post.featuredImage)} className="object-cover transition duration-500 group-hover:scale-105" /></Link>}<div className="flex flex-1 flex-col p-6"><div className="font-cond text-[10px] uppercase tracking-[.2em] text-accent">{post.category}</div><h2 className="mt-4 font-display text-3xl leading-tight"><Link href={`/blogs/${post.slug}`} className="transition hover:text-accent">{post.title.toUpperCase()}</Link></h2>{post.excerpt&&<p className="mt-4 line-clamp-3 leading-relaxed text-[#9a9a9a]">{post.excerpt}</p>}<div className="mt-auto pt-6 text-xs text-[#777]"><span>{post.author}</span><span className="mx-2">·</span><time dateTime={(post.publishedAt??post.createdAt).toISOString()}>{(post.publishedAt??post.createdAt).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}</time><span className="mx-2">·</span><span>{post.readingTime} {copy.blogReadingTimeSuffix}</span></div><Link href={`/blogs/${post.slug}`} className="mt-5 font-cond text-xs uppercase tracking-[.18em] text-accent">{copy.blogsReadMoreLabel} <i className="fas fa-arrow-right ml-2"/></Link></div></article>)}</div>}</div></section>
  </main><Footer/></CmsProvider>;
}
