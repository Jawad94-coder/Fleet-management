import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { cache } from "react";
import BlogMarkdown from "@/components/blog/BlogMarkdown";
import { CmsProvider } from "@/components/CmsProvider";
import Footer from "@/components/layout/Footer";
import SubpageBreadcrumb from "@/components/layout/SubpageBreadcrumb";
import SubpageNavbar from "@/components/layout/SubpageNavbar";
import TopBar from "@/components/layout/TopBar";
import JsonLd from "@/components/seo/JsonLd";
import { getPublishedBlogBySlug, getPublishedBlogs } from "@/lib/blog-queries";
import { getSiteContent } from "@/lib/cms/queries";
import { isValidSlug } from "@/lib/cms/validation";
import { absoluteUrl, breadcrumbJsonLd, organizationId, pageMetadata, truncateDescription } from "@/lib/seo";
import { bypassImageOptimization } from "@/lib/image";

interface BlogPageProps { params: Promise<{ slug: string }> }
export const revalidate = 300;

export async function generateStaticParams() {
  return (await getPublishedBlogs()).map(({ slug }) => ({ slug }));
}

const getBlogPage = cache(async (slug: string) => {
  if (!isValidSlug(slug)) notFound();
  const post = await getPublishedBlogBySlug(slug);
  if (!post) notFound();
  return post;
});

export async function generateMetadata({params}:BlogPageProps):Promise<Metadata>{const{slug}=await params;const post=await getBlogPage(slug);const title=post.seoTitle?.trim()||post.title;const description=truncateDescription(post.seoDescription?.trim()||post.excerpt||post.title);const canonical=absoluteUrl(`/blogs/${post.slug}`);return{...pageMetadata(title,description,`/blogs/${post.slug}`,post.featuredImage??undefined),openGraph:{title,description,type:"article",url:canonical,siteName:"Fleet Management US",locale:"en_US",publishedTime:post.publishedAt?.toISOString(),modifiedTime:post.updatedAt.toISOString(),images:post.featuredImage?[{url:absoluteUrl(post.featuredImage),alt:post.featuredImageAlt?.trim()||`${post.title} featured image`}]:undefined}};}

export default async function BlogPage({params}:BlogPageProps){const{slug}=await params;const[post,content]=await Promise.all([getBlogPage(slug),getSiteContent()]);const date=post.publishedAt??post.createdAt;const copy=content.sectionCopy;const canonical=absoluteUrl(`/blogs/${post.slug}`);const relationshipLabels=[post.category,...post.tags].map(label=>label.toLowerCase());const relatedServices=content.services.filter(service=>relationshipLabels.some(label=>label.length>=4&&service.title.toLowerCase().includes(label))).slice(0,4);return <CmsProvider content={content}><JsonLd data={[{"@context":"https://schema.org","@type":"BlogPosting","@id":`${canonical}#article`,mainEntityOfPage:canonical,headline:post.title,description:post.excerpt||post.seoDescription||post.title,datePublished:date.toISOString(),dateModified:post.updatedAt.toISOString(),...(post.author?.trim()?{author:post.author===content.company.name?{"@type":"Organization","@id":organizationId,name:post.author}:{"@type":"Person",name:post.author}}:{}),image:post.featuredImage?absoluteUrl(post.featuredImage):undefined,publisher:{"@type":"Organization","@id":organizationId,name:content.company.name,logo:{"@type":"ImageObject",url:absoluteUrl(content.company.logo)}},keywords:post.tags.join(", ")},breadcrumbJsonLd([{name:content.company.name,item:absoluteUrl("/")},{name:copy.blogBreadcrumbLabel,item:absoluteUrl("/blogs")},{name:post.title,item:canonical}])]} /><TopBar/><SubpageNavbar/><SubpageBreadcrumb parentHref="/blogs" parentLabel={copy.blogBreadcrumbLabel} currentLabel={post.title}/><main>
  <article><header className="relative overflow-hidden border-b border-[#1a1a1a] py-10 sm:py-14"><div className="absolute inset-0 grid-bg opacity-50"/><div className="relative site-container"><span className="section-label">{post.category}</span><h1 className="mt-6 max-w-5xl break-words font-display text-5xl leading-[.98] sm:text-7xl lg:text-8xl">{post.title.toUpperCase()}</h1>{post.excerpt&&<p className="mt-7 max-w-3xl text-lg leading-relaxed text-[#aaa] sm:text-xl">{post.excerpt}</p>}<div className="mt-7 font-cond text-xs uppercase tracking-[.15em] text-[#777]">{post.author?.trim()&&<><span>{post.author}</span><span className="mx-3 text-accent">/</span></>}<time dateTime={date.toISOString()}>{date.toLocaleDateString("en-US",{month:"long",day:"numeric",year:"numeric"})}</time><span className="mx-3 text-accent">/</span><span>{post.readingTime} {copy.blogReadingTimeSuffix}</span></div></div></header>
  {post.featuredImage&&<div className="site-container pt-10 sm:pt-16"><div className="relative h-[40vw] min-h-64 max-h-[620px] w-full"><Image src={post.featuredImage} alt={post.featuredImageAlt?.trim()||`${post.title} featured image`} fill sizes="(max-width: 1280px) 100vw, 1280px" unoptimized={bypassImageOptimization(post.featuredImage)} className="object-cover" /></div></div>}
  <section className="py-12 sm:py-20"><div className="mx-auto max-w-3xl px-4 sm:px-6"><BlogMarkdown body={post.body}/>{post.tags.length>0&&<div className="mt-12 border-t border-[#242424] pt-7"><span className="font-cond text-xs uppercase tracking-[.18em] text-[#777]">{copy.blogTagsLabel}</span><div className="mt-3 flex flex-wrap gap-2">{post.tags.map(tag=><span key={tag} className="tag">{tag}</span>)}</div></div>}{relatedServices.length>0&&<aside className="mt-10 border border-[#242424] bg-[#141414] p-6"><h2 className="font-display text-2xl">RELATED SERVICES</h2><div className="mt-4 flex flex-wrap gap-3">{relatedServices.map(service=><Link key={service.slug} href={`/services/${service.slug}`} className="tag transition hover:border-accent hover:text-accent">{service.title}</Link>)}</div></aside>}</div></section></article>
  <section className="site-container pb-16"><h2 className="font-display text-3xl">Discuss your dispatch needs</h2><p className="mt-4 max-w-3xl leading-relaxed text-[#a8a8a8]">Compare <Link className="text-accent underline" href="/services/dispatch-services">dispatch services</Link> and <Link className="text-accent underline" href="/services/load-assistance">load assistance</Link>, then <Link className="text-accent underline" href="/#contact">send your equipment and lane details</Link> through our carrier enquiry form.</p></section></main><Footer/></CmsProvider>}
