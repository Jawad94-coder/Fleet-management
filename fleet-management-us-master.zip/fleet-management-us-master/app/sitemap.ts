import type { MetadataRoute } from "next";
import { getPublishedBlogs } from "@/lib/blog-queries";
import { getServices, getTruckTypes } from "@/lib/cms/queries";

import { siteUrl } from "@/lib/seo";

export const revalidate = 300;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [services, truckTypes, posts] = await Promise.all([
    getServices(),
    getTruckTypes(),
    getPublishedBlogs(),
  ]);

  return [
    { url: new URL("/", siteUrl).href, changeFrequency: "weekly", priority: 1 },
    { url: new URL("/blogs", siteUrl).href, changeFrequency: "weekly", priority: 0.8 },
    ...services.map(({ slug, updatedAt }) => ({
      url: new URL(`/services/${slug}`, siteUrl).href,
      lastModified: updatedAt,
      changeFrequency: "monthly" as const,
      priority: 0.8,
    })),
    ...truckTypes.map(({ slug, updatedAt }) => ({
      url: new URL(`/truck-types/${slug}`, siteUrl).href,
      lastModified: updatedAt,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })),
    ...posts.map(({ slug, updatedAt }) => ({
      url: new URL(`/blogs/${slug}`, siteUrl).href,
      lastModified: updatedAt,
      changeFrequency: "monthly" as const,
      priority: 0.6,
    })),
  ];
}
