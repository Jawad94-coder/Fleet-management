import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { loginAdmin } from "../actions";
import { isAdminAuthenticated } from "@/lib/admin-auth";
import SubmitButton from "@/components/admin/SubmitButton";

export const metadata: Metadata = {
  title: "Admin Login | Fleet Management US",
  robots: { index: false, follow: false },
};

interface LoginPageProps {
  searchParams: Promise<{ error?: string }>;
}

export default async function AdminLoginPage({ searchParams }: LoginPageProps) {
  if (await isAdminAuthenticated()) redirect("/admin");

  const error = (await searchParams).error;
  const message =
    error === "config"
      ? "Supabase Auth is not configured. Add the project URL and publishable key."
      : error === "invalid"
        ? "Incorrect email or password."
        : error === "forbidden"
          ? "This account is not approved for admin access."
          : null;

  return (
    <main className="grid-bg min-h-screen px-4 py-16 flex items-center justify-center">
      <section className="w-full max-w-md border border-[#242424] bg-[#141414] p-7 sm:p-10 shadow-2xl">
        <div className="mb-8 flex h-12 w-12 items-center justify-center border border-accent/40 bg-accent/10 text-accent">
          <i className="fas fa-lock" aria-hidden="true"></i>
        </div>
        <p className="font-cond text-xs uppercase tracking-[0.25em] text-accent">
          Fleet Management US
        </p>
        <h1 className="font-display mt-3 text-4xl">ADMIN ACCESS</h1>
        <p className="mt-3 text-sm leading-relaxed text-[#9a9a9a]">
          Sign in with your approved Supabase administrator account.
        </p>

        <form action={loginAdmin} className="mt-8">
          <label
            htmlFor="email"
            className="font-cond mb-2 block text-[11px] uppercase tracking-[0.2em] text-[#9a9a9a]"
          >
            Email address
          </label>
          <input
            id="email"
            name="email"
            type="email"
            required
            autoComplete="username"
            maxLength={320}
            className="form-input mb-5 w-full px-4 py-3 text-sm"
          />
          <label
            htmlFor="password"
            className="font-cond mb-2 block text-[11px] uppercase tracking-[0.2em] text-[#9a9a9a]"
          >
            Password
          </label>
          <input
            id="password"
            name="password"
            type="password"
            required
            autoComplete="current-password"
            className="form-input w-full px-4 py-3 text-sm"
          />
          {message && (
            <p role="alert" className="mt-3 text-sm text-red-400">
              {message}
            </p>
          )}
          <SubmitButton
            pendingLabel="Signing in..."
            className="btn-primary font-cond mt-6 w-full py-3 uppercase tracking-wider"
          >
            Sign in
          </SubmitButton>
        </form>
      </section>
    </main>
  );
}
