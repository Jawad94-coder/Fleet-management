"use server";

import { and, eq, inArray, isNull } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getDb } from "@/db";
import {
  adminAuditRecords,
  adminUsers,
  applicationStatuses,
  carrierApplications,
  type ApplicationStatus,
} from "@/db/schema";
import { selectedIds, requireConfirmation } from "@/lib/cms/admin-validation";
import { requireAdmin } from "@/lib/admin-auth";
import { createSupabaseServerClient, supabaseAuthIsConfigured } from "@/lib/supabase/server";

export async function loginAdmin(formData: FormData) {
  const email = formData.get("email");
  const password = formData.get("password");

  if (!supabaseAuthIsConfigured()) {
    redirect("/admin/login?error=config");
  }

  if (
    typeof email !== "string" ||
    email.length > 320 ||
    typeof password !== "string" ||
    !password ||
    password.length > 4096
  ) {
    redirect("/admin/login?error=invalid");
  }

  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error || !data.user) redirect("/admin/login?error=invalid");

  const [admin] = await getDb()
    .select({ id: adminUsers.userId })
    .from(adminUsers)
    .where(and(eq(adminUsers.userId, data.user.id), eq(adminUsers.active, true)))
    .limit(1);
  if (!admin) {
    await supabase.auth.signOut({ scope: "local" });
    redirect("/admin/login?error=forbidden");
  }

  await getDb().insert(adminAuditRecords).values({
    action: "signed_in",
    entityType: "admin_user",
    entityId: data.user.id,
    summary: "Admin signed in.",
    actor: data.user.id,
  });
  redirect("/admin");
}

export async function logoutAdmin() {
  if (supabaseAuthIsConfigured()) {
    await (await createSupabaseServerClient()).auth.signOut({ scope: "local" });
  }
  redirect("/admin/login");
}

export interface LeadStatusFormState {
  success?: string;
  error?: string;
}

export async function updateApplicationStatus(
  _state: LeadStatusFormState,
  formData: FormData,
): Promise<LeadStatusFormState> {
  const admin = await requireAdmin();

  const id = Number(formData.get("id"));
  const status = formData.get("status");
  if (
    !Number.isSafeInteger(id) ||
    id <= 0 || id > 2147483647 ||
    typeof status !== "string" ||
    !applicationStatuses.includes(status as ApplicationStatus)
  ) {
    return { error: "Invalid status update." };
  }

  try {
    await getDb().transaction(async (tx) => {
      const [updated] = await tx
        .update(carrierApplications)
        .set({ status: status as ApplicationStatus, updatedAt: new Date() })
        .where(and(eq(carrierApplications.id, id), isNull(carrierApplications.deletedAt)))
        .returning({ id: carrierApplications.id });
      if (!updated) throw new Error("Carrier application not found.");
      await tx.insert(adminAuditRecords).values({
        action: "status_changed",
        entityType: "carrier_application",
        entityId: String(id),
        summary: `Carrier application moved to ${status}.`,
        actor: admin.id,
      });
    });
  } catch {
    console.error("Carrier status update failed.");
    return { error: "Status could not be saved." };
  }

  revalidatePath("/admin");
  revalidatePath("/admin/leads", "layout");
  return { success: "Saved." };
}

export async function updateLeadDetails(_state: LeadStatusFormState, formData: FormData): Promise<LeadStatusFormState> {
  const admin=await requireAdmin();const id=Number(formData.get("id"));const status=formData.get("status");const notes=typeof formData.get("internalNotes")==="string"?String(formData.get("internalNotes")).trim():"";
  if(!Number.isSafeInteger(id)||id<=0||id>2147483647||typeof status!=="string"||!applicationStatuses.includes(status as ApplicationStatus)||notes.length>5000)return{error:"Invalid lead update."};
  try{await getDb().transaction(async tx=>{const [lead]=await tx.update(carrierApplications).set({status:status as ApplicationStatus,internalNotes:notes||null,updatedAt:new Date()}).where(and(eq(carrierApplications.id,id),isNull(carrierApplications.deletedAt))).returning({name:carrierApplications.fullName});if(!lead)throw new Error("Lead not found.");await tx.insert(adminAuditRecords).values({action:"lead_updated",entityType:"carrier_application",entityId:String(id),summary:`Updated lead; status ${status}.`,actor:admin.id});});revalidatePath("/admin");revalidatePath("/admin/leads", "layout");return{success:"Lead details saved."};}catch{console.error("Lead update failed.");return{error:"Lead details could not be saved."};}
}

export async function archiveLead(formData: FormData): Promise<void> {const admin=await requireAdmin();requireConfirmation(formData);const id=Number(formData.get("id"));if(!Number.isSafeInteger(id)||id<=0||id>2147483647)throw new Error("Invalid lead ID.");await getDb().transaction(async tx=>{const [lead]=await tx.update(carrierApplications).set({deletedAt:new Date(),updatedAt:new Date()}).where(and(eq(carrierApplications.id,id),isNull(carrierApplications.deletedAt))).returning({name:carrierApplications.fullName});if(!lead)throw new Error("Lead not found.");await tx.insert(adminAuditRecords).values({action:"lead_archived",entityType:"carrier_application",entityId:String(id),summary:"Archived lead.",actor:admin.id});});revalidatePath("/admin");revalidatePath("/admin/leads", "layout");}

export async function bulkLeadAction(formData: FormData): Promise<void> {const admin=await requireAdmin();const ids=selectedIds(formData);const requested=formData.get("bulkStatus");if(!ids.length||typeof requested!=="string")throw new Error("Select leads and a valid action.");const archive=requested==="archived";if(archive||requested==="rejected")requireConfirmation(formData);if(!archive&&!applicationStatuses.includes(requested as ApplicationStatus))throw new Error("Invalid lead status.");await getDb().transaction(async tx=>{const rows=await tx.update(carrierApplications).set(archive?{deletedAt:new Date(),updatedAt:new Date()}:{status:requested as ApplicationStatus,updatedAt:new Date()}).where(and(inArray(carrierApplications.id,ids),isNull(carrierApplications.deletedAt))).returning({id:carrierApplications.id});if(rows.length!==ids.length)throw new Error("Some leads were not found.");await tx.insert(adminAuditRecords).values(ids.map(id=>({action:archive?"bulk_lead_archived":"bulk_lead_status",entityType:"carrier_application",entityId:String(id),summary:archive?"Archived lead in bulk.":`Changed lead to ${requested} in bulk.`,actor:admin.id})));});revalidatePath("/admin");revalidatePath("/admin/leads", "layout");}
