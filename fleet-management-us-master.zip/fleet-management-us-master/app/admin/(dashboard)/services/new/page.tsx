import AdminPageHeader from "@/components/admin/AdminPageHeader";
import ServiceForm from "@/components/admin/ServiceForm";
import { asc, isNull } from "drizzle-orm";
import { getDb } from "@/db";
import { mediaAssets } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
export default async function NewServicePage() { await requireAdmin();const media=await getDb().select({path:mediaAssets.path,fileName:mediaAssets.fileName}).from(mediaAssets).where(isNull(mediaAssets.deletedAt)).orderBy(asc(mediaAssets.fileName));return <><AdminPageHeader eyebrow="Services" title="NEW SERVICE" description="New services can be saved as drafts before publishing."/><ServiceForm media={media}/></>; }
