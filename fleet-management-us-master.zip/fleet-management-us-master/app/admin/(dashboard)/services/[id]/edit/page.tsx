import { and, asc, eq, isNull } from "drizzle-orm";
import { notFound } from "next/navigation";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import ServiceForm from "@/components/admin/ServiceForm";
import { getDb } from "@/db";
import { mediaAssets, services } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
export default async function EditServicePage({ params }: { params: Promise<{ id: string }> }) { await requireAdmin(); const id=Number((await params).id); if(!Number.isSafeInteger(id)||id<1||id>2147483647) notFound(); const [rows,media]=await Promise.all([getDb().select().from(services).where(and(eq(services.id,id),isNull(services.deletedAt))).limit(1),getDb().select({path:mediaAssets.path,fileName:mediaAssets.fileName}).from(mediaAssets).where(isNull(mediaAssets.deletedAt)).orderBy(asc(mediaAssets.fileName))]);const row=rows[0]; if(!row) notFound(); return <><AdminPageHeader eyebrow="Services" title={`EDIT ${row.title.toUpperCase()}`} description="Changing the slug creates a permanent redirect from the previous URL."/><ServiceForm media={media} service={{id:row.id,num:row.num,slug:row.slug,icon:row.icon,image:row.image??undefined,imageAlt:row.imageAlt??undefined,title:row.title,desc:row.description,ctaLabel:row.ctaLabel,ctaHref:row.ctaHref,detail:row.detail,seoTitle:row.seoTitle,seoDescription:row.seoDescription,seoKeywords:row.seoKeywords,sortOrder:row.sortOrder,status:row.status}}/></>; }
