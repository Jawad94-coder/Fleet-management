"use client";

import { useEffect } from "react";

export default function AdminError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error("Admin page failed.", {digest:error.digest});
  }, [error]);

  return (
    <section className="border border-red-500/30 bg-red-500/5 p-8" role="alert">
      <p className="font-cond text-xs uppercase tracking-[0.2em] text-red-400">Unable to load</p>
      <h1 className="font-display mt-3 text-3xl">ADMIN DATA ERROR</h1>
      <p className="mt-3 max-w-xl text-sm leading-relaxed text-[#9a9a9a]">
        The requested admin data could not be loaded. Check the database connection and try again.
      </p>
      <button type="button" onClick={reset} className="btn-primary font-cond mt-6 px-5 py-3 text-xs uppercase tracking-wider">
        Try again
      </button>
    </section>
  );
}
