import Link from "next/link";
import { and, desc, eq, ilike, or } from "drizzle-orm";
import AdminEmptyState from "@/components/admin/AdminEmptyState";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import BlogStatusForm from "@/components/admin/BlogStatusForm";
import DeleteConfirmation from "@/components/admin/DeleteConfirmation";
import { getDb } from "@/db";
import { blogPosts, blogStatuses, type BlogStatus } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { archiveBlog, setBlogStatus } from "./actions";

const labels: Record<BlogStatus,string> = { draft: "Draft", published: "Published", archived: "Archived" };

export default async function BlogsPage({ searchParams }: { searchParams: Promise<{ status?: string; q?: string }> }) {
  await requireAdmin(); const params = await searchParams;
  const status = blogStatuses.includes(params.status as BlogStatus) ? params.status as BlogStatus : null;
  const query = typeof params.q === "string" ? params.q.trim().slice(0,160) : "";
  const search = query ? or(ilike(blogPosts.title, `%${query}%`), ilike(blogPosts.excerpt, `%${query}%`), ilike(blogPosts.author, `%${query}%`), ilike(blogPosts.category, `%${query}%`)) : undefined;
  const posts = await getDb().select({id:blogPosts.id,title:blogPosts.title,slug:blogPosts.slug,excerpt:blogPosts.excerpt,category:blogPosts.category,author:blogPosts.author,status:blogPosts.status,updatedAt:blogPosts.updatedAt}).from(blogPosts).where(and(status ? eq(blogPosts.status,status) : undefined, search)).orderBy(desc(blogPosts.updatedAt));
  return <><AdminPageHeader eyebrow="Publishing" title="BLOGS" description="Create, edit, publish, unpublish, or archive public blog posts." action={<Link href="/admin/blogs/new" className="btn-primary px-6 py-3 font-cond text-xs uppercase tracking-wider">Add blog</Link>}/>
    <form className="mb-5 grid gap-3 sm:grid-cols-[1fr_auto]" role="search">{status&&<input type="hidden" name="status" value={status}/>}<input name="q" defaultValue={query} placeholder="Search title, excerpt, author, or category" aria-label="Search blogs" className="form-input px-4 py-3"/><button className="btn-secondary px-5 py-3">Search</button></form>
    <nav className="mb-5 flex flex-wrap gap-2" aria-label="Filter blogs"><Filter href={`/admin/blogs${query?`?q=${encodeURIComponent(query)}`:""}`} active={!status}>All</Filter>{blogStatuses.map(value=><Filter key={value} href={`/admin/blogs?status=${value}${query?`&q=${encodeURIComponent(query)}`:""}`} active={status===value}>{labels[value]}</Filter>)}</nav>
    {!posts.length?<AdminEmptyState title="No blog posts found" description="Create a draft, then publish it when it is ready for the public website."/>:<div className="overflow-x-auto border border-[#242424] bg-[#141414]"><table className="w-full min-w-[950px] text-left text-sm"><thead className="bg-[#0d0d0d] font-cond text-[10px] uppercase tracking-[.18em] text-[#6a6a6a]"><tr><th className="px-4 py-3">Post</th><th className="px-4 py-3">Category</th><th className="px-4 py-3">Author</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Updated</th><th className="px-4 py-3">Actions</th></tr></thead><tbody className="divide-y divide-[#242424]">{posts.map(post=><tr key={post.id} className="align-top"><td className="max-w-md px-4 py-5"><strong>{post.title}</strong><span className="mt-1 block text-xs text-[#777]">/{post.slug}</span>{post.excerpt&&<span className="mt-2 block text-xs text-[#999]">{post.excerpt.length>120?`${post.excerpt.slice(0,120)}…`:post.excerpt}</span>}</td><td className="px-4 py-5">{post.category}</td><td className="px-4 py-5">{post.author}</td><td className="px-4 py-5">{post.status==="archived"?<span className="tag">Archived</span>:<BlogStatusForm id={post.id} status={post.status} action={setBlogStatus}/>}</td><td className="whitespace-nowrap px-4 py-5 text-xs text-[#777]">{post.updatedAt.toLocaleDateString("en-US")}</td><td className="px-4 py-5"><div className="flex gap-2"><Link href={`/admin/blogs/${post.id}/edit`} className="btn-secondary px-3 py-2 text-xs">Open</Link>{post.status!=="archived"&&<DeleteConfirmation action={archiveBlog} id={post.id} itemName={post.title}/>}</div></td></tr>)}</tbody></table></div>}
  </>;
}

function Filter({href,active,children}:{href:string;active:boolean;children:React.ReactNode}) { return <Link href={href} className={`border px-4 py-2 text-xs ${active?"border-accent bg-accent text-black":"border-[#363636] text-[#aaa]"}`}>{children}</Link>; }
