import { asc, eq, isNull } from "drizzle-orm";
import { notFound } from "next/navigation";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import BlogForm from "@/components/admin/BlogForm";
import { getDb } from "@/db";
import { blogPosts, mediaAssets } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";

export default async function EditBlogPage({ params }: { params: Promise<{ id: string }> }) {
  await requireAdmin(); const raw = (await params).id; if(!/^\d+$/.test(raw)) notFound(); const id=Number(raw);
  const [rows,media]=await Promise.all([getDb().select().from(blogPosts).where(eq(blogPosts.id,id)).limit(1),getDb().select({path:mediaAssets.path,fileName:mediaAssets.fileName}).from(mediaAssets).where(isNull(mediaAssets.deletedAt)).orderBy(asc(mediaAssets.fileName))]);
  const post=rows[0]; if(!post) notFound();
  return <><AdminPageHeader eyebrow="Blogs" title={`EDIT ${post.title.toUpperCase()}`} description="Published changes appear publicly after saving."/><BlogForm post={post} media={media}/></>;
}
