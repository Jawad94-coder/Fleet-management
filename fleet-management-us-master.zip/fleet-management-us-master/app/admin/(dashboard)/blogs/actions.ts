"use server";

import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { getDb } from "@/db";
import { adminAuditRecords, blogPosts } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { actionError, idFrom, requireConfirmation, ValidationError, type CmsFormState } from "@/lib/cms/admin-validation";
import { blogStatusFrom, validateBlog } from "@/lib/cms/blog-validation";
import { lockContent } from "@/lib/cms/media-safety";
import { cleanupUpload, persistImage, prepareImage, removeReplacedImage } from "@/lib/cms/image-save";

function refreshBlogs(...slugs: (string | null | undefined)[]) {
  revalidatePath("/admin/blogs");
  revalidatePath("/blogs");
  for (const slug of slugs) if (slug) revalidatePath(`/blogs/${slug}`);
}

export async function saveBlog(_state: CmsFormState, formData: FormData): Promise<CmsFormState> {
  const admin = await requireAdmin();
  let prepared: Awaited<ReturnType<typeof prepareImage>> = null;
  let bodyImage: Awaited<ReturnType<typeof prepareImage>> = null;
  let saved = false; let oldSlug: string | null = null;
  let oldImage: string | null = null;
  try {
    const id = idFrom(formData);
    const values = validateBlog(formData);
    prepared=await prepareImage(formData,"featuredImage","blogs");
    bodyImage=await prepareImage(formData,"bodyImage","blogs");
    values.featuredImage=prepared?.url??null;values.featuredImageAlt=prepared?.alt??null;
    if(bodyImage)values.body+=`\n\n![${bodyImage.alt}](${bodyImage.url})`;
    await getDb().transaction(async tx => {
      await lockContent(tx);
      await persistImage(tx,prepared,admin.id);
      await persistImage(tx,bodyImage,admin.id);
      if (id) {
        const [old] = await tx.select({ slug: blogPosts.slug,image:blogPosts.featuredImage }).from(blogPosts).where(eq(blogPosts.id, id)).limit(1);
        if (!old) throw new ValidationError("Blog post not found.");
        oldSlug = old.slug;oldImage=old.image;
        await tx.update(blogPosts).set({ ...values, updatedAt: new Date(), updatedBy: admin.id }).where(eq(blogPosts.id, id));
        await tx.insert(adminAuditRecords).values({ action: "updated", entityType: "blog", entityId: String(id), summary: `Updated blog ${values.title}.`, actor: admin.id });
      } else {
        const [created] = await tx.insert(blogPosts).values({ ...values, createdBy: admin.id, updatedBy: admin.id }).returning({ id: blogPosts.id });
        await tx.insert(adminAuditRecords).values({ action: "created", entityType: "blog", entityId: String(created.id), summary: `Created ${values.status} blog ${values.title}.`, actor: admin.id });
      }
    });
    saved = true;await removeReplacedImage(oldImage,values.featuredImage,admin.id).catch(console.error);refreshBlogs(oldSlug, values.slug);
    return { success: "Blog post saved." };
  } catch (error) {
    if (!saved) {await cleanupUpload(prepared);await cleanupUpload(bodyImage);}
    return actionError(error);
  }
}

export async function setBlogStatus(formData: FormData): Promise<void> {
  const admin = await requireAdmin(); const id = idFrom(formData, true)!; const status = blogStatusFrom(formData);
  if (status === "archived") throw new ValidationError("Use Remove to archive a blog post.");
  let slug = "";
  await getDb().transaction(async tx => {
    await lockContent(tx);
    const [post] = await tx.select({ slug: blogPosts.slug, publishedAt: blogPosts.publishedAt }).from(blogPosts).where(eq(blogPosts.id, id)).limit(1);
    if (!post) throw new ValidationError("Blog post not found.");
    slug = post.slug;
    await tx.update(blogPosts).set({ status, publishedAt: status === "published" ? post.publishedAt ?? new Date() : post.publishedAt, updatedAt: new Date(), updatedBy: admin.id }).where(eq(blogPosts.id, id));
    await tx.insert(adminAuditRecords).values({ action: status === "published" ? "published" : "unpublished", entityType: "blog", entityId: String(id), summary: `${status === "published" ? "Published" : "Unpublished"} blog ${post.slug}.`, actor: admin.id });
  });
  refreshBlogs(slug);
}

export async function archiveBlog(formData: FormData): Promise<void> {
  const admin = await requireAdmin(); requireConfirmation(formData); const id = idFrom(formData, true)!; let slug = "";
  await getDb().transaction(async tx => {
    await lockContent(tx);
    const [post] = await tx.update(blogPosts).set({ status: "archived", updatedAt: new Date(), updatedBy: admin.id }).where(eq(blogPosts.id, id)).returning({ slug: blogPosts.slug, title: blogPosts.title });
    if (!post) throw new ValidationError("Blog post not found."); slug = post.slug;
    await tx.insert(adminAuditRecords).values({ action: "archived", entityType: "blog", entityId: String(id), summary: `Archived blog ${post.title}.`, actor: admin.id });
  });
  refreshBlogs(slug);
}
