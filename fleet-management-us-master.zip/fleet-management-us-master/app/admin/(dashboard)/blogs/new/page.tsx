import { asc, isNull } from "drizzle-orm";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import BlogForm from "@/components/admin/BlogForm";
import { getDb } from "@/db";
import { mediaAssets } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";

export default async function NewBlogPage() {
  await requireAdmin(); const media = await getDb().select({ path: mediaAssets.path, fileName: mediaAssets.fileName }).from(mediaAssets).where(isNull(mediaAssets.deletedAt)).orderBy(asc(mediaAssets.fileName));
  return <><AdminPageHeader eyebrow="Blogs" title="NEW BLOG" description="Save a draft or publish it immediately."/><BlogForm media={media}/></>;
}
