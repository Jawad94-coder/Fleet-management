"use server";

import { and, eq, isNull } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { getDb } from "@/db";
import {
  aboutContent,
  aboutFeatures,
  adminAuditRecords,
  agreementDocument,
  agreementRevisions,
  agreementItems,
  contactCards,
  contactSettings,
  heroContent,
  heroStatistics,
  marqueeItems,
  navigationLinks,
  onboardingSteps,
  pricingItems,
  services,
  sectionCopy,
  siteSettings,
  slugRedirects,
  socialLinks,
  truckTypes,
} from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import {
  actionError,
  requireConfirmation,
  ValidationError,
  booleanFrom,
  hrefFrom,
  idFrom,
  integerFrom,
  jsonFrom,
  optionalKeywordsFrom,
  orderFrom,
  slugFrom,
  statusFrom,
  text,
  type CmsFormState,
} from "@/lib/cms/admin-validation";
import { validateServiceDetail, validateAgreementSections } from "@/lib/cms/structured-validation";
import { lockContent } from "@/lib/cms/media-safety";
import { cleanupUpload, persistImage, prepareImage, removeReplacedImage } from "@/lib/cms/image-save";
import { DEFAULT_SECTION_COPY } from "@/data/section-copy";


type SimpleEntity = "navigation" | "social" | "hero-stat" | "about-feature" | "step" | "contact-card" | "marquee" | "pricing" | "agreement-summary";

function refreshCms() {
  revalidatePath("/", "layout");
}

async function audit(tx: Parameters<Parameters<ReturnType<typeof getDb>["transaction"]>[0]>[0], actor: string, action: string, entityType: string, entityId: number | string, summary: string) {
  await tx.insert(adminAuditRecords).values({ action, entityType, entityId: String(entityId), summary, actor });
}

export async function updateSiteSettings(_state: CmsFormState, formData: FormData): Promise<CmsFormState> {
  const admin = await requireAdmin();
  let prepared:Awaited<ReturnType<typeof prepareImage>>=null;let saved=false;let oldImage:string|null=null;
  try {
    const phone = text(formData, "phone", 60);
    const email = text(formData, "email", 200).toLowerCase();
    prepared=await prepareImage(formData,"logo","company",true);
    const values = {
      name: text(formData, "name", 160),
      legalName: text(formData, "legalName", 200),
      shortName: text(formData, "shortName", 160),
      tagline: text(formData, "tagline", 160),
      estYear: integerFrom(formData, "estYear", true)!,
      dot: text(formData, "dot", 40),
      mc: text(formData, "mc", 40),
      phone,
      phoneHref: `tel:${phone.replace(/[^\d+]/g, "")}`,
      email,
      emailHref: `mailto:${email}`,
      website: text(formData, "website", 240),
      address: text(formData, "address", 240),
      city: text(formData, "city", 160),
      hours: text(formData, "hours", 240),
      copyright: text(formData, "copyright", 240),
      logo:prepared!.url,
      logoAlt:prepared!.alt,
      seoTitle:text(formData,"seoTitle",240),
      seoDescription:text(formData,"seoDescription",500),
      updatedAt: new Date(),
      updatedBy: admin.id,
    };
    await getDb().transaction(async (tx) => { await lockContent(tx);
      const[current]=await tx.select({logo:siteSettings.logo}).from(siteSettings).where(eq(siteSettings.id,1)).limit(1);oldImage=current?.logo??null;await persistImage(tx,prepared,admin.id);
      await tx.update(siteSettings).set(values).where(eq(siteSettings.id, 1));
      await audit(tx, admin.id, "updated", "site_settings", 1, "Updated company settings.");
    });
    saved=true;await removeReplacedImage(oldImage,values.logo,admin.id).catch(console.error);
    refreshCms();
    return { success: "Company settings saved." };
  } catch (error) {if(!saved)await cleanupUpload(prepared);return actionError(error); }
}

export async function updateHero(_state: CmsFormState, formData: FormData): Promise<CmsFormState> {
  const admin = await requireAdmin();
  const prepared: NonNullable<Awaited<ReturnType<typeof prepareImage>>>[]=[];let saved=false;let oldImages:string[]=[];
  try {
    const count=integerFrom(formData,"heroImageCount",true)!;
    if(count<1||count>20)throw new ValidationError("Use between 1 and 20 hero images.");
    for(let index=0;index<count;index++){const image=await prepareImage(formData,`heroImage${index}`,"hero",true);if(image)prepared.push(image);}
    const values = {
      heading: text(formData, "heading", 240),
      headingAccent: text(formData, "headingAccent", 120),
      tagline: text(formData, "tagline", 240),
      description: text(formData, "description", 3000),
      primaryCtaLabel: text(formData, "primaryCtaLabel", 120),
      primaryCtaHref: hrefFrom(formData, "primaryCtaHref"),
      secondaryCtaLabel: text(formData, "secondaryCtaLabel", 120),
      secondaryCtaHref: hrefFrom(formData, "secondaryCtaHref"),
      showAuthority: booleanFrom(formData, "showAuthority"),
      images: prepared.map(image=>image.url),
      imageAlts:prepared.map(image=>image.alt),
      updatedAt: new Date(),
      updatedBy: admin.id,
    };
    await getDb().transaction(async (tx) => { await lockContent(tx);
      const[current]=await tx.select({images:heroContent.images}).from(heroContent).where(eq(heroContent.id,1)).limit(1);oldImages=current?.images??[];
      for(const image of prepared)await persistImage(tx,image,admin.id);
      await tx.update(heroContent).set(values).where(eq(heroContent.id, 1));
      await audit(tx, admin.id, "updated", "hero", 1, "Updated hero content.");
    });
    saved=true;
    for(const oldImage of oldImages)if(!values.images.includes(oldImage))await removeReplacedImage(oldImage,null,admin.id).catch(console.error);
    refreshCms();
    return { success: "Hero saved." };
  } catch (error) {if(!saved)for(const image of prepared)await cleanupUpload(image);return actionError(error); }
}

export async function updateAbout(_state: CmsFormState, formData: FormData): Promise<CmsFormState> {
  const admin = await requireAdmin();
  let prepared: Awaited<ReturnType<typeof prepareImage>> = null;
  let saved=false;
  let oldImage: string | null = null;
  try {
    prepared=await prepareImage(formData,"image","about");
    const image=prepared?.url??"";const imageAlt=prepared?.alt??"";
    const values = {
      sectionLabel: text(formData, "sectionLabel", 160), heading: text(formData, "heading", 240), headingAccent: text(formData, "headingAccent", 240),
      establishedText: text(formData, "establishedText", 200, false), years: text(formData, "years", 40, false), yearsLabel: text(formData, "yearsLabel", 240, false),
      image, imageAlt, description1: text(formData, "description1", 5000), description2: text(formData, "description2", 5000, false), enabled:booleanFrom(formData,"enabled"),
      updatedAt: new Date(), updatedBy: admin.id,
    };
    await getDb().transaction(async (tx) => { await lockContent(tx);const[current]=await tx.select({image:aboutContent.image}).from(aboutContent).where(eq(aboutContent.id,1)).limit(1);oldImage=current?.image??null;await persistImage(tx,prepared,admin.id);await tx.update(aboutContent).set(values).where(eq(aboutContent.id, 1)); await audit(tx, admin.id, "updated", "about", 1, "Updated About content."); });
    saved=true;
    await removeReplacedImage(oldImage,image,admin.id).catch(console.error);
    refreshCms();
    return { success: "About section saved." };
  } catch (error) {if(!saved)await cleanupUpload(prepared);return actionError(error); }
}

export async function updateContact(_state: CmsFormState, formData: FormData): Promise<CmsFormState> {
  const admin = await requireAdmin();
  try {
    const values = {
      sectionLabel: text(formData, "sectionLabel", 160), heading: text(formData, "heading", 240), headingAccent: text(formData, "headingAccent", 240),
      description: text(formData, "description", 5000), dispatchStatusText: text(formData, "dispatchStatusText", 160),
      dispatchResponseTime: text(formData, "dispatchResponseTime", 80), afterHoursText: text(formData, "afterHoursText", 240),
      privacyDisclaimer: text(formData, "privacyDisclaimer", 3000), updatedAt: new Date(), updatedBy: admin.id,
    };
    await getDb().transaction(async (tx) => { await lockContent(tx); await tx.update(contactSettings).set(values).where(eq(contactSettings.id, 1)); await audit(tx, admin.id, "updated", "contact", 1, "Updated contact settings."); });
    refreshCms();
    return { success: "Contact section saved." };
  } catch (error) {return actionError(error); }
}

export async function updateAgreement(_state: CmsFormState, formData: FormData): Promise<CmsFormState> {
  const admin = await requireAdmin();
  try {
    const sections = validateAgreementSections(jsonFrom<unknown>(formData, "sections"));
    const values = {
      version: text(formData, "version", 80), title: text(formData, "title", 200), intro: text(formData, "intro", 10000), sections,
      carrierSignatureLabel: text(formData, "carrierSignatureLabel", 160), carrierSignatureHelp: text(formData, "carrierSignatureHelp", 240),
      companySignatureLabel: text(formData, "companySignatureLabel", 160), companySignatureHelp: text(formData, "companySignatureHelp", 240),
      updatedAt: new Date(), updatedBy: admin.id,
    };
    await getDb().transaction(async (tx) => { await lockContent(tx);
      const [current]=await tx.select().from(agreementDocument).where(eq(agreementDocument.id,1)).limit(1).for("update");
      if(!current)throw new ValidationError("Agreement document not found.");
      await tx.insert(agreementRevisions).values({version:current.version,snapshot:{title:current.title,intro:current.intro,sections:current.sections,carrierSignatureLabel:current.carrierSignatureLabel,carrierSignatureHelp:current.carrierSignatureHelp,companySignatureLabel:current.companySignatureLabel,companySignatureHelp:current.companySignatureHelp},sourceUpdatedAt:current.updatedAt,archivedBy:admin.id});
      await tx.update(agreementDocument).set(values).where(eq(agreementDocument.id, 1));
      await audit(tx, admin.id, "updated", "agreement", 1, `Updated agreement version ${values.version}.`);
    });
    refreshCms();
    return { success: "Agreement saved." };
  } catch (error) { return actionError(error); }
}

export async function updateSectionCopy(_state: CmsFormState, formData: FormData): Promise<CmsFormState> {
  const admin = await requireAdmin();
  try {
    const fields=Object.keys(DEFAULT_SECTION_COPY) as Array<keyof typeof DEFAULT_SECTION_COPY>;
    const content=Object.fromEntries(fields.map(field=>[field,field.endsWith("Href")?hrefFrom(formData,field):text(formData,field,field.toLowerCase().includes("description")||field.toLowerCase().includes("message")||field.toLowerCase().includes("disclaimer")||field==="contactSmsConsent"?5000:1000)])) as unknown as import("@/lib/cms/types").SectionCopyContent;
    await getDb().transaction(async (tx) => { await lockContent(tx); await tx.update(sectionCopy).set({ content, updatedAt: new Date(), updatedBy: admin.id }).where(eq(sectionCopy.id, 1)); await audit(tx, admin.id, "updated", "section_copy", 1, "Updated public section copy."); });
    refreshCms(); return { success: "Section headings and labels saved." };
  } catch (error) { return actionError(error); }
}

export async function updateServicesSection(_state: CmsFormState, formData: FormData): Promise<CmsFormState> {
  const admin = await requireAdmin();
  try {
    const values = { servicesLabel:text(formData,"servicesLabel",240), servicesHeading:text(formData,"servicesHeading",240), servicesHeadingAccent:text(formData,"servicesHeadingAccent",240), servicesDescription:text(formData,"servicesDescription",3000) };
    await getDb().transaction(async tx=>{await lockContent(tx);const [row]=await tx.select().from(sectionCopy).where(eq(sectionCopy.id,1)).limit(1).for("update");if(!row)throw new ValidationError("Services section settings are not seeded.");await tx.update(sectionCopy).set({content:{...row.content,...values},updatedAt:new Date(),updatedBy:admin.id}).where(eq(sectionCopy.id,1));await audit(tx,admin.id,"updated","services_section",1,"Updated Services section settings.");});
    refreshCms();return{success:"Services section saved."};
  } catch(error){return actionError(error);}
}

export async function saveSimpleItem(_state: CmsFormState, formData: FormData): Promise<CmsFormState> {
  const admin = await requireAdmin();
  try {
    const entity = text(formData, "entity", 40) as SimpleEntity;
    const id = idFrom(formData);
    const common = { sortOrder: orderFrom(formData), status: statusFrom(formData), updatedAt: new Date(), updatedBy: admin.id, deletedAt: null };
    let savedId: number;
    let summary: string;
    await getDb().transaction(async (tx) => { await lockContent(tx);
      if (entity === "navigation") {
        const values = { ...common, label: text(formData, "label", 120), href: hrefFrom(formData, "href") };
        savedId = id ? (await tx.update(navigationLinks).set(values).where(eq(navigationLinks.id, id)).returning({ id: navigationLinks.id }))[0]?.id : (await tx.insert(navigationLinks).values({ ...values, createdBy: admin.id }).returning({ id: navigationLinks.id }))[0].id;
        summary = `Saved navigation link ${values.label}.`;
      } else if (entity === "social") {
        const values = { ...common, label: text(formData, "label", 120), icon: text(formData, "icon", 120), href: hrefFrom(formData, "href") };
        savedId = id ? (await tx.update(socialLinks).set(values).where(eq(socialLinks.id, id)).returning({ id: socialLinks.id }))[0]?.id : (await tx.insert(socialLinks).values({ ...values, createdBy: admin.id }).returning({ id: socialLinks.id }))[0].id;
        summary = `Saved social link ${values.label}.`;
      } else if (entity === "hero-stat") {
        const values = { ...common, label: text(formData, "label", 160), value: text(formData, "value", 80), accent: booleanFrom(formData, "accent") };
        savedId = id ? (await tx.update(heroStatistics).set(values).where(eq(heroStatistics.id, id)).returning({ id: heroStatistics.id }))[0]?.id : (await tx.insert(heroStatistics).values({ ...values, createdBy: admin.id }).returning({ id: heroStatistics.id }))[0].id;
        summary = `Saved hero statistic ${values.label}.`;
      } else if (entity === "about-feature") {
        const values = { ...common, title: text(formData, "title", 160), icon: text(formData, "icon", 120), description: text(formData, "description", 3000), accent: booleanFrom(formData, "accent") };
        savedId = id ? (await tx.update(aboutFeatures).set(values).where(eq(aboutFeatures.id, id)).returning({ id: aboutFeatures.id }))[0]?.id : (await tx.insert(aboutFeatures).values({ ...values, createdBy: admin.id }).returning({ id: aboutFeatures.id }))[0].id;
        summary = `Saved About feature ${values.title}.`;
      } else if (entity === "step") {
        const values = { ...common, num: text(formData, "num", 20), label: text(formData, "label", 120), title: text(formData, "title", 200), description: text(formData, "description", 3000) };
        savedId = id ? (await tx.update(onboardingSteps).set(values).where(eq(onboardingSteps.id, id)).returning({ id: onboardingSteps.id }))[0]?.id : (await tx.insert(onboardingSteps).values({ ...values, createdBy: admin.id }).returning({ id: onboardingSteps.id }))[0].id;
        summary = `Saved onboarding step ${values.title}.`;
      } else if (entity === "contact-card") {
        const values = { ...common, label: text(formData, "label", 160), icon: text(formData, "icon", 120), value: text(formData, "value", 3000), href: hrefFrom(formData, "href", false) || null };
        savedId = id ? (await tx.update(contactCards).set(values).where(eq(contactCards.id, id)).returning({ id: contactCards.id }))[0]?.id : (await tx.insert(contactCards).values({ ...values, createdBy: admin.id }).returning({ id: contactCards.id }))[0].id;
        summary = `Saved contact card ${values.label}.`;
      } else if (entity === "marquee") {
        const values = { ...common, label: text(formData, "label", 160) };
        savedId = id ? (await tx.update(marqueeItems).set(values).where(eq(marqueeItems.id, id)).returning({ id: marqueeItems.id }))[0]?.id : (await tx.insert(marqueeItems).values({ ...values, createdBy: admin.id }).returning({ id: marqueeItems.id }))[0].id;
        summary = `Saved marquee item ${values.label}.`;
      } else if (entity === "pricing") {
        const values = { ...common, name: text(formData, "name", 160), value: text(formData, "value", 80), unit: text(formData, "unit", 120), agreementSuffix: text(formData, "agreementSuffix", 240, false) || null, description: text(formData, "description", 3000), highlight: booleanFrom(formData, "highlight") };
        savedId = id ? (await tx.update(pricingItems).set(values).where(eq(pricingItems.id, id)).returning({ id: pricingItems.id }))[0]?.id : (await tx.insert(pricingItems).values({ ...values, createdBy: admin.id }).returning({ id: pricingItems.id }))[0].id;
        summary = `Saved pricing row ${values.name}.`;
      } else if (entity === "agreement-summary") {
        const values = { ...common, num: text(formData, "num", 20), title: text(formData, "title", 200), description: text(formData, "description", 3000) };
        savedId = id ? (await tx.update(agreementItems).set(values).where(eq(agreementItems.id, id)).returning({ id: agreementItems.id }))[0]?.id : (await tx.insert(agreementItems).values({ ...values, createdBy: admin.id }).returning({ id: agreementItems.id }))[0].id;
        summary = `Saved agreement summary ${values.title}.`;
      } else throw new ValidationError("Unsupported CMS item.");
      if (!savedId!) throw new ValidationError("CMS item not found.");
      await audit(tx, admin.id, id ? "updated" : "created", entity, savedId, summary!);
    });
    refreshCms();
    return { success: "Saved." };
  } catch (error) { return actionError(error); }
}

export async function deleteSimpleItem(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  requireConfirmation(formData);
  const entity = text(formData, "entity", 40) as SimpleEntity;
  const id = idFrom(formData, true)!;
  const archived = { status: "draft" as const, deletedAt: new Date(), updatedAt: new Date(), updatedBy: admin.id };
  await getDb().transaction(async (tx) => { await lockContent(tx);
    if (entity === "navigation") await tx.update(navigationLinks).set(archived).where(eq(navigationLinks.id, id));
    else if (entity === "social") await tx.update(socialLinks).set(archived).where(eq(socialLinks.id, id));
    else if (entity === "hero-stat") await tx.update(heroStatistics).set(archived).where(eq(heroStatistics.id, id));
    else if (entity === "about-feature") await tx.update(aboutFeatures).set(archived).where(eq(aboutFeatures.id, id));
    else if (entity === "step") await tx.update(onboardingSteps).set(archived).where(eq(onboardingSteps.id, id));
    else if (entity === "contact-card") await tx.update(contactCards).set(archived).where(eq(contactCards.id, id));
    else if (entity === "marquee") await tx.update(marqueeItems).set(archived).where(eq(marqueeItems.id, id));
    else if (entity === "pricing") await tx.update(pricingItems).set(archived).where(eq(pricingItems.id, id));
    else if (entity === "agreement-summary") await tx.update(agreementItems).set(archived).where(eq(agreementItems.id, id));
    else throw new ValidationError("Unsupported CMS item.");
    await audit(tx, admin.id, "archived", entity, id, `Archived ${entity} item.`);
  });
  refreshCms();
}


export async function saveService(_state: CmsFormState, formData: FormData): Promise<CmsFormState> {
  const admin = await requireAdmin();
  let prepared: Awaited<ReturnType<typeof prepareImage>> = null;
  let saved=false;
  let oldImage: string | null = null;
  try {
    const id = idFrom(formData);
    const slug = slugFrom(formData);
    const detail = validateServiceDetail(jsonFrom<unknown>(formData, "detail"));
    prepared=await prepareImage(formData,"image","services");
    const values = { num: text(formData, "num", 20), slug, icon: text(formData, "icon", 120), image:prepared?.url??null, imageAlt:prepared?.alt??null, title: text(formData, "title", 200), description: text(formData, "description", 5000), ctaLabel:text(formData,"ctaLabel",120), ctaHref:hrefFrom(formData,"ctaHref"), detail, seoTitle:text(formData,"seoTitle",240,false)||null, seoDescription:text(formData,"seoDescription",500,false)||null, seoKeywords:optionalKeywordsFrom(formData), sortOrder: orderFrom(formData), status: statusFrom(formData), updatedAt: new Date(), updatedBy: admin.id, deletedAt: null };
    await getDb().transaction(async (tx) => { await lockContent(tx);
      await persistImage(tx,prepared,admin.id);
      const [reserved] = await tx.select({id:slugRedirects.id}).from(slugRedirects).where(and(eq(slugRedirects.entityType,"service"),eq(slugRedirects.oldSlug,slug))).limit(1);
      if(reserved)throw new ValidationError("This slug is reserved by a previous service URL.");
      if (id) {
        const [old] = await tx.select({ slug: services.slug, image:services.image }).from(services).where(and(eq(services.id, id), isNull(services.deletedAt))).limit(1);
        if (!old) throw new ValidationError("Service not found.");
        oldImage=old.image;
        await tx.update(services).set(values).where(eq(services.id, id));
        if (old.slug !== slug) {
          await tx.update(slugRedirects).set({ newSlug: slug }).where(and(eq(slugRedirects.entityType, "service"), eq(slugRedirects.newSlug, old.slug)));
          await tx.insert(slugRedirects).values({ entityType: "service", oldSlug: old.slug, newSlug: slug }).onConflictDoUpdate({ target: [slugRedirects.entityType, slugRedirects.oldSlug], set: { newSlug: slug } });
        }
        await audit(tx, admin.id, "updated", "service", id, `Updated service ${values.title}.`);
      } else {
        const [created] = await tx.insert(services).values({ ...values, createdBy: admin.id }).returning({ id: services.id });
        await audit(tx, admin.id, "created", "service", created.id, `Created service ${values.title}.`);
      }
    });
    saved=true;
    await removeReplacedImage(oldImage,values.image,admin.id).catch(console.error);
    refreshCms();
    return { success: "Service saved." };
  } catch (error) { if(!saved)await cleanupUpload(prepared);return actionError(error); }
}

export async function saveTruckType(_state: CmsFormState, formData: FormData): Promise<CmsFormState> {
  const admin = await requireAdmin();
  let prepared: Awaited<ReturnType<typeof prepareImage>> = null;
  let saved=false;let oldImage:string|null=null;
  try {
    const id = idFrom(formData);
    const slug = slugFrom(formData);
    const commonFreight = jsonFrom<unknown[]>(formData, "commonFreight");
    if (!Array.isArray(commonFreight) || commonFreight.length > 50 || commonFreight.some((item) => typeof item !== "string" || !item.trim() || item.length > 300)) throw new ValidationError("Common Freight items are invalid.");
    prepared=await prepareImage(formData,"image","trucks",true);
    const values = { num: text(formData, "num", 20), slug, icon: text(formData, "icon", 120), name: text(formData, "name", 200), spec: text(formData, "spec", 200), image: prepared!.url, imageAlt:prepared!.alt, intro: text(formData, "intro", 5000), bestFor: text(formData, "bestFor", 3000), equipmentNotes: text(formData, "equipmentNotes", 5000), commonFreight: commonFreight as string[], weeklyGrossMin: integerFrom(formData, "weeklyGrossMin"), weeklyGrossMax: integerFrom(formData, "weeklyGrossMax"), avgMilesPerWeek: text(formData, "avgMilesPerWeek", 120, false) || null, seoTitle:text(formData,"seoTitle",240,false)||null, seoDescription:text(formData,"seoDescription",500,false)||null, seoKeywords:optionalKeywordsFrom(formData), sortOrder: orderFrom(formData), status: statusFrom(formData), updatedAt: new Date(), updatedBy: admin.id, deletedAt: null };
    if (values.weeklyGrossMin !== null && values.weeklyGrossMax !== null && values.weeklyGrossMin > values.weeklyGrossMax) throw new ValidationError("Weekly gross minimum cannot exceed the maximum.");
    await getDb().transaction(async (tx) => { await lockContent(tx);
      await persistImage(tx,prepared,admin.id);
      const [reserved] = await tx.select({id:slugRedirects.id}).from(slugRedirects).where(and(eq(slugRedirects.entityType,"truck"),eq(slugRedirects.oldSlug,slug))).limit(1);
      if(reserved)throw new ValidationError("This slug is reserved by a previous truck URL.");
      if (id) {
        const [old] = await tx.select({ slug: truckTypes.slug,image:truckTypes.image }).from(truckTypes).where(and(eq(truckTypes.id, id), isNull(truckTypes.deletedAt))).limit(1);
        if (!old) throw new ValidationError("Truck type not found.");
        oldImage=old.image;
        await tx.update(truckTypes).set(values).where(eq(truckTypes.id, id));
        if (old.slug !== slug) {
          await tx.update(slugRedirects).set({ newSlug: slug }).where(and(eq(slugRedirects.entityType, "truck"), eq(slugRedirects.newSlug, old.slug)));
          await tx.insert(slugRedirects).values({ entityType: "truck", oldSlug: old.slug, newSlug: slug }).onConflictDoUpdate({ target: [slugRedirects.entityType, slugRedirects.oldSlug], set: { newSlug: slug } });
        }
        await audit(tx, admin.id, "updated", "truck_type", id, `Updated truck type ${values.name}.`);
      } else {
        const [created] = await tx.insert(truckTypes).values({ ...values, createdBy: admin.id }).returning({ id: truckTypes.id });
        await audit(tx, admin.id, "created", "truck_type", created.id, `Created truck type ${values.name}.`);
      }
    });
    saved=true;await removeReplacedImage(oldImage,values.image,admin.id).catch(console.error);
    refreshCms();
    return { success: "Truck type saved." };
  } catch (error) {if(!saved)await cleanupUpload(prepared);return actionError(error); }
}

export async function setMainEntityStatus(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  const id = idFrom(formData, true)!;
  const entity = text(formData, "entity", 20);
  const status = statusFrom(formData);
  await getDb().transaction(async (tx) => { await lockContent(tx);
    if (entity === "service") await tx.update(services).set({ status, updatedAt: new Date(), updatedBy: admin.id }).where(and(eq(services.id, id), isNull(services.deletedAt)));
    else if (entity === "truck") await tx.update(truckTypes).set({ status, updatedAt: new Date(), updatedBy: admin.id }).where(and(eq(truckTypes.id, id), isNull(truckTypes.deletedAt)));
    else throw new ValidationError("Unsupported content type.");
    await audit(tx, admin.id, "status_changed", entity, id, `Changed ${entity} status to ${status}.`);
  });
  refreshCms();
}

export async function archiveMainEntity(formData: FormData): Promise<void> {
  const admin = await requireAdmin();
  requireConfirmation(formData);
  const id = idFrom(formData, true)!;
  const entity = text(formData, "entity", 20);
  const archived = { status: "draft" as const, deletedAt: new Date(), updatedAt: new Date(), updatedBy: admin.id };
  await getDb().transaction(async (tx) => { await lockContent(tx);
    if (entity === "service") await tx.update(services).set(archived).where(eq(services.id, id));
    else if (entity === "truck") await tx.update(truckTypes).set(archived).where(eq(truckTypes.id, id));
    else throw new ValidationError("Unsupported content type.");
    await audit(tx, admin.id, "archived", entity, id, `Archived ${entity}.`);
  });
  refreshCms();
}
