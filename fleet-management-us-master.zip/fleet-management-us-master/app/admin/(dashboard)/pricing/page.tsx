import { asc, eq, isNull } from "drizzle-orm";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import AgreementEditor from "@/components/admin/AgreementEditor";
import SectionCopyForm from "@/components/admin/SectionCopyForm";
import SimpleItemForm, { type SimpleFieldConfig } from "@/components/admin/SimpleItemForm";
import { getDb } from "@/db";
import { agreementDocument, agreementItems, pricingItems, sectionCopy } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";

type PricingRow = typeof pricingItems.$inferSelect;
type SummaryRow = typeof agreementItems.$inferSelect;
const pricingFields = (item: Partial<PricingRow>): SimpleFieldConfig[] => [{name:"name",label:"Name",value:item.name},{name:"value",label:"Value",value:item.value},{name:"unit",label:"Unit",value:item.unit},{name:"agreementSuffix",label:"Agreement suffix",value:item.agreementSuffix,required:false},{name:"description",label:"Description",value:item.description,type:"textarea"},{name:"highlight",label:"Highlight",value:item.highlight?1:0,checkbox:true}];
const summaryFields = (item: Partial<SummaryRow>): SimpleFieldConfig[] => [{name:"num",label:"Number",value:item.num},{name:"title",label:"Title",value:item.title},{name:"description",label:"Description",value:item.description,type:"textarea"}];

export default async function PricingPage(){
  await requireAdmin();
  const [pricing,summary,[document],[copy]]=await Promise.all([getDb().select().from(pricingItems).where(isNull(pricingItems.deletedAt)).orderBy(asc(pricingItems.sortOrder)),getDb().select().from(agreementItems).where(isNull(agreementItems.deletedAt)).orderBy(asc(agreementItems.sortOrder)),getDb().select().from(agreementDocument).where(eq(agreementDocument.id,1)),getDb().select().from(sectionCopy).where(eq(sectionCopy.id,1))]);
  if(!document||!copy)throw new Error("Pricing CMS content is not seeded.");
  return <><AdminPageHeader eyebrow="CMS" title="PRICING & AGREEMENT" description="Control section wording, public pricing, the agreement summary, and the complete versioned carrier agreement."/><Section title="Section headings, labels & calls to action"><SectionCopyForm copy={copy.content}/></Section><Section title="Pricing rows"><SimpleItemForm entity="pricing" title="Add pricing row" fields={pricingFields({})}/>{pricing.map((item)=><SimpleItemForm key={item.id} entity="pricing" id={item.id} title={item.name} status={item.status} sortOrder={item.sortOrder} fields={pricingFields(item)}/>)}</Section><Section title="Agreement summary"><SimpleItemForm entity="agreement-summary" title="Add summary item" fields={summaryFields({})}/>{summary.map((item)=><SimpleItemForm key={item.id} entity="agreement-summary" id={item.id} title={item.title} status={item.status} sortOrder={item.sortOrder} fields={summaryFields(item)}/>)}</Section><Section title="Full carrier agreement"><AgreementEditor agreement={document}/></Section></>;
}
function Section({title,children}:{title:string;children:React.ReactNode}){return <section className="mb-12"><h2 className="font-display mb-5 text-3xl">{title}</h2><div className="grid gap-4">{children}</div></section>}
