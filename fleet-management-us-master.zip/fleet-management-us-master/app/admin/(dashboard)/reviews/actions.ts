"use server";

import { and, eq, inArray, isNull } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { getDb } from "@/db";
import { adminAuditRecords, reviewStatuses, testimonials, type ReviewStatus } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { selectedIds, requireConfirmation, actionError } from "@/lib/cms/admin-validation";
import { lockContent } from "@/lib/cms/media-safety";
import { validateReview, type ReviewFormState } from "@/lib/cms/review-validation";
import { cleanupUpload, persistImage, prepareImage, removeReplacedImage } from "@/lib/cms/image-save";

function refreshReviews() { revalidatePath("/admin"); revalidatePath("/admin/reviews"); revalidatePath("/", "layout"); }
function reviewStatus(value: FormDataEntryValue | null): ReviewStatus | null { return typeof value === "string" && reviewStatuses.includes(value as ReviewStatus) ? value as ReviewStatus : null; }

export async function createReview(_state: ReviewFormState, formData: FormData): Promise<ReviewFormState> {
  const admin=await requireAdmin(); const result=validateReview(formData); if(!result.ok)return result.state;
  if(result.data.status!=="pending"&&result.data.status!=="published")return{error:"Choose Pending or Published.",fieldErrors:{status:"Choose Pending or Published."}};
  let prepared:Awaited<ReturnType<typeof prepareImage>>=null;let saved=false;
  try{prepared=await prepareImage(formData,"avatarPath","testimonials");result.data.avatarPath=prepared?.url??null;result.data.avatarAlt=prepared?.alt??null;await getDb().transaction(async tx=>{await lockContent(tx);await persistImage(tx,prepared,admin.id);const [created]=await tx.insert(testimonials).values({...result.data,createdBy:admin.id,updatedBy:admin.id}).returning({id:testimonials.id});await tx.insert(adminAuditRecords).values({action:"created",entityType:"testimonial",entityId:String(created.id),summary:`Created ${result.data.status} review.`,actor:admin.id});});saved=true;refreshReviews();return{success:"Review created and saved."};}catch(error){if(!saved)await cleanupUpload(prepared);return actionError(error);}
}

export async function updateReview(_state: ReviewFormState, formData: FormData): Promise<ReviewFormState> {
  const admin=await requireAdmin(); const id=Number(formData.get("id")); if(!Number.isSafeInteger(id)||id<=0||id>2147483647)return{error:"Invalid review ID."}; const result=validateReview(formData);if(!result.ok)return result.state;
  let prepared:Awaited<ReturnType<typeof prepareImage>>=null;let saved=false;let oldImage:string|null=null;
  try{prepared=await prepareImage(formData,"avatarPath","testimonials");result.data.avatarPath=prepared?.url??null;result.data.avatarAlt=prepared?.alt??null;await getDb().transaction(async tx=>{await lockContent(tx);if(result.data.status==="archived"||result.data.status==="rejected")requireConfirmation(formData);await persistImage(tx,prepared,admin.id);const[current]=await tx.select({image:testimonials.avatarPath}).from(testimonials).where(and(eq(testimonials.id,id),isNull(testimonials.deletedAt))).limit(1);oldImage=current?.image??null;const [updated]=await tx.update(testimonials).set({...result.data,updatedAt:new Date(),updatedBy:admin.id,deletedAt:null}).where(and(eq(testimonials.id,id),isNull(testimonials.deletedAt))).returning({id:testimonials.id});if(!updated)throw new Error("Review not found.");await tx.insert(adminAuditRecords).values({action:`review_${result.data.status}`,entityType:"testimonial",entityId:String(id),summary:`Updated review; status ${result.data.status}.`,actor:admin.id});});saved=true;await removeReplacedImage(oldImage,result.data.avatarPath,admin.id).catch(console.error);refreshReviews();return{success:"Review changes saved."};}catch(error){if(!saved)await cleanupUpload(prepared);return actionError(error);}
}

export async function setReviewStatus(formData: FormData): Promise<void> {
  const admin=await requireAdmin(); const id=Number(formData.get("id")); const status=reviewStatus(formData.get("status")); if(!Number.isSafeInteger(id)||id<=0||id>2147483647||!status)throw new Error("Invalid review moderation request.");
  await getDb().transaction(async tx=>{await lockContent(tx);if(status==="archived"||status==="rejected")requireConfirmation(formData);const [row]=await tx.update(testimonials).set({status,updatedAt:new Date(),updatedBy:admin.id}).where(and(eq(testimonials.id,id),isNull(testimonials.deletedAt))).returning({name:testimonials.name});if(!row)throw new Error("Review not found.");await tx.insert(adminAuditRecords).values({action:`review_${status}`,entityType:"testimonial",entityId:String(id),summary:`Changed review to ${status}.`,actor:admin.id});});refreshReviews();
}

export async function archiveReview(formData: FormData): Promise<void> { formData.set("status","archived"); await setReviewStatus(formData); }

export async function bulkReviewAction(formData: FormData): Promise<void> {
  const admin=await requireAdmin();const ids=selectedIds(formData);const status=reviewStatus(formData.get("bulkStatus"));if(!ids.length||!status)throw new Error("Select reviews and a valid action.");
  await getDb().transaction(async tx=>{await lockContent(tx);if(status==="archived"||status==="rejected")requireConfirmation(formData);const rows=await tx.update(testimonials).set({status,updatedAt:new Date(),updatedBy:admin.id}).where(and(inArray(testimonials.id,ids),isNull(testimonials.deletedAt))).returning({id:testimonials.id});if(rows.length!==ids.length)throw new Error("Some reviews were not found.");await tx.insert(adminAuditRecords).values(ids.map(id=>({action:`bulk_review_${status}`,entityType:"testimonial",entityId:String(id),summary:`Changed review to ${status} in bulk.`,actor:admin.id})));});refreshReviews();
}
