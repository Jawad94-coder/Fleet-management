import Link from "next/link";
import { and, asc, eq, ilike, isNull, or } from "drizzle-orm";
import AdminEmptyState from "@/components/admin/AdminEmptyState";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import BulkModerationForm from "@/components/admin/BulkModerationForm";
import ReviewStatusForm from "@/components/admin/ReviewStatusForm";
import DeleteConfirmation from "@/components/admin/DeleteConfirmation";
import { getDb } from "@/db";
import { reviewStatuses, testimonials, type ReviewStatus } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { archiveReview, bulkReviewAction } from "./actions";

const labels: Record<ReviewStatus,string>={pending:"Pending",published:"Published",rejected:"Rejected",archived:"Archived"};

export default async function ReviewsPage({searchParams}:{searchParams:Promise<{status?:string;q?:string}>}) {
  await requireAdmin(); const params=await searchParams;const status=reviewStatuses.includes(params.status as ReviewStatus)?params.status as ReviewStatus:null;const query=(typeof params.q==="string"?params.q.trim().slice(0,160):"");
  const search=query?or(ilike(testimonials.name,`%${query}%`),ilike(testimonials.company,`%${query}%`),ilike(testimonials.quote,`%${query}%`)):undefined;
  const reviews=await getDb().select().from(testimonials).where(and(isNull(testimonials.deletedAt),status?eq(testimonials.status,status):undefined,search)).orderBy(asc(testimonials.sortOrder),asc(testimonials.id));
  return <><AdminPageHeader eyebrow="Moderation" title="REVIEWS" description="Review, publish, reject, feature, order, or archive testimonials." action={<Link href="/admin/reviews/new" className="btn-primary px-6 py-3 font-cond text-xs uppercase tracking-wider">Add review</Link>}/>
    <form className="mb-5 grid gap-3 sm:grid-cols-[1fr_auto]" role="search">{status&&<input type="hidden" name="status" value={status}/>}<input name="q" defaultValue={query} placeholder="Search carrier, company, or review" aria-label="Search reviews" className="form-input px-4 py-3"/><button className="btn-secondary px-5 py-3">Search</button></form>
    <nav className="mb-5 flex flex-wrap gap-2" aria-label="Filter reviews"><Filter href={`/admin/reviews${query?`?q=${encodeURIComponent(query)}`:""}`} active={!status}>All</Filter>{reviewStatuses.map(value=><Filter key={value} href={`/admin/reviews?status=${value}${query?`&q=${encodeURIComponent(query)}`:""}`} active={status===value}>{labels[value]}</Filter>)}</nav>
    {!reviews.length?<AdminEmptyState title="No reviews found" description="New reviews remain pending until an administrator publishes them."/>:<BulkModerationForm action={bulkReviewAction} kind="reviews"><div className="overflow-x-auto border border-[#242424] bg-[#141414]"><table className="w-full min-w-[1050px] text-left text-sm"><thead className="bg-[#0d0d0d] font-cond text-[10px] uppercase tracking-[.18em] text-[#6a6a6a]"><tr><th className="px-4 py-3">Select</th><th className="px-4 py-3">Order</th><th className="px-4 py-3">Carrier</th><th className="px-4 py-3">Review</th><th className="px-4 py-3">Rating</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Submitted</th><th className="px-4 py-3">Actions</th></tr></thead><tbody className="divide-y divide-[#242424]">{reviews.map(review=><tr key={review.id} className="align-top"><td className="px-4 py-5"><input type="checkbox" name="selectedId" value={review.id} form="bulk-reviews" aria-label={`Select review by ${review.name}`} className="h-4 w-4 accent-[#FF6B00]"/></td><td className="px-4 py-5">{review.sortOrder}</td><td className="px-4 py-5"><strong>{review.name}</strong>{review.company&&<span className="block text-xs text-[#777]">{review.company}</span>}<span className="block text-xs text-[#777]">{review.role}</span>{review.featured&&<span className="tag mt-2">Featured</span>}</td><td className="max-w-md px-4 py-5 text-[#aaa]">{review.quote.length>140?`${review.quote.slice(0,140)}…`:review.quote}</td><td className="px-4 py-5 text-accent" aria-label={`${review.rating} out of 5 stars`}>{"★".repeat(review.rating)}</td><td className="px-4 py-5"><ReviewStatusForm id={review.id} status={review.status} name={review.name}/></td><td className="whitespace-nowrap px-4 py-5 text-xs text-[#777]">{review.submittedAt.toLocaleDateString("en-US")}</td><td className="px-4 py-5"><div className="flex gap-2"><Link href={`/admin/reviews/${review.id}/edit`} className="btn-secondary px-3 py-2 text-xs">Open</Link>{review.status!=="archived"&&<DeleteConfirmation action={archiveReview} id={review.id} itemName={review.name}/>}</div></td></tr>)}</tbody></table></div></BulkModerationForm>}
  </>;
}
function Filter({href,active,children}:{href:string;active:boolean;children:React.ReactNode}){return <Link href={href} className={`border px-4 py-2 text-xs ${active?"border-accent bg-accent text-black":"border-[#363636] text-[#aaa]"}`}>{children}</Link>}
