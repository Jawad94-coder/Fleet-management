import Link from "next/link";
import { and, asc, eq, isNull } from "drizzle-orm";
import { notFound } from "next/navigation";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import ReviewForm from "@/components/admin/ReviewForm";
import { getDb } from "@/db";
import { mediaAssets, testimonials } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { updateReview } from "../../actions";

export default async function EditReviewPage({ params }: { params: Promise<{ id: string }> }) {
  await requireAdmin();
  const media=await getDb().select({path:mediaAssets.path,fileName:mediaAssets.fileName}).from(mediaAssets).where(isNull(mediaAssets.deletedAt)).orderBy(asc(mediaAssets.fileName));
  const { id: rawId } = await params;
  if (!/^\d+$/.test(rawId)) notFound();
  const id = Number(rawId);
  if (!Number.isSafeInteger(id) || id <= 0 || id > 2147483647) notFound();
  const [review] = await getDb().select().from(testimonials).where(and(eq(testimonials.id, id), isNull(testimonials.deletedAt))).limit(1);
  if (!review) notFound();
  return <><AdminPageHeader eyebrow="Reviews" title="EDIT REVIEW" action={<Link href="/admin/reviews" className="btn-secondary px-5 py-3 font-cond text-xs uppercase tracking-wider">Back to reviews</Link>} /><p className="mb-5 text-xs text-[#999]">Submitted {review.submittedAt.toLocaleString("en-US")} · Updated {review.updatedAt.toLocaleString("en-US")}</p><ReviewForm media={media} action={updateReview} id={id} initialValues={review} /></>;
}
