import { asc, isNull } from "drizzle-orm";
import { getDb } from "@/db";
import { mediaAssets } from "@/db/schema";
import Link from "next/link";
import AdminPageHeader from "@/components/admin/AdminPageHeader";
import ReviewForm from "@/components/admin/ReviewForm";
import { requireAdmin } from "@/lib/admin-auth";
import { createReview } from "../actions";

export default async function NewReviewPage() {
  await requireAdmin();
  const media=await getDb().select({path:mediaAssets.path,fileName:mediaAssets.fileName}).from(mediaAssets).where(isNull(mediaAssets.deletedAt)).orderBy(asc(mediaAssets.fileName));
  return <><AdminPageHeader eyebrow="Reviews" title="ADD REVIEW" action={<Link href="/admin/reviews" className="btn-secondary px-5 py-3 font-cond text-xs uppercase tracking-wider">Back to reviews</Link>} /><ReviewForm media={media} action={createReview} resetOnSuccess /></>;
}
