export default function AdminLoading() {
  return (
    <div className="animate-pulse" role="status" aria-live="polite">
      <div className="h-3 w-24 bg-[#242424]" />
      <div className="mt-4 h-10 w-72 max-w-full bg-[#242424]" />
      <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }, (_, index) => (
          <div key={index} className="h-32 border border-[#242424] bg-[#141414]" />
        ))}
      </div>
      <span className="sr-only">Loading admin content</span>
    </div>
  );
}
