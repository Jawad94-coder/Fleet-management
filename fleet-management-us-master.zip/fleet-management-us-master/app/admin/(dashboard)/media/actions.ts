"use server";

import { and, eq, isNull } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { getDb } from "@/db";
import { adminAuditRecords, mediaAssets } from "@/db/schema";
import { requireAdmin } from "@/lib/admin-auth";
import { actionError, imageHrefFrom, ValidationError, requireConfirmation, idFrom, text, type CmsFormState } from "@/lib/cms/admin-validation";
import { lockContent, mediaReferences } from "@/lib/cms/media-safety";
import { mediaFolders, removeMediaObject, uploadMediaObject, validateMediaFile, type MediaFolder } from "@/lib/storage/media";

function folderFrom(formData:FormData):MediaFolder{const folder=formData.get("folder");if(typeof folder!=="string"||!mediaFolders.includes(folder as MediaFolder))throw new ValidationError("Choose a valid CMS image folder.");return folder as MediaFolder;}

export async function uploadMedia(_state:CmsFormState, formData:FormData):Promise<CmsFormState> {
  const admin=await requireAdmin();
  try {
    const file=formData.get("file");
    if(!(file instanceof File))throw new ValidationError("Choose an image to upload.");
    const altText=text(formData,"altText",500,false)||null;
    const bytes=await validateMediaFile(file);
    const uploaded=await uploadMediaObject(file,bytes,folderFrom(formData));
    try {
      await getDb().transaction(async tx=>{
        await lockContent(tx);const [asset]=await tx.insert(mediaAssets).values({path:uploaded.publicUrl,fileName:file.name.slice(0,260),mimeType:file.type,cloudinaryPublicId:uploaded.publicId,source:"cloudinary",sizeBytes:uploaded.sizeBytes,width:uploaded.width,height:uploaded.height,altText,createdBy:admin.id,updatedBy:admin.id}).returning({id:mediaAssets.id});
        await tx.insert(adminAuditRecords).values({action:"created",entityType:"media",entityId:String(asset.id),summary:"Uploaded image.",actor:admin.id});
      });
    } catch(error) { await removeMediaObject(uploaded.publicId); throw error; }
    revalidatePath("/","layout");
    return {success:"Image uploaded."};
  } catch(error) { return actionError(error); }
}

export async function registerExternalMedia(_state:CmsFormState,formData:FormData):Promise<CmsFormState>{
  const admin=await requireAdmin();
  try{
    const path=imageHrefFrom(formData,"url");
    if(!/^https?:\/\//i.test(path))throw new ValidationError("Enter a public HTTP(S) image URL.");
    const altText=text(formData,"altText",500,false)||null;
    const fileName=text(formData,"fileName",260,false)||new URL(path).pathname.split("/").at(-1)||"External image";
    await getDb().transaction(async tx=>{await lockContent(tx);const[asset]=await tx.insert(mediaAssets).values({path,fileName,mimeType:"image/external",source:"external",altText,createdBy:admin.id,updatedBy:admin.id}).returning({id:mediaAssets.id});await tx.insert(adminAuditRecords).values({action:"created",entityType:"media",entityId:String(asset.id),summary:"Registered external image URL.",actor:admin.id});});
    revalidatePath("/","layout");return{success:"External image registered."};
  }catch(error){return actionError(error);}
}

export async function updateMedia(_state:CmsFormState,formData:FormData):Promise<CmsFormState> {
  const admin=await requireAdmin();
  try {
    const id=idFrom(formData,true)!;
    const altText=text(formData,"altText",500,false)||null;
    await getDb().transaction(async tx=>{
      await lockContent(tx);
      const [row]=await tx.update(mediaAssets).set({altText,updatedAt:new Date(),updatedBy:admin.id}).where(and(eq(mediaAssets.id,id),isNull(mediaAssets.deletedAt))).returning({id:mediaAssets.id});
      if(!row)throw new ValidationError("Media asset not found.");
      await tx.insert(adminAuditRecords).values({action:"updated",entityType:"media",entityId:String(id),summary:"Updated media alternative text.",actor:admin.id});
    });
    revalidatePath("/","layout");
    return {success:"Alternative text saved."};
  } catch(error) { return actionError(error); }
}

export async function deleteMedia(_state:CmsFormState,formData:FormData):Promise<CmsFormState> {
  const admin=await requireAdmin();
  try {
    requireConfirmation(formData);
    const id=idFrom(formData,true)!;
    const asset=await getDb().transaction(async tx=>{
      await lockContent(tx);
      const [asset]=await tx.select().from(mediaAssets).where(and(eq(mediaAssets.id,id),isNull(mediaAssets.deletedAt))).limit(1);
      if(!asset)throw new ValidationError("Media asset not found.");
      const uses=await mediaReferences(tx,asset.path);
      if(uses.length)throw new ValidationError(`This image is used by ${uses.join(", ")}. Replace it there first.`);
      await tx.update(mediaAssets).set({deletedAt:new Date(),updatedAt:new Date(),updatedBy:admin.id}).where(eq(mediaAssets.id,id));
      return asset;
    });
    if(asset.source==="cloudinary"&&asset.cloudinaryPublicId)try{await removeMediaObject(asset.cloudinaryPublicId);}catch(error){await getDb().update(mediaAssets).set({deletedAt:null,updatedAt:new Date(),updatedBy:admin.id}).where(eq(mediaAssets.id,id));throw error;}
    await getDb().insert(adminAuditRecords).values({action:"archived",entityType:"media",entityId:String(id),summary:asset.source==="cloudinary"?"Deleted unused Cloudinary image.":"Archived unused external or legacy media.",actor:admin.id});
    revalidatePath("/","layout");
    return {success:asset.source==="cloudinary"?"Cloudinary image deleted.":"Media archived."};
  } catch(error) { return actionError(error); }
}
