import "./globals.css";
import type { Metadata } from "next";
import { Anton, Inter, Oswald } from "next/font/google";
import { getSiteSettings } from "@/lib/cms/queries";
import { siteUrl } from "@/lib/seo";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const oswald = Oswald({ subsets: ["latin"], variable: "--font-oswald" });
const anton = Anton({ subsets: ["latin"], weight: "400", variable: "--font-anton" });

export async function generateMetadata(): Promise<Metadata> {
  const company = await getSiteSettings();
  const description = company.seoDescription.trim() || `${company.name} provides fleet management and trucking support for carriers nationwide.`;
  return {
    metadataBase: new URL(siteUrl),
    title: {
      default: company.name,
      template: `%s | ${company.name}`,
    },
    description,
    icons: {
      icon: company.logo,
      shortcut: company.logo,
      apple: company.logo,
    },
    other: {
      "p:domain_verify": "0a6f91a2d4e0818c070b76334ad2ed2b",
    },
    openGraph: {
      type: "website",
      title: company.name,
      description,
      siteName: company.name,
      locale: "en_US",
    },
    twitter: {
      card: "summary_large_image",
      title: company.name,
      description,
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        "max-image-preview": "large",
      },
    },
  };
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" data-scroll-behavior="smooth">
      <body className={`${inter.variable} ${oswald.variable} ${anton.variable}`}>
        <div className="noise-overlay"></div>
        {children}
      </body>
    </html>
  );
}
