import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound, permanentRedirect } from "next/navigation";
import { cache } from "react";
import Footer from "@/components/layout/Footer";
import SubpageBreadcrumb from "@/components/layout/SubpageBreadcrumb";
import SubpageNavbar from "@/components/layout/SubpageNavbar";
import TopBar from "@/components/layout/TopBar";
import { CmsProvider } from "@/components/CmsProvider";
import JsonLd from "@/components/seo/JsonLd";
import { getSiteContent, getSlugRedirect, getTruckTypes, getTruckTypeBySlug } from "@/lib/cms/queries";
import { isValidSlug } from "@/lib/cms/validation";
import { absoluteUrl, breadcrumbJsonLd, organizationId, pageMetadata, truncateDescription } from "@/lib/seo";
import { bypassImageOptimization } from "@/lib/image";

interface TruckTypePageProps {
  params: Promise<{ slug: string }>;
}

export const revalidate = 300;

export async function generateStaticParams() {
  return (await getTruckTypes()).map(({ slug }) => ({ slug }));
}

const getTruckTypePage = cache(async (slug: string) => {
  if (!isValidSlug(slug)) notFound();
  const truck = await getTruckTypeBySlug(slug);
  if (truck) return truck;
  const redirectSlug = await getSlugRedirect("truck", slug);
  if (redirectSlug) permanentRedirect(`/truck-types/${redirectSlug}`);
  notFound();
});

export async function generateMetadata({ params }: TruckTypePageProps): Promise<Metadata> {
  const { slug } = await params;
  const [truck,content] = await Promise.all([getTruckTypePage(slug),getSiteContent()]);
  const title = truck.seoTitle?.trim() || `${truck.name} ${content.sectionCopy.truckSeoSuffix}`;
  const description = truncateDescription(truck.seoDescription?.trim() || truck.intro);
  const canonical = absoluteUrl(`/truck-types/${truck.slug}`);

  return {
    ...pageMetadata(title, description, `/truck-types/${truck.slug}`, truck.image, truck.imageAlt),
    openGraph: {
      type: "website",
      title,
      description,
      url: canonical,
      siteName: "Fleet Management US",
      locale: "en_US",
      images: [{ url: absoluteUrl(truck.image), alt: truck.imageAlt?.trim() || `${truck.name} truck` }],
    },
  };
}

export default async function TruckTypePage({ params }: TruckTypePageProps) {
  const { slug } = await params;
  const [truck, content] = await Promise.all([getTruckTypePage(slug), getSiteContent()]);

  const hasRevenueTarget = truck.weeklyGrossMin && truck.weeklyGrossMax;
  const copy=content.sectionCopy;
  const canonical = absoluteUrl(`/truck-types/${truck.slug}`);
  const relatedTruckTypes = content.truckTypes.filter(({ slug: relatedSlug }) => relatedSlug !== truck.slug).slice(0, 4);

  return (
    <CmsProvider content={content}>
      <JsonLd data={[
        {
          "@context": "https://schema.org",
          "@type": "Service",
          "@id": `${canonical}#service`,
          url: canonical,
          name: truck.name,
          serviceType: truck.spec,
          description: truck.intro,
          image: absoluteUrl(truck.image),
          provider: { "@type": "Organization", "@id": organizationId, name: content.company.name },
        },
        breadcrumbJsonLd([
          { name: content.company.name, item: absoluteUrl("/") },
          { name: copy.truckBreadcrumbLabel, item: absoluteUrl("/#trucks") },
          { name: truck.name, item: canonical },
        ]),
      ]} />
      <TopBar />
      <SubpageNavbar />
      <SubpageBreadcrumb parentHref="/#trucks" parentLabel={copy.truckBreadcrumbLabel} currentLabel={truck.name} />

      <main>
        <section className="relative overflow-hidden border-b border-[#1a1a1a] py-10 sm:py-14 lg:py-16">
          <div className="absolute inset-0 grid-bg opacity-40"></div>
          <div className="relative site-container grid items-center gap-8 sm:gap-10 lg:grid-cols-12">
            <div className="lg:col-span-7">
              <div className="mb-6 flex items-center gap-3 sm:mb-8 sm:gap-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center border border-accent text-accent sm:h-14 sm:w-14">
                  <i className={`fas ${truck.icon} text-2xl`}></i>
                </span>
                <span className="font-cond text-xs font-semibold uppercase tracking-[0.16em] text-accent sm:tracking-[0.24em]">{copy.truckItemLabel} {truck.num} {copy.detailCountConnector} {String(content.truckTypes.length).padStart(2, "0")}</span>
              </div>
              <div className="tag mb-5">{truck.spec}</div>
              <h1 className="break-words font-display text-[2.75rem] leading-[0.98] min-[360px]:text-5xl sm:text-7xl md:text-8xl lg:text-9xl">{truck.name.toUpperCase()}</h1>
              <p className="mt-6 max-w-3xl text-base leading-relaxed text-[#b0b0b0] sm:mt-8 sm:text-xl">{truck.intro}</p>
            </div>
            <div className="relative min-h-[260px] overflow-hidden border border-[#363636] sm:min-h-[430px] lg:col-span-5">
              <Image src={truck.image} alt={truck.imageAlt?.trim() || `${truck.name} truck`} fill sizes="(max-width: 1024px) 100vw, 42vw" unoptimized={bypassImageOptimization(truck.image)} className="object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
              <div className="absolute bottom-0 left-0 border-r border-t border-accent bg-black/85 px-5 py-3 font-cond text-xs uppercase tracking-[0.2em] text-accent">{copy.truckImageBadge}</div>
            </div>
          </div>
        </section>

        <section className="bg-[#0d0d0d] py-16 sm:py-24">
          <div className="site-container">
            <div className="grid gap-px border border-[#242424] bg-[#242424] lg:grid-cols-3">
              <article className="bg-[#141414] p-6 sm:p-8">
                <span className="font-cond text-xs uppercase tracking-[0.22em] text-accent">{copy.truckBestForLabel}</span>
                <h2 className="mt-4 font-display text-3xl tracking-wide">{truck.bestFor.toUpperCase()}</h2>
              </article>

              <article className="bg-[#141414] p-6 sm:p-8 lg:col-span-2">
                <span className="font-cond text-xs uppercase tracking-[0.22em] text-accent">{copy.truckReadinessLabel}</span>
                <p className="mt-4 text-lg leading-relaxed text-[#a8a8a8]">{truck.equipmentNotes}</p>
              </article>

              <article className="bg-[#141414] p-6 sm:p-8 lg:col-span-2">
                <div className="mb-6 flex items-center gap-3">
                  <span className="h-px w-8 bg-accent"></span>
                  <h2 className="font-display text-3xl tracking-wide">{copy.truckFreightHeading}</h2>
                </div>
                <ul className="grid gap-4 sm:grid-cols-2">
                  {truck.commonFreight.map((freight) => (
                    <li key={freight} className="flex items-start gap-3 text-[#a8a8a8]">
                      <i className="fas fa-check mt-1 text-xs text-accent"></i>
                      <span>{freight}</span>
                    </li>
                  ))}
                </ul>
              </article>

              <article className="bg-[rgba(255,107,0,0.08)] p-6 sm:p-8">
                <span className="font-cond text-xs uppercase tracking-[0.22em] text-accent">{copy.truckRevenueLabel}</span>
                {hasRevenueTarget ? (
                  <>
                    <div className="mt-4 break-words font-display text-3xl text-accent sm:text-4xl">
                      ${truck.weeklyGrossMin!.toLocaleString()}–${truck.weeklyGrossMax!.toLocaleString()}
                    </div>
                    <p className="mt-2 text-sm text-[#a8a8a8]">{copy.truckGrossPrefix} · {truck.avgMilesPerWeek} {copy.truckMilesSuffix}</p>
                  </>
                ) : (
                  <>
                    <div className="mt-4 font-display text-4xl text-accent">{copy.truckCustomValue}</div>
                    <p className="mt-2 text-sm leading-relaxed text-[#a8a8a8]">{copy.truckCustomDescription}</p>
                  </>
                )}
              </article>
            </div>
            {hasRevenueTarget && (
              <p className="mt-4 text-xs leading-relaxed text-[#6a6a6a]">{copy.truckRevenueDisclaimer}</p>
            )}
          </div>
        </section>

        {relatedTruckTypes.length > 0 && (
          <section className="border-t border-[#242424] bg-[#0d0d0d] py-16 sm:py-20">
            <div className="site-container">
              <div className="flex flex-wrap items-end justify-between gap-4">
                <div><span className="section-label">Explore equipment</span><h2 className="mt-5 font-display text-4xl sm:text-5xl">RELATED TRUCK TYPES</h2></div>
                <Link href="/blogs" className="font-cond text-xs uppercase tracking-[0.18em] text-accent">Visit our blog <i className="fas fa-arrow-right ml-2" /></Link>
              </div>
              <p className="mt-6 max-w-3xl leading-relaxed text-[#a8a8a8]">Discuss equipment fit with our <Link className="text-accent underline" href="/services/dispatch-services">truck dispatch service</Link> and review <Link className="text-accent underline" href="/services/load-assistance">load booking assistance</Link> before selecting lanes.</p>
              <div className="mt-8 grid gap-px border border-[#242424] bg-[#242424] sm:grid-cols-2 lg:grid-cols-4">
                {relatedTruckTypes.map((related) => <Link key={related.slug} href={`/truck-types/${related.slug}`} className="group bg-[#141414] p-6 transition hover:bg-[#181818]"><span className="font-cond text-xs text-accent">{related.spec}</span><h3 className="mt-3 font-display text-2xl">{related.name}</h3><span className="mt-5 inline-block font-cond text-xs uppercase tracking-[0.16em] text-[#9a9a9a] group-hover:text-accent">View truck type</span></Link>)}
              </div>
            </div>
          </section>
        )}

        <section className="relative overflow-hidden py-16 text-center sm:py-24">
          <div className="absolute inset-0 stripe-pattern"></div>
          <div className="relative max-w-3xl mx-auto px-4 sm:px-6">
            <span className="section-label center">{copy.truckCtaLabel}</span>
            <h2 className="mt-6 font-display text-4xl leading-none sm:text-6xl">{copy.truckCtaHeading} <span className="accent-text">{copy.truckCtaAccent}</span></h2>
            <p className="mx-auto mt-6 max-w-xl leading-relaxed text-[#9a9a9a]">{copy.truckCtaDescription}</p>
            <div className="mt-9 flex flex-col justify-center gap-3 sm:flex-row">
              <Link href="/#contact" className="btn-primary px-8 py-4 font-cond uppercase tracking-wider">
                {copy.truckCtaButton} <i className="fas fa-arrow-right ml-3"></i>
              </Link>
              <a href={content.company.phoneHref} className="btn-secondary px-8 py-4 font-cond uppercase tracking-wider">
                <i className="fas fa-phone mr-3 text-accent"></i> {copy.callButtonPrefix} {content.company.phone}
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </CmsProvider>
  );
}
