import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound, permanentRedirect } from "next/navigation";
import { cache } from "react";
import Footer from "@/components/layout/Footer";
import SubpageBreadcrumb from "@/components/layout/SubpageBreadcrumb";
import SubpageNavbar from "@/components/layout/SubpageNavbar";
import TopBar from "@/components/layout/TopBar";
import { CmsProvider } from "@/components/CmsProvider";
import JsonLd from "@/components/seo/JsonLd";
import { getServiceBySlug, getServices, getSiteContent, getSlugRedirect } from "@/lib/cms/queries";
import { isValidSlug } from "@/lib/cms/validation";
import { absoluteUrl, breadcrumbJsonLd, organizationId, pageMetadata, truncateDescription } from "@/lib/seo";
import { bypassImageOptimization } from "@/lib/image";

interface ServicePageProps {
  params: Promise<{ slug: string }>;
}

export const revalidate = 300;

export async function generateStaticParams() {
  return (await getServices()).map(({ slug }) => ({ slug }));
}

const getServicePage = cache(async (slug: string) => {
  if (!isValidSlug(slug)) notFound();
  const service = await getServiceBySlug(slug);
  if (service) return service;
  const redirectSlug = await getSlugRedirect("service", slug);
  if (redirectSlug) permanentRedirect(`/services/${redirectSlug}`);
  notFound();
});

export async function generateMetadata({ params }: ServicePageProps): Promise<Metadata> {
  const { slug } = await params;
  const service = await getServicePage(slug);
  const title = service.seoTitle?.trim() || service.detail.heading;
  const description = truncateDescription(service.seoDescription?.trim() || service.desc);
  const canonical = absoluteUrl(`/services/${service.slug}`);

  return {
    ...pageMetadata(title, description, `/services/${service.slug}`, service.image, service.imageAlt),
    openGraph: {
      type: "website",
      title,
      description,
      url: canonical,
      siteName: "Fleet Management US",
      locale: "en_US",
      images: [{ url: absoluteUrl(service.image || "/images/hero-fleet-highway.webp"), alt: service.imageAlt?.trim() || "Commercial truck on a highway" }],
    },
  };
}

export default async function ServicePage({ params }: ServicePageProps) {
  const { slug } = await params;
  const [service, content] = await Promise.all([getServicePage(slug), getSiteContent()]);

  const { detail } = service;
  const copy=content.sectionCopy;
  const canonical = absoluteUrl(`/services/${service.slug}`);
  const relatedServices = content.services.filter(({ slug: relatedSlug }) => relatedSlug !== service.slug).slice(0, 4);

  return (
    <CmsProvider content={content}>
      <JsonLd data={[
        {
          "@context": "https://schema.org",
          "@type": "Service",
          "@id": `${canonical}#service`,
          url: canonical,
          name: detail.heading,
          description: service.desc,
          ...(service.image ? { image: absoluteUrl(service.image) } : {}),
          provider: { "@type": "Organization", "@id": organizationId, name: content.company.name },
        },
        breadcrumbJsonLd([
          { name: content.company.name, item: absoluteUrl("/") },
          { name: copy.serviceBreadcrumbLabel, item: absoluteUrl("/#services") },
          { name: detail.heading, item: canonical },
        ]),
      ]} />
      <TopBar />
      <SubpageNavbar />
      <SubpageBreadcrumb parentHref="/#services" parentLabel={copy.serviceBreadcrumbLabel} currentLabel={detail.heading} />

      <main>
        <section className="relative overflow-hidden border-b border-[#1a1a1a] py-10 sm:py-14 lg:py-16">
          <div className="absolute inset-0 grid-bg opacity-50"></div>
          <div className="pointer-events-none absolute right-[6vw] top-1/2 hidden -translate-y-1/2 font-display text-[16rem] leading-none text-[#141414] xl:block 2xl:text-[18rem]" aria-hidden="true">
            {service.num}
          </div>
          <div className="relative site-container">
            <div className="mb-6 flex items-center gap-3 sm:mb-8 sm:gap-4">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center border border-accent text-accent sm:h-14 sm:w-14">
                {service.image ? <Image src={service.image} alt={service.imageAlt?.trim() || `${service.title} service image`} width={56} height={56} sizes="56px" unoptimized={bypassImageOptimization(service.image)} className="h-full w-full object-cover" /> : <i className={`fas ${service.icon} text-2xl`}></i>}
              </span>
              <span className="font-cond text-xs font-semibold uppercase tracking-[0.16em] text-accent sm:tracking-[0.24em]">{copy.serviceItemLabel} {service.num} {copy.detailCountConnector} {String(content.services.length).padStart(2,"0")}</span>
            </div>
            <h1 className="max-w-5xl break-words font-display text-4xl leading-tight sm:text-6xl lg:text-7xl">
              {detail.heading.toUpperCase()}
            </h1>
            <p className="mt-6 max-w-3xl text-base leading-relaxed text-[#b0b0b0] sm:mt-8 sm:text-xl">{detail.intro}</p>

            {detail.fee && (
              <div className="mt-8 flex w-full max-w-2xl items-start gap-3 border border-accent bg-[rgba(255,107,0,0.08)] p-4 sm:mt-10 sm:inline-flex sm:w-auto sm:gap-4 sm:p-6">
                <i className="fas fa-receipt mt-1 shrink-0 text-accent"></i>
                <div className="min-w-0">
                  <div className="font-cond text-xs uppercase tracking-[0.22em] text-accent">{copy.serviceFeeLabel}</div>
                  <p className="mt-1 break-words font-display text-xl tracking-wide min-[360px]:text-2xl sm:text-3xl">{detail.fee}</p>
                </div>
              </div>
            )}
          </div>
        </section>

        <section className="bg-[#0d0d0d] py-16 sm:py-24">
          <div className="site-container">
            <div className="grid gap-px border border-[#242424] bg-[#242424] lg:grid-cols-2">
              {detail.sections.map((section) => (
                <article
                  key={section.title}
                  className={`p-6 sm:p-9 ${section.highlight ? "bg-[rgba(255,107,0,0.08)]" : "bg-[#141414]"}`}
                >
                  <div className="mb-5 flex items-center gap-3">
                    <span className="h-px w-8 bg-accent"></span>
                    <h2 className="font-display text-2xl tracking-wide sm:text-3xl">{section.title.toUpperCase()}</h2>
                  </div>
                  {section.intro && <p className="leading-relaxed text-[#a8a8a8]">{section.intro}</p>}
                  {section.items && (
                    <ul className={`${section.intro ? "mt-6" : ""} space-y-4`}>
                      {section.items.map((item) => (
                        <li key={`${item.name ?? "item"}-${item.description}`} className="flex items-start gap-3 text-[#a8a8a8]">
                          <i className="fas fa-check mt-1 text-xs text-accent"></i>
                          <span className="leading-relaxed">
                            {item.name && <strong className="mr-1 font-semibold text-white">{item.name}:</strong>}
                            {item.description}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </article>
              ))}
            </div>

            {detail.revenueTargets && (
              <section className="mt-12 border border-[#242424] bg-[#141414] p-6 sm:p-9">
                <span className="section-label">{copy.serviceRevenueLabel}</span>
                <h2 className="mt-5 font-display text-3xl sm:text-5xl">{copy.serviceRevenueHeading}</h2>
                <p className="mt-3 text-sm text-[#9a9a9a]">{detail.revenueTargets.note}</p>
                <div className="mt-8 overflow-x-auto">
                  <table className="w-full min-w-[620px] text-left">
                    <thead className="border-b border-[#363636] font-cond text-xs uppercase tracking-[0.18em] text-[#6a6a6a]">
                      <tr>
                        <th className="px-4 py-4 font-medium">{copy.serviceEquipmentColumn}</th>
                        <th className="px-4 py-4 font-medium">{copy.serviceGrossColumn}</th>
                        <th className="px-4 py-4 font-medium">{copy.serviceMilesColumn}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {detail.revenueTargets.targets.map((target) => (
                        <tr key={target.truckType} className="border-b border-[#242424] last:border-0">
                          <td className="px-4 py-5 font-semibold text-white">{target.truckType}</td>
                          <td className="px-4 py-5 font-display text-xl text-accent">
                            ${target.weeklyGrossMin.toLocaleString()}–${target.weeklyGrossMax.toLocaleString()}
                          </td>
                          <td className="px-4 py-5 text-[#a8a8a8]">{target.avgMilesPerWeek}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="mt-5 text-xs leading-relaxed text-[#6a6a6a]">{detail.revenueTargets.disclaimer}</p>
              </section>
            )}

            {detail.closing && (
              <div className="mt-12 border-l-2 border-accent bg-[#141414] p-6 sm:p-8">
                <p className="max-w-4xl text-lg leading-relaxed text-[#c0c0c0] sm:text-xl">{detail.closing}</p>
              </div>
            )}
          </div>
        </section>

        <section className="border-t border-[#242424] py-12">
          <div className="site-container">
            <h2 className="font-display text-3xl">Plan your next step</h2>
            <p className="mt-4 max-w-3xl leading-relaxed text-[#a8a8a8]">
              Compare <Link className="text-accent underline" href="/services/dispatch-services">dispatch responsibilities</Link>,
              {" "}<Link className="text-accent underline" href="/services/load-assistance">load selection</Link> and
              {" "}<Link className="text-accent underline" href="/services/back-office-support">back-office support</Link> when choosing your service scope.
              Read our <Link className="text-accent underline" href="/blogs/owner-operator-dispatch-pricing-responsibilities">guide to dispatch pricing and questions to ask</Link>,
              then <Link className="text-accent underline" href="/#contact">request a service discussion</Link> for your equipment and lanes.
            </p>
            {service.slug === "mc-leasing" && <p className="mt-4 max-w-3xl text-sm leading-relaxed text-[#a8a8a8]">Verify the proposed operating carrier through <a className="text-accent underline" href="https://www.fmcsa.dot.gov/registration">FMCSA registration resources</a> and obtain qualified review of the lease and insurance responsibilities before operating.</p>}
            {service.slug === "dispatch-services" && <p className="mt-4 max-w-3xl text-sm leading-relaxed text-[#a8a8a8]">For the distinction between dispatch assistance and brokerage, review <a className="text-accent underline" href="https://www.fmcsa.dot.gov/newsroom/fmcsa-issues-final-guidance-clarifying-broker-and-bona-fide-agents-definitions">FMCSA&apos;s broker and bona fide agent guidance</a>.</p>}
            {service.slug === "dispatch-services" && <p className="mt-4 max-w-3xl leading-relaxed text-[#a8a8a8]">Explore equipment-specific support for <Link className="text-accent underline" href="/truck-types/box-truck">box trucks</Link>, <Link className="text-accent underline" href="/truck-types/dry-van">dry vans</Link>, <Link className="text-accent underline" href="/truck-types/reefer">reefers</Link>, <Link className="text-accent underline" href="/truck-types/flatbed">flatbeds</Link> and <Link className="text-accent underline" href="/truck-types/hotshot">hotshot trucks</Link>.</p>}
          </div>
        </section>

        {relatedServices.length > 0 && (
          <section className="border-t border-[#242424] bg-[#0d0d0d] py-16 sm:py-20">
            <div className="site-container">
              <div className="flex flex-wrap items-end justify-between gap-4">
                <div><span className="section-label">Explore more</span><h2 className="mt-5 font-display text-4xl sm:text-5xl">RELATED SERVICES</h2></div>
                <Link href="/blogs" className="font-cond text-xs uppercase tracking-[0.18em] text-accent">Visit our blog <i className="fas fa-arrow-right ml-2" /></Link>
              </div>
              <div className="mt-8 grid gap-px border border-[#242424] bg-[#242424] sm:grid-cols-2 lg:grid-cols-4">
                {relatedServices.map((related) => <Link key={related.slug} href={`/services/${related.slug}`} className="group bg-[#141414] p-6 transition hover:bg-[#181818]"><span className="font-cond text-xs text-accent">{related.num}</span><h3 className="mt-3 font-display text-2xl">{related.title}</h3><span className="mt-5 inline-block font-cond text-xs uppercase tracking-[0.16em] text-[#9a9a9a] group-hover:text-accent">View service</span></Link>)}
              </div>
            </div>
          </section>
        )}

        <section className="relative overflow-hidden py-16 text-center sm:py-24">
          <div className="absolute inset-0 stripe-pattern"></div>
          <div className="relative max-w-3xl mx-auto px-4 sm:px-6">
            <span className="section-label center">{copy.serviceCtaLabel}</span>
            <h2 className="mt-6 font-display text-4xl leading-none sm:text-6xl">{copy.serviceCtaHeading} <span className="accent-text">{copy.serviceCtaAccent}</span></h2>
            <p className="mx-auto mt-6 max-w-xl leading-relaxed text-[#9a9a9a]">{copy.serviceCtaDescription}</p>
            <div className="mt-9 flex flex-col justify-center gap-3 sm:flex-row">
              <Link href="/#contact" className="btn-primary px-8 py-4 font-cond uppercase tracking-wider">
                {copy.serviceCtaButton} <i className="fas fa-arrow-right ml-3"></i>
              </Link>
              <a href={content.company.phoneHref} className="btn-secondary px-8 py-4 font-cond uppercase tracking-wider">
                <i className="fas fa-phone mr-3 text-accent"></i> {copy.callButtonPrefix} {content.company.phone}
              </a>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </CmsProvider>
  );
}
