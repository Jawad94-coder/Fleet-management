import HomePage from "@/components/HomePage";
import DispatchAnswers from "@/components/sections/DispatchAnswers";
import JsonLd from "@/components/seo/JsonLd";
import { getSiteContent, getSiteSettings } from "@/lib/cms/queries";
import { absoluteUrl, breadcrumbJsonLd, organizationId, pageMetadata } from "@/lib/seo";

export const revalidate = 300;

export async function generateMetadata() {
  const company = await getSiteSettings();
  const title = company.seoTitle.trim() || "Truck Dispatch Services for US Carriers | Fleet Management US";
  const metadata = pageMetadata(title, company.seoDescription, "/");
  metadata.title = { absolute: title };
  return metadata;
}

export default async function Home() {
  const content = await getSiteContent();
  const { company } = content;
  const homeUrl = absoluteUrl("/");
  const logo = absoluteUrl(company.logo);
  const sameAs = content.socialLinks.map(({ href }) => href);

  return (
    <>
      <JsonLd data={[
        {
          "@context": "https://schema.org",
          "@type": "Organization",
          "@id": organizationId,
          name: company.name,
          url: homeUrl,
          logo,
          ...(sameAs.length ? { sameAs } : {}),
        },
        {
          "@context": "https://schema.org",
          "@type": "WebSite",
          "@id": absoluteUrl("/#website"),
          name: company.name,
          url: homeUrl,
          inLanguage: "en-US",
          publisher: { "@id": organizationId },
        },
        breadcrumbJsonLd([{ name: company.name, item: homeUrl }]),
      ]} />
      <HomePage content={content}><DispatchAnswers /></HomePage>
    </>
  );
}
