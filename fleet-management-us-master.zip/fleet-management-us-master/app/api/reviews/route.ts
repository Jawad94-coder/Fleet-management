import { getDb } from "@/db";
import { testimonials } from "@/db/schema";
import { validateReview } from "@/lib/cms/review-validation";
import { consumeRateLimit, submissionFingerprint } from "@/lib/public-rate-limit";
import { readSubmission } from "@/lib/submission-request";
import { logServerError } from "@/lib/server-error";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  let body: unknown;
  try { body = await readSubmission(request); }
  catch { return Response.json({error:"Invalid submission."},{status:400}); }
  if (!body || typeof body !== "object" || Array.isArray(body)) return Response.json({error:"Invalid submission."},{status:400});
  const input = body as Record<string, unknown>;
  if (input.website) return Response.json({error:"Invalid submission."},{status:400});
  const data = new FormData();
  for (const key of ["name","company","role","equipment","location","tenure","quote","initials","rating"]) {
    if (typeof input[key] === "string" || typeof input[key] === "number") data.set(key,String(input[key]));
  }
  data.set("status","pending");
  data.set("sortOrder","0");
  const result = validateReview(data);
  if (!result.ok) return Response.json({error:result.state.error,fieldErrors:result.state.fieldErrors},{status:400});
  try {
    if (!await consumeRateLimit("public_source",submissionFingerprint(request,"source"),30) ||
        !await consumeRateLimit("review_submission",submissionFingerprint(request,result.data.name),3)) {
      return Response.json({error:"Too many submissions. Please try again later."},{status:429,headers:{"Retry-After":"900"}});
    }
    await getDb().insert(testimonials).values({...result.data,status:"pending",createdBy:"public",updatedBy:"public"});
    revalidatePath("/admin","layout");
    return Response.json({ok:true,message:"Your review was received and is awaiting approval."},{status:201});
  } catch(error) {
    logServerError("Review submission failed.",error);
    return Response.json({error:"Your review could not be saved. Please try again."},{status:500});
  }
}
