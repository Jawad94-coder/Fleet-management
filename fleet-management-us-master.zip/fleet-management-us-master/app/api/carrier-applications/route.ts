import { readSubmission } from "@/lib/submission-request";
import { revalidatePath } from "next/cache";
import { getDb } from "@/db";
import { carrierApplications } from "@/db/schema";
import { validateCarrierApplication } from "@/lib/carrier-application";
import { getPublishedTruckTypeNames } from "@/lib/cms/queries";
import { consumeRateLimit, submissionFingerprint } from "@/lib/public-rate-limit";
import { logServerError } from "@/lib/server-error";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: unknown;

  try {
    body = await readSubmission(request);
  } catch {
    return Response.json({ error: "Invalid submission." }, { status: 400 });
  }

  if (
    body &&
    typeof body === "object" &&
    !Array.isArray(body) &&
    typeof (body as Record<string, unknown>).website === "string" &&
    (body as Record<string, string>).website.trim()
  ) {
    return Response.json({ error: "Invalid submission." }, { status: 400 });
  }

  try {
    if (!await consumeRateLimit("public_source", submissionFingerprint(request, "source"), 30)) return Response.json({error:"Too many submissions. Please try again later."},{status:429,headers:{"Retry-After":"900"}});
    const result = validateCarrierApplication(
      body,
      new Set(await getPublishedTruckTypeNames()),
    );
    if (!result.ok) {
      return Response.json({ error: result.error }, { status: 400 });
    }

    const allowed=await consumeRateLimit("carrier_application",submissionFingerprint(request,result.data.email));
    if(!allowed)return Response.json({error:"Too many submissions. Please wait before trying again."},{status:429,headers:{"Retry-After":"900"}});

    const [application] = await getDb()
      .insert(carrierApplications)
      .values(result.data)
      .returning({ id: carrierApplications.id });

    revalidatePath("/admin", "layout");
    return Response.json({ ok: true, id: application.id }, { status: 201 });
  } catch (error) {
    logServerError("Carrier application submission failed.",error);
    return Response.json(
      { error: "We could not submit your request. Please try again shortly." },
      { status: 500 },
    );
  }
}
