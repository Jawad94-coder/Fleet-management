# Technical On-Page SEO Audit

**Audit date:** September 27, 2026  
**Scope:** Public homepage sections, service detail pages, truck-type detail pages, blog index/article rendering, CMS image metadata, internal links, Drizzle schema, and Next.js image configuration.  
**Change policy:** This is a read-only audit. No application code, content, schema, or migration was changed.

## Executive summary

| Priority | Finding | Current effect |
| --- | --- | --- |
| High | Public content images bypass the Next.js image pipeline | Hero, service, truck, and blog imagery is rendered as CSS backgrounds; the remaining `next/image` instances explicitly opt out of optimization. This removes automatic responsive sources and format/size optimization and may hurt LCP and transferred bytes. |
| High | Cloudinary is not configured in `images.remotePatterns` | `next.config.ts` has no `images` configuration. Current code avoids an error only because every remote `Image` uses an identity loader plus `unoptimized`; a normal optimized Cloudinary `Image` would not be allowed. |
| Medium | Service and truck records have no per-record SEO override columns | Blogs already have `seo_title` and `seo_description`; services and trucks do not. None of the three tables has `seo_keywords`. |
| Medium | Detail pages have little contextual internal linking | Published detail pages are discoverable, but service and truck pages do not link to related services, truck types, or relevant articles. Blog articles currently contain no contextual links to service/truck detail pages. |
| Medium | Homepage service discovery depends on editable `cta_href` | Current published values are correct, but editors can point a service card elsewhere and remove that page's only content-level inbound link. |
| Low | Some media-library rows have null registry alt text | The public logo receives a valid content-specific alt from site settings, and two other null-alt assets are not used by published content. There is no current missing/generic public alt defect, but the media registry is not a reliable fallback. |

## High priority

### H1. Content imagery bypasses responsive image optimization

The audit found **no raw `<img>` elements** in the public surfaces. However, using no raw `<img>` tags does not mean the site is receiving `next/image` benefits:

- `src/components/sections/Hero.tsx:33` renders all hero slides with `backgroundImage`.
- `src/components/sections/Services.tsx:31` renders service images with `backgroundImage`.
- `app/services/[slug]/page.tsx:94` renders the detail-page service image with `backgroundImage`.
- `app/truck-types/[slug]/page.tsx:103` renders the truck hero with `backgroundImage`.
- `app/blogs/page.tsx:18` renders blog-card images with `backgroundImage`.
- `app/blogs/[slug]/page.tsx:34` renders the article hero with `backgroundImage`.
- `src/components/blog/BlogMarkdown.tsx:19` converts Markdown images into CSS backgrounds.

CSS background images do not receive Next.js-generated responsive `srcset` values, intrinsic sizing, automatic modern-format selection, or built-in image lazy loading. The hero's first image is particularly important because it is a likely Largest Contentful Paint candidate. The hero component defers later slides, but its first slide remains a CSS background rather than an image the framework can size and preload deliberately.

The actual `next/image` uses also bypass optimization:

- `src/components/sections/About.tsx:26-30`
- `src/components/sections/Testimonials.tsx:77`
- `src/components/layout/Navbar.tsx:17`
- `src/components/layout/SubpageNavbar.tsx:22`
- `src/components/layout/Footer.tsx:21`

Each supplies an identity loader (`loader={({ src }) => src}`) and `unoptimized`. This retains some `Image` component behavior, such as aspect-ratio reservation and default lazy loading where not preloaded, but it disables the optimizer and responsive generated sources.

**Recommendation for the implementation phase:** use `Image` with `fill` and accurate `sizes` for content images, preload only the true above-the-fold LCP image, and leave decorative imagery explicitly decorative. If Cloudinary transformations are preferred over the built-in optimizer, use a real Cloudinary loader that emits width/quality transformations rather than an identity loader. Do not convert icon-like or intentionally decorative backgrounds unless that improves semantics or performance.

### H2. Cloudinary is not whitelisted for optimized remote images

`next.config.ts` contains no `images` block and no `images.remotePatterns`. Therefore, **Cloudinary is not properly whitelisted for the default Next.js image optimizer**.

Current remote `Image` calls do not expose this immediately because they all use `unoptimized` with a custom identity loader. Current published media queried during this audit is local, legacy Supabase, or external; there were no published Cloudinary-backed references in the audited content snapshot. New uploads are nevertheless Cloudinary-backed, so this becomes an operational SEO/performance issue as soon as an uploaded image is assigned to public content.

**Recommendation for the implementation phase:** add a narrow HTTPS `remotePatterns` entry for the actual Cloudinary delivery host and cloud path (normally `res.cloudinary.com/<cloud-name>/image/upload/**`). Add equally narrow patterns only for legacy remote hosts that must remain renderable. Then remove `unoptimized`/identity loaders where the default optimizer is desired. Avoid a wildcard host rule.

## Medium priority

### M1. Per-record SEO override coverage is inconsistent

Schema inspection found:

| Table | `seo_title` | `seo_description` | `seo_keywords` |
| --- | --- | --- | --- |
| `cms_services` | Missing | Missing | Missing |
| `cms_truck_types` | Missing | Missing | Missing |
| `cms_blog_posts` | Present, nullable (`varchar(240)`) | Present, nullable (`varchar(500)`) | Missing |

Site-wide `cms_site_settings` also already has non-null `seo_title` and `seo_description` fields. The gap is specifically at the service/truck record level, plus keywords across all three record types.

#### Proposed Drizzle schema diff (proposal only)

```diff
 export const cmsServices = pgTable("cms_services", {
   // existing columns...
+  seoTitle: varchar("seo_title", { length: 240 }),
+  seoDescription: varchar("seo_description", { length: 500 }),
+  seoKeywords: jsonb("seo_keywords").$type<string[]>(),
 });

 export const cmsTruckTypes = pgTable("cms_truck_types", {
   // existing columns...
+  seoTitle: varchar("seo_title", { length: 240 }),
+  seoDescription: varchar("seo_description", { length: 500 }),
+  seoKeywords: jsonb("seo_keywords").$type<string[]>(),
 });

 export const cmsBlogPosts = pgTable("cms_blog_posts", {
   // seoTitle and seoDescription already exist
+  seoKeywords: jsonb("seo_keywords").$type<string[]>(),
 });
```

All proposed columns are nullable: omitting `.notNull()` and a default preserves existing records and allows the current generated-metadata fallback. After an approved schema edit, the repository's established flow is `npm run db:generate`, followed by review of the generated SQL before migration.

Adding columns alone would not expose them to editors. A complete later implementation must also update the admin validators/forms/actions, public query projections/types, and `generateMetadata()` fallback logic.

**SEO caveat:** Google ignores the legacy `meta keywords` tag. `seo_keywords` can still be useful as editorial taxonomy or input to internal linking/structured content, but it should not outrank unique titles, useful descriptions, or page copy. Blog posts already have a `tags` array, so adding a separate blog keyword array may duplicate that taxonomy.

### M2. Detail pages lack contextual related-content links

Current inbound-link coverage is functional:

- `src/components/sections/Services.tsx:25` links homepage service cards to their detail pages. Live published `cta_href` values matched `/services/<slug>` for all seven published services.
- `src/components/sections/TruckTypes.tsx:32` links all nine published truck cards to `/truck-types/<slug>`.
- `app/blogs/page.tsx:18` links both the image and title/read-more controls to each published article.
- The published global navigation includes `/blogs`; detail pages render the shared subpage navigation and footer, so services and trucks have a global link to the blog index.
- Breadcrumbs return service pages to `/#services`, truck pages to `/#trucks`, and articles to `/blogs`.

What is missing is contextual linking:

- Service detail pages do not link to related service pages, supported truck types, or relevant blog articles.
- Truck detail pages do not link to related truck types, relevant services, or articles.
- The two currently published Markdown articles contain no internal links to service or truck detail pages.

Global navigation prevents isolation, but contextual links supply stronger topical relationships and more useful crawl paths. A later implementation should add a small, genuinely related content block or editorially controlled links; it should not generate indiscriminate site-wide link lists.

### M3. A service page can become orphaned through editable CTA data

The homepage service link uses `svc.ctaHref ?? /services/${svc.slug}` rather than always using the canonical detail URL. Current published database values are correct, so **no service page is currently orphaned**. However, changing a card CTA to an anchor or external URL would remove that detail page's only content-level homepage inbound link. Sitemap discovery is not a substitute for internal linking.

Consider separating “detail URL” from the editable CTA destination, or always linking the card/title to `/services/<slug>` and keeping an optional secondary CTA independently editable.

## Low priority

### L1. Current alt text is valid, but the media registry is not authoritative

The live published-data cross-reference found **no public image rendered with missing, empty, or generic alt text** such as `image` or `photo`. The audited records currently resolve as follows:

| Render location | Rendering method | Alt/accessible-name source | Current published result |
| --- | --- | --- | --- |
| `src/components/layout/Navbar.tsx:17` | `Image` | `cms_site_settings.logo_alt` | `Fleet Management US`; valid |
| `src/components/layout/SubpageNavbar.tsx:22` | `Image` | `cms_site_settings.logo_alt` | Valid |
| `src/components/layout/Footer.tsx:21` | `Image` | `cms_site_settings.logo_alt` | Valid |
| `src/components/sections/Hero.tsx:33` | CSS background inside `aria-hidden` wrapper | Decorative; `cms_hero_content.image_alts` is loaded but intentionally not exposed | No missing-alt defect; decorative imagery is hidden from accessibility APIs |
| `src/components/sections/About.tsx:26` | `Image` | `cms_about_content.image_alt` | Descriptive |
| `src/components/sections/Services.tsx:31` | CSS background with `role="img"` | `cms_services.image_alt`, then service title fallback | No published service currently has an image; no current defect |
| `app/services/[slug]/page.tsx:94` | CSS background with `role="img"` | `cms_services.image_alt`, then service title fallback | No published service currently has an image; no current defect |
| `app/truck-types/[slug]/page.tsx:103` | CSS background with `role="img"` | `cms_truck_types.image_alt`, then truck name fallback | All nine published trucks have descriptive values |
| `app/blogs/page.tsx:18` | CSS background with `role="img"` | `cms_blog_posts.featured_image_alt`, then post title fallback | Both published posts have descriptive values |
| `app/blogs/[slug]/page.tsx:34` | CSS background with `role="img"` | `cms_blog_posts.featured_image_alt`, then post title fallback | Both published posts have descriptive values |
| `src/components/blog/BlogMarkdown.tsx:19` | CSS background with `role="img"` | Markdown `![alt](url)` alt segment | Both published inline images have descriptive Markdown alt text |
| `src/components/sections/Testimonials.tsx:77` | `Image` | `cms_testimonials.avatar_alt`, then reviewer name fallback | No published testimonial currently has an avatar image |

`cms_media_assets.alt_text` is not read by these renderers. The application copies or stores alt text in content-specific fields, which is consistent with allowing context-specific descriptions but means media-library alt text is not a runtime fallback.

The non-deleted media snapshot had three null `cms_media_assets.alt_text` values:

1. `/images/logo.png` — publicly rendered, but safely named by `cms_site_settings.logo_alt`.
2. A legacy Supabase `jamshed.jpeg` asset — not referenced by published content in the audited surfaces.
3. An external Picsum asset — not referenced by published content in the audited surfaces.

For future assignments, the field that should supply the rendered alt remains the target content field: `image_alt` for services/trucks/about, `featured_image_alt` for blog heroes, `avatar_alt` for testimonials, `logo_alt` for company logos, and the Markdown alt segment for inline article images. Media-library `alt_text` can prefill those fields, but should not silently overwrite a context-specific description.

### L2. Title fallbacks prevent missing names but may be less descriptive

Service, truck, blog, and testimonial renderers fall back to the record title/name when a dedicated alt field is null. This is better than an unnamed image, but a title can describe the page rather than the image. Admin validation should require a descriptive alt value whenever an informative image is selected, while decorative images should use deliberate empty alt semantics rather than a title fallback.

## Orphan-page inventory

Based on the current published database snapshot and the rendered link paths:

| Public page group | Published count | Internal inbound source | Orphaned now? |
| --- | ---: | --- | --- |
| `/services/[slug]` | 7 | Homepage service cards | No |
| `/truck-types/[slug]` | 9 | Homepage truck cards | No |
| `/blogs` | 1 index | Global navigation/footer | No |
| `/blogs/[slug]` | 2 | Blog index cards | No |

This inventory covers published routes, not draft/archived content that intentionally has no public inbound links. The editable service CTA risk is documented under M3.

## Image configuration verdict

- **Cloudinary allowlist:** No. `next.config.ts` has no `images.remotePatterns`.
- **Raw `<img>` tags:** None found in the audited public surfaces.
- **`next/image` everywhere:** No. Major content images are CSS backgrounds.
- **Automatic optimization where `next/image` is used:** No. Every audited instance opts out with `unoptimized` and an identity loader.
- **Automatic lazy loading:** Available only to non-preloaded `Image` instances; CSS backgrounds do not receive Next.js image lazy loading.
- **Responsive sizing:** `About` and testimonial avatars declare `sizes`, but optimization is disabled. CSS backgrounds do not produce responsive source candidates.

## Suggested implementation order

1. Fix the image delivery path, beginning with the first hero/LCP image and blog/truck content imagery; add narrow Cloudinary `remotePatterns` or a genuine Cloudinary transformation loader.
2. Add the approved nullable SEO schema fields through the normal Drizzle generate/review/migrate flow, then wire them through admin and public metadata code.
3. Add editorially relevant cross-links among services, equipment pages, and articles; make canonical service-card linking resilient to CTA edits.
4. Tighten admin image-alt validation and optionally use media-library alt text only as an initial field value.

No fixes or migrations were applied as part of this audit.
