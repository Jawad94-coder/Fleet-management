import "server-only";

import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

declare global {
  var fmuPostgresPool: Pool | undefined;
}

let database: NodePgDatabase<typeof schema> | undefined;

export function getDb() {
  if (database) return database;

  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error("DATABASE_URL is not configured.");
  }

  const pool =
    globalThis.fmuPostgresPool ??
    new Pool({
      connectionString,
      max: 1,
    });

  if (process.env.NODE_ENV !== "production") {
    globalThis.fmuPostgresPool = pool;
  }

  database = drizzle(pool, { schema });
  return database;
}
