import {
  boolean,
  check,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import type { FleetService } from "../data/content";
import type { AgreementSectionContent, SectionCopyContent } from "../lib/cms/types";

export const applicationStatuses = [
  "new",
  "contacted",
  "qualified",
  "onboarding",
  "closed",
  "rejected",
] as const;

export type ApplicationStatus = (typeof applicationStatuses)[number];

export const applicationStatus = pgEnum(
  "carrier_application_status",
  applicationStatuses,
);

export const contentStatuses = ["published", "draft"] as const;
export type ContentStatus = (typeof contentStatuses)[number];
export const contentStatus = pgEnum("cms_content_status", contentStatuses);

export { reviewStatuses, type ReviewStatus } from "../lib/cms/review-validation.ts";
import { reviewStatuses } from "../lib/cms/review-validation.ts";
export const reviewStatus = pgEnum("cms_review_status", reviewStatuses);

export const blogStatuses = ["draft", "published", "archived"] as const;
export type BlogStatus = (typeof blogStatuses)[number];
export const blogStatus = pgEnum("cms_blog_status", blogStatuses);

export const carrierApplications = pgTable("carrier_applications", {
  id: serial("id").primaryKey(),
  fullName: varchar("full_name", { length: 160 }).notNull(),
  companyName: varchar("company_name", { length: 200 }),
  phone: varchar("phone", { length: 60 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  truckType: varchar("truck_type", { length: 100 }).notNull(),
  currentZip: varchar("current_zip", { length: 10 }).notNull(),
  preferredLanes: varchar("preferred_lanes", { length: 500 }),
  message: text("message"),
  smsOptIn: boolean("sms_opt_in").default(false).notNull(),
  smsConsentAt: timestamp("sms_consent_at", { withTimezone: true }),
  status: applicationStatus("status").default("new").notNull(),
  internalNotes: text("internal_notes"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const siteSettings = pgTable("cms_site_settings", {
  id: integer("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  legalName: varchar("legal_name", { length: 200 }).default("Fleet Management US LLC").notNull(),
  shortName: varchar("short_name", { length: 160 }).notNull(),
  tagline: varchar("tagline", { length: 160 }).notNull(),
  estYear: integer("est_year").notNull(),
  dot: varchar("dot", { length: 40 }).notNull(),
  mc: varchar("mc", { length: 40 }).notNull(),
  phone: varchar("phone", { length: 60 }).notNull(),
  phoneHref: varchar("phone_href", { length: 100 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  emailHref: varchar("email_href", { length: 240 }).notNull(),
  address: varchar("address", { length: 240 }).notNull(),
  city: varchar("city", { length: 160 }).notNull(),
  website: varchar("website", { length: 240 }).notNull(),
  hours: varchar("hours", { length: 240 }).notNull(),
  copyright: varchar("copyright", { length: 240 }).notNull(),
  logo: varchar("logo", { length: 1000 }).default("/images/logo.png").notNull(),
  logoAlt: varchar("logo_alt", { length: 500 }).default("Fleet Management US").notNull(),
  seoTitle: varchar("seo_title", { length: 240 }).default("Fleet Management US — Your Partner for Reliable Trucking Operations").notNull(),
  seoDescription: varchar("seo_description", { length: 500 }).default("Fleet management, dispatch, leasing, and back-office support for carriers nationwide.").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
}).enableRLS();

export const heroContent = pgTable("cms_hero_content", {
  id: integer("id").primaryKey(),
  heading: varchar("heading", { length: 240 }).default("FLEET\nMANAGEMENT").notNull(),
  headingAccent: varchar("heading_accent", { length: 120 }).default("US").notNull(),
  tagline: varchar("tagline", { length: 240 }).notNull(),
  description: text("description").notNull(),
  primaryCtaLabel: varchar("primary_cta_label", { length: 120 }).default("Get Started").notNull(),
  primaryCtaHref: varchar("primary_cta_href", { length: 200 }).default("#contact").notNull(),
  secondaryCtaLabel: varchar("secondary_cta_label", { length: 120 }).default("View Services").notNull(),
  secondaryCtaHref: varchar("secondary_cta_href", { length: 200 }).default("#services").notNull(),
  showAuthority: boolean("show_authority").default(true).notNull(),
  images: jsonb("images").$type<string[]>().default([]).notNull(),
  imageAlts: jsonb("image_alts").$type<string[]>().default([]).notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
}).enableRLS();

export const sectionCopy = pgTable("cms_section_copy", {
  id: integer("id").primaryKey(),
  content: jsonb("content").$type<SectionCopyContent>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
}).enableRLS();

export const aboutContent = pgTable("cms_about_content", {
  id: integer("id").primaryKey(),
  sectionLabel: varchar("section_label", { length: 160 }).default("About Fleet Management US").notNull(),
  heading: varchar("heading", { length: 240 }).default("BUILT BY DRIVERS,").notNull(),
  headingAccent: varchar("heading_accent", { length: 240 }).default("FOR DRIVERS.").notNull(),
  establishedText: varchar("established_text", { length: 200 }).default("EST. 2014 · CHICAGO, IL").notNull(),
  yearsLabel: varchar("years_label", { length: 240 }).default("Years Building Careers on the Road").notNull(),
  image: varchar("image", { length: 1000 }).notNull(),
  imageAlt: varchar("image_alt", { length: 500 }).default("Fleet at loading dock").notNull(),
  years: varchar("years", { length: 40 }).notNull(),
  description1: text("description_1").notNull(),
  description2: text("description_2").notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
}).enableRLS();

export const contactSettings = pgTable("cms_contact_settings", {
  id: integer("id").primaryKey(),
  sectionLabel: varchar("section_label", { length: 160 }).default("Contact").notNull(),
  heading: varchar("heading", { length: 240 }).default("LET'S GET YOUR").notNull(),
  headingAccent: varchar("heading_accent", { length: 240 }).default("WHEELS ROLLING.").notNull(),
  description: text("description").notNull(),
  dispatchStatusText: varchar("dispatch_status_text", { length: 160 }).default("DISPATCH ONLINE NOW").notNull(),
  dispatchResponseTime: varchar("dispatch_response_time", { length: 80 }).notNull(),
  afterHoursText: varchar("after_hours_text", { length: 240 }).default("After-hours line available for active carriers.").notNull(),
  privacyDisclaimer: text("privacy_disclaimer").default("By submitting, you agree to be contacted by Fleet Management US regarding carrier opportunities. We never share your information.").notNull(),
  enabled: boolean("enabled").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
}).enableRLS();

export const navigationLinks = pgTable("cms_navigation_links", {
  id: serial("id").primaryKey(),
  href: varchar("href", { length: 200 }).notNull().unique(),
  label: varchar("label", { length: 120 }).notNull(),
  sortOrder: integer("sort_order").notNull(),
  status: contentStatus("status").default("published").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const socialLinks = pgTable("cms_social_links", {
  id: serial("id").primaryKey(),
  label: varchar("label", { length: 120 }).notNull().unique(),
  icon: varchar("icon", { length: 120 }).notNull(),
  href: varchar("href", { length: 1000 }).notNull(),
  sortOrder: integer("sort_order").notNull(),
  status: contentStatus("status").default("published").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const heroStatistics = pgTable("cms_hero_statistics", {
  id: serial("id").primaryKey(),
  label: varchar("label", { length: 160 }).notNull().unique(),
  value: varchar("value", { length: 80 }).notNull(),
  accent: boolean("accent").default(false).notNull(),
  sortOrder: integer("sort_order").notNull(),
  status: contentStatus("status").default("published").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const aboutFeatures = pgTable("cms_about_features", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 160 }).notNull().unique(),
  icon: varchar("icon", { length: 120 }).notNull(),
  description: text("description").notNull(),
  accent: boolean("accent").default(false).notNull(),
  sortOrder: integer("sort_order").notNull(),
  status: contentStatus("status").default("published").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const services = pgTable("cms_services", {
  id: serial("id").primaryKey(),
  num: varchar("num", { length: 20 }).notNull().unique(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  icon: varchar("icon", { length: 120 }).notNull(),
  image: varchar("image", { length: 1000 }),
  imageAlt: varchar("image_alt", { length: 500 }),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull(),
  ctaLabel: varchar("cta_label", { length: 120 }).default("View service").notNull(),
  ctaHref: varchar("cta_href", { length: 1000 }).notNull(),
  detail: jsonb("detail").$type<FleetService["detail"]>().notNull(),
  seoTitle: varchar("seo_title", { length: 240 }),
  seoDescription: varchar("seo_description", { length: 500 }),
  seoKeywords: jsonb("seo_keywords").$type<string[]>(),
  sortOrder: integer("sort_order").notNull(),
  status: contentStatus("status").default("published").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const truckTypes = pgTable("cms_truck_types", {
  id: serial("id").primaryKey(),
  num: varchar("num", { length: 20 }).notNull().unique(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  icon: varchar("icon", { length: 120 }).notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  spec: varchar("spec", { length: 200 }).notNull(),
  image: varchar("image", { length: 1000 }).notNull(),
  imageAlt: varchar("image_alt", { length: 500 }).default("").notNull(),
  intro: text("intro").notNull(),
  bestFor: text("best_for").notNull(),
  commonFreight: jsonb("common_freight").$type<string[]>().notNull(),
  equipmentNotes: text("equipment_notes").notNull(),
  weeklyGrossMin: integer("weekly_gross_min"),
  weeklyGrossMax: integer("weekly_gross_max"),
  avgMilesPerWeek: varchar("avg_miles_per_week", { length: 120 }),
  seoTitle: varchar("seo_title", { length: 240 }),
  seoDescription: varchar("seo_description", { length: 500 }),
  seoKeywords: jsonb("seo_keywords").$type<string[]>(),
  sortOrder: integer("sort_order").notNull(),
  status: contentStatus("status").default("published").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const pricingItems = pgTable("cms_pricing_items", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 160 }).notNull().unique(),
  value: varchar("value", { length: 80 }).notNull(),
  unit: varchar("unit", { length: 120 }).notNull(),
  agreementSuffix: varchar("agreement_suffix", { length: 240 }),
  description: text("description").notNull(),
  highlight: boolean("highlight").default(false).notNull(),
  sortOrder: integer("sort_order").notNull(),
  status: contentStatus("status").default("published").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const agreementItems = pgTable("cms_agreement_items", {
  id: serial("id").primaryKey(),
  num: varchar("num", { length: 20 }).notNull().unique(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull(),
  sortOrder: integer("sort_order").notNull(),
  status: contentStatus("status").default("published").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const agreementDocument = pgTable("cms_agreement_document", {
  id: integer("id").primaryKey(),
  version: varchar("version", { length: 80 }).default("2024.1").notNull(),
  title: varchar("title", { length: 200 }).default("CARRIER AGREEMENT").notNull(),
  intro: text("intro").notNull(),
  sections: jsonb("sections").$type<AgreementSectionContent[]>().notNull(),
  carrierSignatureLabel: varchar("carrier_signature_label", { length: 160 }).notNull(),
  carrierSignatureHelp: varchar("carrier_signature_help", { length: 240 }).notNull(),
  companySignatureLabel: varchar("company_signature_label", { length: 160 }).notNull(),
  companySignatureHelp: varchar("company_signature_help", { length: 240 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
}).enableRLS();

export const slugRedirects = pgTable("cms_slug_redirects", {
  id: serial("id").primaryKey(),
  entityType: varchar("entity_type", { length: 40 }).notNull(),
  oldSlug: varchar("old_slug", { length: 160 }).notNull(),
  newSlug: varchar("new_slug", { length: 160 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}, (table) => [uniqueIndex("cms_slug_redirect_identity_idx").on(table.entityType, table.oldSlug)]).enableRLS();

export const onboardingSteps = pgTable("cms_onboarding_steps", {
  id: serial("id").primaryKey(),
  num: varchar("num", { length: 20 }).notNull().unique(),
  label: varchar("label", { length: 120 }).notNull(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull(),
  sortOrder: integer("sort_order").notNull(),
  status: contentStatus("status").default("published").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const testimonials = pgTable("cms_testimonials", {
  id: serial("id").primaryKey(),
  quote: text("quote").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  company: varchar("company", { length: 200 }),
  role: varchar("role", { length: 200 }).notNull(),
  equipment: varchar("equipment", { length: 160 }),
  location: varchar("location", { length: 160 }),
  tenure: varchar("tenure", { length: 160 }),
  initials: varchar("initials", { length: 8 }).notNull(),
  avatarPath: varchar("avatar_path", { length: 1000 }),
  avatarAlt: varchar("avatar_alt", { length: 500 }),
  rating: integer("rating").default(5).notNull(),
  featured: boolean("featured").default(false).notNull(),
  internalNotes: text("internal_notes"),
  sortOrder: integer("sort_order").notNull(),
  status: reviewStatus("status").default("pending").notNull(),
  submittedAt: timestamp("submitted_at", { withTimezone: true }).defaultNow().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}, (table) => [uniqueIndex("cms_testimonials_identity_idx").on(table.name, table.quote), check("cms_review_rating_range", sql`${table.rating} BETWEEN 1 AND 5`)]).enableRLS();

export const contactCards = pgTable("cms_contact_cards", {
  id: serial("id").primaryKey(),
  label: varchar("label", { length: 160 }).notNull().unique(),
  icon: varchar("icon", { length: 120 }).notNull(),
  href: varchar("href", { length: 1000 }),
  value: text("value").notNull(),
  sortOrder: integer("sort_order").notNull(),
  status: contentStatus("status").default("published").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const blogPosts = pgTable("cms_blog_posts", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 240 }).notNull(),
  slug: varchar("slug", { length: 160 }).notNull().unique(),
  excerpt: text("excerpt"),
  body: text("body").notNull(),
  featuredImage: varchar("featured_image", { length: 1000 }),
  featuredImageAlt: varchar("featured_image_alt", { length: 500 }),
  author: varchar("author", { length: 160 }).notNull(),
  category: varchar("category", { length: 160 }).notNull(),
  tags: jsonb("tags").$type<string[]>().default([]).notNull(),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  status: blogStatus("status").default("draft").notNull(),
  readingTime: integer("reading_time").default(1).notNull(),
  seoTitle: varchar("seo_title", { length: 240 }),
  seoDescription: varchar("seo_description", { length: 500 }),
  seoKeywords: jsonb("seo_keywords").$type<string[]>(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
}, (table) => [check("cms_blog_reading_time_range", sql`${table.readingTime} BETWEEN 1 AND 120`)]).enableRLS();

export const marqueeItems = pgTable("cms_marquee_items", {
  id: serial("id").primaryKey(),
  label: varchar("label", { length: 160 }).notNull().unique(),
  sortOrder: integer("sort_order").notNull(),
  status: contentStatus("status").default("published").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}).enableRLS();

export const mediaAssets = pgTable("cms_media_assets", {
  id: serial("id").primaryKey(),
  path: varchar("path", { length: 1000 }).notNull().unique(),
  fileName: varchar("file_name", { length: 260 }).notNull(),
  mimeType: varchar("mime_type", { length: 120 }).notNull(),
  storageKey: varchar("storage_key", { length: 1000 }).unique(),
  cloudinaryPublicId: varchar("cloudinary_public_id", { length: 500 }).unique(),
  source: varchar("source", { length: 20 }).default("local").notNull(),
  sizeBytes: integer("size_bytes"),
  width: integer("width"),
  height: integer("height"),
  altText: varchar("alt_text", { length: 500 }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  createdBy: varchar("created_by", { length: 120 }).default("seed").notNull(),
  updatedBy: varchar("updated_by", { length: 120 }).default("seed").notNull(),
  deletedAt: timestamp("deleted_at", { withTimezone: true }),
}, (table) => [check("cms_media_source_values", sql`${table.source} IN ('local','external','supabase','cloudinary')`)]).enableRLS();

export const adminAuditRecords = pgTable("admin_audit_records", {
  id: serial("id").primaryKey(),
  action: varchar("action", { length: 80 }).notNull(),
  entityType: varchar("entity_type", { length: 120 }).notNull(),
  entityId: varchar("entity_id", { length: 120 }).notNull(),
  summary: text("summary").notNull(),
  actor: varchar("actor", { length: 120 }).default("admin").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}).enableRLS();

export const adminUsers = pgTable("admin_users", {
  userId: uuid("user_id").primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  role: varchar("role", { length: 40 }).default("admin").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}).enableRLS();

export const publicRateLimits = pgTable("public_rate_limits", {
  id: serial("id").primaryKey(),
  action: varchar("action", { length: 80 }).notNull(),
  keyHash: varchar("key_hash", { length: 64 }).notNull(),
  windowStartedAt: timestamp("window_started_at", { withTimezone: true }).defaultNow().notNull(),
  requestCount: integer("request_count").default(1).notNull(),
}, (table) => [uniqueIndex("public_rate_limits_action_key_idx").on(table.action, table.keyHash)]).enableRLS();

export const agreementRevisions = pgTable("cms_agreement_revisions", {
  id: serial("id").primaryKey(),
  version: varchar("version", { length: 80 }).notNull(),
  snapshot: jsonb("snapshot").$type<{ title: string; intro: string; sections: AgreementSectionContent[]; carrierSignatureLabel: string; carrierSignatureHelp: string; companySignatureLabel: string; companySignatureHelp: string }>().notNull(),
  sourceUpdatedAt: timestamp("source_updated_at", { withTimezone: true }).notNull(),
  archivedBy: varchar("archived_by", { length: 120 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
}).enableRLS();
