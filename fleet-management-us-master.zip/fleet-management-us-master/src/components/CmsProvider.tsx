"use client";

import { createContext, useContext, type ReactNode } from "react";
import type { PublicSiteContent } from "@/lib/cms/types";

const CmsContext = createContext<PublicSiteContent | null>(null);

export function CmsProvider({ content, children }: { content: PublicSiteContent; children: ReactNode }) {
  return <CmsContext.Provider value={content}>{children}</CmsContext.Provider>;
}

export function useCms() {
  const content = useContext(CmsContext);
  if (!content) throw new Error("CMS content provider is missing.");
  return content;
}
