"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { useCms } from "@/components/CmsProvider";
import { bypassImageOptimization } from "@/lib/image";

export default function Hero() {
  const content = useCms();
  const images = content.heroImages;
  const [imageIndex, setImageIndex] = useState(0);
  const [loadAllImages, setLoadAllImages] = useState(false);

  useEffect(() => {
    if (images.length < 2) return;
    const timer = window.setTimeout(() => setLoadAllImages(true), 1500);
    return () => window.clearTimeout(timer);
  }, [images.length]);

  useEffect(() => {
    if (images.length < 2) return;
    const timer = window.setInterval(
      () => setImageIndex((index) => (index + 1) % images.length),
      6000,
    );
    return () => window.clearInterval(timer);
  }, [images.length]);

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center hero-bg grid-bg overflow-hidden"
    >
      <div className="hero-media absolute inset-0" aria-hidden="true">
        {images.map((image, index) => (index === 0 || loadAllImages) && (
          <div
            key={`${image}-${index}`}
            className="hero-slide"
            style={{ animation: "none", opacity: index === imageIndex ? 1 : 0, transform: "scale(1.08)", transition: "opacity 1s ease" }}
          >
            <Image
              src={image}
              alt=""
              fill
              sizes="100vw"
              quality={75}
              fetchPriority={index === 0 ? "high" : undefined}
              loading={index === 0 ? "eager" : "lazy"}
              unoptimized={bypassImageOptimization(image)}
              className="object-cover object-[58%_center]"
            />
          </div>
        ))}
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-[#0a0a0a]/40"></div>

      <div className="hidden xl:flex absolute left-6 top-1/2 -translate-y-1/2 flex-col items-center gap-4 z-10">
        <div className="w-px h-20 bg-[#363636]" />
        <span className="vertical-text font-cond text-xs tracking-[0.4em] text-[#808080]">{content.sectionCopy.heroRailText}</span>
        <div className="w-px h-20 bg-[#363636]" />
      </div>

      <div className="relative site-container py-16 sm:py-24 w-full z-10">
        <div className="max-w-5xl">
          <div className="flex items-center gap-4 mb-8 flex-wrap">
            <span className="tag"><span className="pulse-dot mr-2" />{content.sectionCopy.heroEyebrow}</span>
            {content.heroShowAuthority && (
              <span className="font-cond text-xs tracking-[0.2em] uppercase text-[#9a9a9a]">
                DOT #{content.company.dot} · MC #{content.company.mc}
              </span>
            )}
          </div>

          <h1 className="font-display text-[2.65rem] min-[360px]:text-5xl sm:text-7xl md:text-6xl lg:text-7xl leading-[1.08] mb-6">
            <span className="whitespace-pre-line">{content.heroHeading}</span> <span className="accent-text ml-1 sm:ml-0">{content.heroHeadingAccent}</span>
          </h1>

          <div className="flex items-center gap-4 mb-8">
            <div className="h-px flex-1 max-w-[80px] bg-accent" />
            <p className="font-cond text-lg sm:text-xl md:text-2xl lg:text-3xl tracking-wide text-[#c0c0c0] uppercase">{content.heroTagline}</p>
          </div>

          <p className="text-[#9a9a9a] text-base md:text-lg max-w-2xl mb-10 leading-relaxed">{content.heroDescription}</p>

          <div className="flex flex-wrap gap-4 mb-16">
            <a href={content.heroPrimaryCtaHref} className="btn-primary w-full sm:w-auto px-8 py-4 font-cond text-base tracking-wider uppercase">
              {content.heroPrimaryCtaLabel} <i className="fas fa-arrow-right ml-3" />
            </a>
            <a href={content.heroSecondaryCtaHref} className="btn-secondary w-full sm:w-auto px-8 py-4 font-cond text-base tracking-wider uppercase">
              <i className="fas fa-list mr-3" /> {content.heroSecondaryCtaLabel}
            </a>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 pt-10 border-t border-[#1a1a1a]">
            {content.heroStats.map((stat) => (
              <div key={stat.label}>
                <div className={`stat-num ${stat.accent ? "text-accent" : "metallic-text"}`}>{stat.value}</div>
                <div className="font-cond text-xs tracking-[0.2em] uppercase text-[#9a9a9a] mt-2">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 right-8 hidden md:flex flex-col items-center gap-3 z-10">
        <span className="font-cond text-[10px] tracking-[0.3em] text-[#808080] uppercase">{content.sectionCopy.heroScrollLabel}</span>
        <div className="w-px h-12 bg-gradient-to-b from-accent to-transparent" />
      </div>
    </section>
  );
}
