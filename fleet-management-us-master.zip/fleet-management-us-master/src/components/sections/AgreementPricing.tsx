"use client";

import { useCms } from "@/components/CmsProvider";

interface AgreementPricingProps {
  onOpenAgreement: () => void;
}

export default function AgreementPricing({ onOpenAgreement }: AgreementPricingProps) {
  const { pricing, agreementSummary, sectionCopy: copy } = useCms();
  return (
    <section id="agreement" className="py-16 sm:py-24 bg-[#0d0d0d] stripe-pattern">
      <div className="site-container">
        <div className="text-center mb-10 sm:mb-16">
          <span className="section-label center">{copy.agreementLabel}</span>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl mt-6 leading-[1.02] sm:leading-[0.88]">
            {copy.agreementHeading}
            <br />
            <span className="metallic-text">{copy.agreementHeadingAccent}</span>
          </h2>
          <p className="text-[#9a9a9a] max-w-2xl mx-auto mt-6 leading-relaxed">
            {copy.agreementDescription}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div>
            <div className="border border-[#242424] p-6 sm:p-8 bg-[#141414] h-full relative">
              <div className="flex items-center justify-between mb-8 pb-6 border-b border-[#242424]">
                <div>
                  <div className="font-cond text-xs tracking-[0.2em] uppercase text-accent">{copy.agreementDocumentOneLabel}</div>
                  <h3 className="font-display text-3xl mt-1">{copy.agreementSummaryTitle}</h3>
                </div>
                <i className="fas fa-file-signature text-accent text-2xl"></i>
              </div>

              <div className="space-y-5 text-sm leading-relaxed">
                {agreementSummary.map((item) => (
                  <div key={item.num} className="flex gap-4">
                    <span className="agreement-num">{item.num}</span>
                    <div>
                      <div className="font-cond tracking-wider uppercase text-sm font-medium mb-1">{item.title}</div>
                      <p className="text-[#9a9a9a]">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={onOpenAgreement}
                className="btn-primary w-full mt-8 py-4 font-cond tracking-wider uppercase"
              >
                {copy.agreementButtonLabel} <i className="fas fa-arrow-right ml-3"></i>
              </button>
            </div>
          </div>

          <div>
            <div className="border border-[#242424] p-6 sm:p-8 bg-[#141414] h-full relative">
              <div className="flex items-center justify-between mb-8 pb-6 border-b border-[#242424]">
                <div>
                  <div className="font-cond text-xs tracking-[0.2em] uppercase text-accent">{copy.agreementDocumentTwoLabel}</div>
                  <h3 className="font-display text-3xl mt-1">{copy.pricingTitle}</h3>
                </div>
                <i className="fas fa-dollar-sign text-accent text-2xl"></i>
              </div>

              <div>
                {pricing.map((item) => (
                  <div key={item.name} className="price-row">
                    <div className="flex-1 pr-4">
                      <div className="font-cond tracking-wider uppercase font-medium">{item.name}</div>
                      <div className="text-xs text-[#808080] mt-1 leading-relaxed">{item.description}</div>
                    </div>
                    <div className="text-right">
                      <div className={`font-display text-3xl uppercase ${item.highlight ? "text-accent" : "metallic-text"}`}>{item.value}</div>
                      <div className="text-[10px] text-[#9a9a9a] font-cond tracking-wider uppercase">{item.unit}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 p-4 bg-[#0a0a0a] border-l-2 border-accent">
                <div className="flex items-start gap-3">
                  <i className="fas fa-circle-info text-accent mt-1"></i>
                  <p className="text-xs text-[#9a9a9a] leading-relaxed">
                    {copy.pricingNote}
                  </p>
                </div>
              </div>

              <a href="#contact" className="btn-secondary w-full mt-6 py-4 font-cond tracking-wider uppercase">
                <i className="fas fa-calculator mr-3"></i> {copy.quoteButtonLabel}
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
