import Image from "next/image";
import { useCms } from "@/components/CmsProvider";
import { bypassImageOptimization } from "@/lib/image";

export default function About() {
  const {
    aboutImage: image,
    aboutImageAlt: imageAlt,
    aboutEnabled: enabled,
    aboutSectionLabel: sectionLabel,
    aboutHeading: heading,
    aboutHeadingAccent: headingAccent,
    aboutEstablishedText: establishedText,
    aboutYearsLabel: yearsLabel,
    aboutYears: years,
    aboutDescription1: description1,
    aboutDescription2: description2,
    aboutFeatures: features,
  } = useCms();
  if (!enabled) return null;
  return (
    <section id="about" className="py-16 sm:py-24 relative">
      <div className="site-container">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          {image && <div className="lg:col-span-5">
            <div className="relative h-[440px] sm:h-[620px]">
              <Image
                src={image}
                alt={imageAlt}
                unoptimized={bypassImageOptimization(image)}
                fill
                sizes="(max-width: 1024px) 100vw, 42vw"
                className="object-cover grayscale-[20%] contrast-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent"></div>
              {establishedText && <div className="absolute top-4 left-4 sm:top-6 sm:left-6 tag bg-[#0a0a0a]/80">{establishedText}</div>}
              {years && <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6">
                <div className="bg-[#0a0a0a]/95 border-l-4 border-accent p-4 sm:p-6">
                  <div className="font-display text-5xl text-accent">{years}</div>
                  {yearsLabel && <div className="font-cond tracking-wider text-sm text-[#c0c0c0] mt-1 uppercase">
                    {yearsLabel}
                  </div>}
                </div>
              </div>}
            </div>
          </div>}

          <div className={image ? "lg:col-span-7" : "lg:col-span-12"}>
            <span className="section-label">{sectionLabel}</span>
            <h2 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.02] sm:leading-[0.88] mt-6 mb-8">
              {heading}
              <br />
              <span className="metallic-text">{headingAccent}</span>
            </h2>
            <p className="text-[#c0c0c0] text-lg leading-relaxed mb-6">
              {description1}
            </p>
            {description2 && <p className="text-[#9a9a9a] leading-relaxed mb-10">
              {description2}
            </p>}

            {features.length > 0 && <div className="grid sm:grid-cols-3 gap-6">
              {features.map((feature) => (
                <div
                  key={feature.title}
                  className={`border-t-2 pt-4 ${feature.accent ? "border-accent" : "border-[#363636]"}`}
                >
                  <i className={`fas ${feature.icon} text-accent text-2xl mb-3`}></i>
                  <div className="font-cond tracking-wider uppercase text-sm font-medium">{feature.title}</div>
                  <div className="text-[#808080] text-xs mt-1 leading-relaxed">{feature.description}</div>
                </div>
              ))}
            </div>}
          </div>
        </div>
      </div>
    </section>
  );
}
