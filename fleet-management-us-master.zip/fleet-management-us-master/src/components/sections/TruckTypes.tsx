"use client";

import Link from "next/link";
import { useCms } from "@/components/CmsProvider";

export default function TruckTypes() {
  const { truckTypes, sectionCopy: copy } = useCms();
  return (
    <section id="trucks" className="py-16 sm:py-24 relative">
      <div className="site-container">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 sm:mb-16">
          <div>
            <span className="section-label">{copy.trucksLabel}</span>
            <h2 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.02] sm:leading-[0.88] mt-6">
              {copy.trucksHeading} <span className="accent-text">{copy.trucksHeadingAccent}</span>
            </h2>
          </div>
          <div className="text-left sm:text-right">
            <p className="text-[#9a9a9a] max-w-sm leading-relaxed mt-2 text-sm">
              {copy.trucksDescription}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {truckTypes.map((truck) => (
            <Link
              key={truck.name}
              href={`/truck-types/${truck.slug}`}
              className="truck-card p-4 sm:p-6 group focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent"
            >
              <i className={`truck-icon fas ${truck.icon} text-3xl mb-4`}></i>
              <div className="font-cond tracking-wider uppercase text-sm font-medium">{truck.name}</div>
              <div className="truck-spec text-[10px] mt-1 font-cond tracking-wider">{truck.spec}</div>
              <span className="mt-4 inline-flex items-center gap-2 font-cond text-[10px] font-semibold uppercase tracking-[0.16em] text-accent">
                {copy.trucksLinkLabel} <i className="fas fa-arrow-right transition-transform group-hover:translate-x-1"></i>
              </span>
            </Link>
          ))}
        </div>

        <div className="mt-8 flex items-center gap-3 text-xs text-[#808080] font-cond tracking-wider uppercase">
          <i className="fas fa-circle-info text-accent"></i>
          <span>{copy.trucksCustomNote}</span>
        </div>
      </div>
    </section>
  );
}
