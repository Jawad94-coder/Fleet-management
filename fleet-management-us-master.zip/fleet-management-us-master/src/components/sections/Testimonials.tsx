"use client";

import { useEffect, useState, type CSSProperties } from "react";
import Image from "next/image";
import { useCms } from "@/components/CmsProvider";
import { bypassImageOptimization } from "@/lib/image";

export default function Testimonials() {
  const { testimonials, sectionCopy:copy } = useCms();
  const [active, setActive] = useState(0);
  const [playing, setPlaying] = useState(true);
  const angle = 360 / testimonials.length;

  function move(direction: number) {
    setPlaying(false);
    setActive((current) => (current + direction + testimonials.length) % testimonials.length);
  }

  useEffect(() => {
    if (!playing || !testimonials.length) return;
    const timer = window.setInterval(
      () => setActive((current) => (current + 1) % testimonials.length),
      6500,
    );
    return () => window.clearInterval(timer);
  }, [playing, testimonials.length]);

  if (!testimonials.length) return null;

  return (
    <section id="testimonials" className="py-16 sm:py-24 bg-[#0d0d0d] relative overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div className="site-container relative">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-10 sm:mb-16">
          <div>
            <span className="section-label">{copy.testimonialsLabel}</span>
            <h2 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.02] sm:leading-[0.88] mt-6">
              {copy.testimonialsHeading}
              <br />
              <span className="accent-text">{copy.testimonialsHeadingAccent}</span>
            </h2>
          </div>
          <p className="text-[#9a9a9a] max-w-md leading-relaxed">
            {copy.testimonialsDescription}
          </p>
        </div>

        <div className="testimonial-stage" role="region" aria-roledescription="carousel" aria-label="Carrier testimonials">
          <div
            className="testimonial-ring"
            style={{ "--testimonial-rotation": `${active * -angle}deg` } as CSSProperties}
          >
            {testimonials.map((testimonial, index) => (
              <article
                key={testimonial.id}
                className={`testimonial-card flex flex-col p-6 sm:p-8 border bg-[#141414] ${
                  active === index ? "border-accent" : "border-[#242424]"
                }`}
                style={{ "--testimonial-angle": `${index * angle}deg` } as CSSProperties}
                aria-hidden={active !== index}
              >
                <div className="flex items-center justify-between mb-7">
                  <div className="flex gap-1 text-accent" role="img" aria-label={`${testimonial.rating} out of 5 stars`}>
                    {Array.from({ length: testimonial.rating }, (_, star) => (
                      <i key={star} className="fas fa-star text-xs" aria-hidden="true" />
                    ))}
                  </div>
                  <i className="fas fa-quote-right text-3xl text-[#2b2b2b]" aria-hidden="true" />
                </div>

                <blockquote className="text-[#c0c0c0] leading-relaxed flex-1">
                  “{testimonial.quote}”
                </blockquote>

                <div className="mt-8 pt-6 border-t border-[#2b2b2b]">
                  <div className="flex items-center gap-4">
                    <div className="relative w-12 h-12 shrink-0 overflow-hidden bg-accent text-[#0a0a0a] font-display text-lg flex items-center justify-center">
                      {testimonial.avatarPath?<Image src={testimonial.avatarPath} alt={testimonial.avatarAlt?.trim() || `${testimonial.name} testimonial portrait`} unoptimized={bypassImageOptimization(testimonial.avatarPath)} fill sizes="48px" className="object-cover"/>:testimonial.initials}
                    </div>
                    <div className="min-w-0">
                      <div className="font-cond text-lg tracking-wide uppercase">{testimonial.name}</div>
                      <div className="text-xs text-[#808080]">{testimonial.role} · {testimonial.location}</div>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-5">
                    <span className="tag">{testimonial.equipment}</span>
                    <span className="tag">{testimonial.tenure}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>

        <div className="flex justify-center items-center gap-3 mt-8">
          <button type="button" onClick={() => move(-1)} className="testimonial-control" aria-label="Previous testimonial">
            <i className="fas fa-arrow-left" aria-hidden="true" />
          </button>
          <button
            type="button"
            onClick={() => setPlaying((current) => !current)}
            className="testimonial-control"
            aria-label={playing ? "Pause testimonial rotation" : "Play testimonial rotation"}
          >
            <i className={`fas ${playing ? "fa-pause" : "fa-play"}`} aria-hidden="true" />
          </button>
          <button type="button" onClick={() => move(1)} className="testimonial-control" aria-label="Next testimonial">
            <i className="fas fa-arrow-right" aria-hidden="true" />
          </button>
        </div>

        <p className="mt-8 text-center text-[11px] text-[#808080] font-cond tracking-wide">
          {copy.testimonialsDisclaimer}
        </p>
      </div>
    </section>
  );
}
