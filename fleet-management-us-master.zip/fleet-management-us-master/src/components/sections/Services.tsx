"use client";

import Link from "next/link";
import Image from "next/image";
import { useCms } from "@/components/CmsProvider";
import { bypassImageOptimization } from "@/lib/image";

export default function Services() {
  const { services, sectionCopy: copy } = useCms();
  return (
    <section id="services" className="py-16 sm:py-24 bg-[#0d0d0d] relative stripe-pattern">
      <div className="site-container relative">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 sm:mb-16">
          <div>
            <span className="section-label">{copy.servicesLabel}</span>
            <h2 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.02] sm:leading-[0.88] mt-6">
              {copy.servicesHeading} <span className="accent-text">{copy.servicesHeadingAccent}</span>
            </h2>
          </div>
          <p className="text-[#9a9a9a] max-w-md leading-relaxed">{copy.servicesDescription}</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-[#1a1a1a] border border-[#1a1a1a]">
          {services.map((svc) => (
            <Link
              key={svc.num}
              href={svc.ctaHref ?? `/services/${svc.slug}`}
              className="service-card p-6 sm:p-8 group md:last:col-span-2 lg:last:col-span-1 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-accent"
            >
              <div className="flex items-start justify-between mb-6">
                <div className="svc-icon w-12 h-12 border border-[#363636] flex items-center justify-center text-[#c0c0c0] transition-colors">
                  {svc.image ? <Image src={svc.image} alt={svc.imageAlt?.trim() || `${svc.title} service image`} width={48} height={48} sizes="48px" unoptimized={bypassImageOptimization(svc.image)} className="h-full w-full object-cover" /> : <i className={`fas ${svc.icon} text-xl`}></i>}
                </div>
                <span className="svc-num font-display text-3xl text-[#363636] transition-colors">{svc.num}</span>
              </div>
              <h3 className="font-display text-2xl mb-3 tracking-wide">{svc.title}</h3>
              <p className="text-[#9a9a9a] text-sm leading-relaxed">{svc.desc}</p>
              <span className="mt-6 inline-flex items-center gap-2 font-cond text-xs font-semibold tracking-[0.18em] uppercase text-accent">
                {svc.ctaLabel ?? copy.servicesLinkLabel} <i className="fas fa-arrow-right transition-transform group-hover:translate-x-1"></i>
              </span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
