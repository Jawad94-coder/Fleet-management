import Link from "next/link";

export default function DispatchAnswers() {
  return (
    <section className="border-t border-[#242424] bg-[#0d0d0d] py-16 sm:py-24" aria-labelledby="dispatch-questions">
      <div className="site-container">
        <span className="section-label">Before you choose a dispatcher</span>
        <h2 id="dispatch-questions" className="mt-6 font-display text-4xl sm:text-5xl">Truck dispatch questions, answered</h2>
        <div className="mt-8 grid gap-px border border-[#242424] bg-[#242424] md:grid-cols-2">
          <article className="bg-[#141414] p-6 sm:p-8">
            <h3 className="font-display text-2xl">What does a truck dispatcher do?</h3>
            <p className="mt-4 leading-relaxed text-[#a8a8a8]">A truck dispatcher helps a carrier research loads, discuss rates with brokers and coordinate pickups, delivery updates and paperwork. The scope and authorization should be defined in a written agreement. Review our <Link href="/services/dispatch-services" className="text-accent underline">dispatch services for US owner-operators</Link>.</p>
          </article>
          <article className="bg-[#141414] p-6 sm:p-8">
            <h3 className="font-display text-2xl">How much do dispatch services cost?</h3>
            <p className="mt-4 leading-relaxed text-[#a8a8a8]">Dispatch pricing may use a percentage, a weekly fee or a per-load fee. Compare the fee base, included tasks and any additional charges. Request current written terms for your operation and read our <Link href="/blogs/owner-operator-dispatch-pricing-responsibilities" className="text-accent underline">dispatch pricing guide</Link>.</p>
          </article>
          <article className="bg-[#141414] p-6 sm:p-8">
            <h3 className="font-display text-2xl">How can planning reduce empty miles?</h3>
            <p className="mt-4 leading-relaxed text-[#a8a8a8]">Compare the trip to pickup, loaded miles and likely repositioning after delivery before accepting freight. A return-load plan can help avoid unnecessary travel, but freight availability and driver constraints still matter. Explore <Link href="/services/load-assistance" className="text-accent underline">load selection assistance</Link> and our <Link href="/blogs/reduce-empty-miles-with-dispatch-planning" className="text-accent underline">empty-mile planning guide</Link>.</p>
          </article>
          <article className="bg-[#141414] p-6 sm:p-8">
            <h3 className="font-display text-2xl">What should I confirm before onboarding?</h3>
            <p className="mt-4 leading-relaxed text-[#a8a8a8]">Confirm equipment support, lanes, communication hours, carrier approval rights, document handling and fees. A dispatcher does not supply operating authority merely by arranging support. Review <Link href="/services/carrier-setup-assistance" className="text-accent underline">carrier onboarding assistance</Link> or <Link href="/#contact" className="text-accent underline">send your carrier enquiry</Link>.</p>
          </article>
        </div>
      </div>
    </section>
  );
}
