"use client";

import { useCms } from "@/components/CmsProvider";
import { useState } from "react";

interface ContactProps {
  onToast: (message: string) => void;
}

export default function Contact({ onToast }: ContactProps) {
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const {
    truckTypes,
    contactCards,
    contactSectionLabel,
    contactHeading,
    contactHeadingAccent,
    contactDescription: description,
    dispatchStatusText,
    dispatchResponseTime,
    contactAfterHoursText,
    contactPrivacyDisclaimer,
    sectionCopy:copy,
  } = useCms();
  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if(submitting)return;
    const form = e.currentTarget;
    const formData = new FormData(form);
    const name = String(formData.get("fullName") || "");
    setSubmitting(true);
    setError("");

    try {
      const response = await fetch("/api/carrier-applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...Object.fromEntries(formData),
          smsOptIn: formData.get("smsOptIn") === "on",
        }),
      });
      const result = (await response.json()) as { error?: string };

      if (!response.ok) {
        setError(result.error || copy.contactSubmitError);
        return;
      }

      onToast(`Thanks ${name.trim().split(" ")[0]}, ${copy.contactSuccessMessage}`);
      form.reset();
    } catch {
      setError(copy.contactConnectionError);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section id="contact" className="py-16 sm:py-24 bg-[#0d0d0d] relative">
      <div className="absolute inset-0 grid-bg opacity-40"></div>
      <div className="site-container relative">
        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <span className="section-label">{contactSectionLabel}</span>
            <h2 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl mt-6 mb-8 leading-[1.02] sm:leading-[0.88]">
              {contactHeading}
              <br />
              <span className="accent-text">{contactHeadingAccent}</span>
            </h2>
            <p className="text-[#9a9a9a] mb-10 leading-relaxed">
              {description}
            </p>

            <div className="space-y-3">
              {contactCards.map((card) => (
                <div key={card.label} className="flex items-center gap-4 p-4 border border-[#242424] bg-[#141414] hover:border-accent transition-colors group">
                  <div className="w-11 h-11 bg-accent/10 border border-accent/30 flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-[#0a0a0a] transition-colors">
                    <i className={`fas ${card.icon}`}></i>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[10px] font-cond tracking-[0.25em] uppercase text-[#808080]">
                      {card.label}
                    </div>
                    {card.href ? (
                      <a href={card.href} className="font-cond tracking-wide hover:text-accent transition break-all sm:break-normal">
                        {card.value}
                      </a>
                    ) : (
                      <span className="font-cond tracking-wide whitespace-pre-line">{card.value}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 p-5 border border-accent/30 bg-accent/5">
              <div className="flex items-center gap-3 mb-2">
                <span className="pulse-dot"></span>
                <span className="font-cond tracking-[0.2em] uppercase text-sm text-accent">{dispatchStatusText}</span>
              </div>
              <p className="text-xs text-[#9a9a9a]">
                {dispatchResponseTime && <>{copy.contactAverageResponseLabel}: <strong className="text-[#f0f0f0]">{dispatchResponseTime}</strong> · </>}{contactAfterHoursText}
              </p>
            </div>
          </div>

          <div className="lg:col-span-7">
            <form onSubmit={handleSubmit} className="bg-[#141414] border border-[#242424] p-5 sm:p-8 md:p-10">
              <div className="hidden" aria-hidden="true">
                <label htmlFor="website">Website</label>
                <input id="website" name="website" type="text" tabIndex={-1} autoComplete="off" />
              </div>
              <div className="flex items-center justify-between mb-8 pb-6 border-b border-[#242424]">
                <div>
                  <div className="font-cond text-xs tracking-[0.2em] uppercase text-accent">{copy.contactFormLabel}</div>
                  <h3 className="font-display text-3xl mt-1">{copy.contactFormHeading}</h3>
                </div>
                <i className="fas fa-paper-plane text-accent text-2xl"></i>
              </div>

              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="font-cond text-[10px] tracking-[0.2em] uppercase text-[#9a9a9a] mb-2 block" htmlFor="contact-fullName">{copy.contactNameLabel} *</label>
                  <input type="text" id="contact-fullName" name="fullName" maxLength={160} required className="form-input w-full px-4 py-3 text-sm" placeholder={copy.contactNamePlaceholder} />
                </div>
                <div>
                  <label className="font-cond text-[10px] tracking-[0.2em] uppercase text-[#9a9a9a] mb-2 block" htmlFor="contact-company">{copy.contactCompanyLabel}</label>
                  <input type="text" id="contact-company" name="company" maxLength={200} className="form-input w-full px-4 py-3 text-sm" placeholder={copy.contactCompanyPlaceholder} />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="font-cond text-[10px] tracking-[0.2em] uppercase text-[#9a9a9a] mb-2 block" htmlFor="contact-phone">{copy.contactPhoneLabel} *</label>
                  <input type="tel" id="contact-phone" name="phone" maxLength={60} required className="form-input w-full px-4 py-3 text-sm" placeholder={copy.contactPhonePlaceholder} />
                </div>
                <div>
                  <label className="font-cond text-[10px] tracking-[0.2em] uppercase text-[#9a9a9a] mb-2 block" htmlFor="contact-email">{copy.contactEmailLabel} *</label>
                  <input type="email" id="contact-email" name="email" maxLength={200} required className="form-input w-full px-4 py-3 text-sm" placeholder={copy.contactEmailPlaceholder} />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="font-cond text-[10px] tracking-[0.2em] uppercase text-[#9a9a9a] mb-2 block" htmlFor="contact-truckType">{copy.contactTruckLabel} *</label>
                  <select id="contact-truckType" name="truckType" required className="form-input w-full px-4 py-3 text-sm">
                    <option value="">{copy.contactTruckPlaceholder}</option>
                    {truckTypes.map((truck) => (
                      <option key={truck.name}>{truck.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="font-cond text-[10px] tracking-[0.2em] uppercase text-[#9a9a9a] mb-2 block" htmlFor="contact-zip">{copy.contactZipLabel} *</label>
                  <input type="text" id="contact-zip" name="zip" maxLength={10} required className="form-input w-full px-4 py-3 text-sm" placeholder={copy.contactZipPlaceholder} />
                </div>
              </div>

              <div className="mb-4">
                <label className="font-cond text-[10px] tracking-[0.2em] uppercase text-[#9a9a9a] mb-2 block" htmlFor="contact-lanes">{copy.contactLanesLabel}</label>
                <input type="text" id="contact-lanes" name="lanes" maxLength={500} className="form-input w-full px-4 py-3 text-sm" placeholder={copy.contactLanesPlaceholder} />
              </div>

              <div className="mb-6">
                <label className="font-cond text-[10px] tracking-[0.2em] uppercase text-[#9a9a9a] mb-2 block" htmlFor="contact-message">{copy.contactMessageLabel}</label>
                <textarea id="contact-message" name="message" maxLength={5000} rows={4} className="form-input w-full px-4 py-3 text-sm" placeholder={copy.contactMessagePlaceholder}></textarea>
              </div>

              <label className="mb-6 flex cursor-pointer items-start gap-3 text-xs leading-relaxed text-[#9a9a9a]">
                <input
                  type="checkbox"
                  name="smsOptIn"
                  className="mt-0.5 h-4 w-4 accent-[#FF6B00]"
                />
                <span>
                  {copy.contactSmsConsent}
                </span>
              </label>

              <button disabled={submitting} type="submit" className="btn-primary w-full py-4 font-cond tracking-wider uppercase disabled:cursor-not-allowed disabled:opacity-60">
                {submitting ? copy.contactSubmittingLabel : copy.contactSubmitLabel} <i className={`fas ${submitting ? "fa-circle-notch fa-spin" : "fa-arrow-right"} ml-3`}></i>
              </button>

              {error && (
                <p role="alert" aria-live="polite" className="mt-4 text-center text-sm text-red-400">
                  {error}
                </p>
              )}

              <p className="text-[10px] text-[#808080] mt-4 text-center leading-relaxed">
                {contactPrivacyDisclaimer}
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
