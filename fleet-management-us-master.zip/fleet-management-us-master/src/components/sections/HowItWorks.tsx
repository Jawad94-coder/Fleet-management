"use client";

import { useCms } from "@/components/CmsProvider";

export default function HowItWorks() {
  const { steps, sectionCopy: copy } = useCms();
  return (
    <section className="py-16 sm:py-24">
      <div className="site-container">
        <div className="text-center mb-10 sm:mb-16">
          <span className="section-label center">{copy.howLabel}</span>
          <h2 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl mt-6 leading-[1.02] sm:leading-[0.88]">
            {copy.howHeading} <span className="accent-text">{copy.howHeadingAccent}</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-5 gap-px bg-[#1a1a1a] border border-[#1a1a1a]">
          {steps.map((step) => (
            <div key={step.num} className="bg-[#0a0a0a] p-6 sm:p-8 relative group hover:bg-[#141414] transition-colors">
              <div className="step-num mb-4">{step.num}</div>
              <div className="font-cond text-xs tracking-[0.2em] uppercase text-accent mb-3">{step.label}</div>
              <h3 className="font-display text-xl mb-3 tracking-wide">{step.title}</h3>
              <p className="text-[#9a9a9a] text-sm leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 sm:mt-20 text-center relative">
          <div className="absolute inset-0 grid-bg opacity-30"></div>
          <div className="relative">
            <div className="font-cond text-xs tracking-[0.3em] uppercase text-accent mb-4">{copy.howCtaLabel}</div>
            <h3 className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl mb-8 leading-[1.02] sm:leading-[0.9]">
              {copy.howCtaHeading} <span className="accent-text">{copy.howCtaAccent}</span>
            </h3>
            <p className="text-[#9a9a9a] max-w-xl mx-auto mb-10 leading-relaxed">
              {copy.howCtaDescription}
            </p>
            <a href="#contact" className="btn-primary px-10 py-4 font-cond tracking-wider uppercase text-base">
              {copy.howCtaButton} <i className="fas fa-arrow-right ml-3"></i>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
