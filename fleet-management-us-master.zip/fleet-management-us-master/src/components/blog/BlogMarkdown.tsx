import type { ReactNode } from "react";
import Image from "next/image";
import { bypassImageOptimization } from "@/lib/image";

function safeUrl(value: string, image = false) {
  if (/^\/(?!\/)[a-z0-9_./%-]*(?:\?[a-z0-9_=&.%-]*)?$/i.test(value)) return value;
  try {
    const url = new URL(value);
    if (url.protocol === "https:" || url.protocol === "http:" || (!image && url.protocol === "mailto:")) return url.href;
  } catch {}
  return null;
}

function inline(value: string): ReactNode[] {
  const pattern = /(!?\[([^\]]+)\]\(([^)\s]+)\)|\*\*([^*]+)\*\*|\*([^*]+)\*)/g;
  const nodes: ReactNode[] = []; let last = 0; let match: RegExpExecArray | null;
  while ((match = pattern.exec(value))) {
    if (match.index > last) nodes.push(value.slice(last, match.index));
    if (match[1].startsWith("!")) {
      const url = safeUrl(match[3], true);
      nodes.push(url ? <span key={match.index} className="relative my-8 block h-64 sm:h-96"><Image src={url} alt={match[2]} fill sizes="(max-width: 768px) 100vw, 768px" unoptimized={bypassImageOptimization(url)} className="object-contain" /></span> : match[2]);
    } else if (match[2]) {
      const url = safeUrl(match[3]);
      nodes.push(url ? <a key={match.index} href={url} className="text-accent underline decoration-accent/50 underline-offset-4">{match[2]}</a> : match[2]);
    } else if (match[4]) nodes.push(<strong key={match.index} className="font-semibold text-white">{match[4]}</strong>);
    else nodes.push(<em key={match.index}>{match[5]}</em>);
    last = pattern.lastIndex;
  }
  if (last < value.length) nodes.push(value.slice(last));
  return nodes;
}

export default function BlogMarkdown({ body }: { body: string }) {
  const lines = body.replace(/\r/g, "").split("\n"); const blocks: ReactNode[] = [];
  for (let i=0;i<lines.length;) {
    const line=lines[i].trim(); if(!line){i++;continue;}
    const heading=/^(#{1,3})\s+(.+)$/.exec(line);
    if(heading){const className="font-display mt-10 mb-4 text-white "+(heading[1].length===1?"text-4xl sm:text-5xl":heading[1].length===2?"text-3xl sm:text-4xl":"text-2xl sm:text-3xl");const content=inline(heading[2]);blocks.push(heading[1].length===1?<h2 key={i} className={className}>{content}</h2>:heading[1].length===2?<h3 key={i} className={className}>{content}</h3>:<h4 key={i} className={className}>{content}</h4>);i++;continue;}
    const list=/^([-*]|\d+\.)\s+(.+)$/.exec(line);
    if(list){const ordered=/\d+\./.test(list[1]);const items:ReactNode[]=[];while(i<lines.length){const item=/^([-*]|\d+\.)\s+(.+)$/.exec(lines[i].trim());if(!item||/\d+\./.test(item[1])!==ordered)break;items.push(<li key={i}>{inline(item[2])}</li>);i++;}blocks.push(ordered?<ol key={`l${i}`} className="my-6 list-decimal space-y-2 pl-6 marker:text-accent">{items}</ol>:<ul key={`l${i}`} className="my-6 list-disc space-y-2 pl-6 marker:text-accent">{items}</ul>);continue;}
    const paragraph=[line];i++;while(i<lines.length&&lines[i].trim()&&!/^(#{1,3})\s+/.test(lines[i].trim())&&!/^([-*]|\d+\.)\s+/.test(lines[i].trim())){paragraph.push(lines[i].trim());i++;}blocks.push(<p key={i} className="my-5 leading-8 text-[#b0b0b0]">{inline(paragraph.join(" "))}</p>);
  }
  return <div>{blocks}</div>;
}
