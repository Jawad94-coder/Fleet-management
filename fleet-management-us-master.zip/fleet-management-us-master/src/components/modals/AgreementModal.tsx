"use client";

import { useEffect, useRef } from "react";
import { useCms } from "@/components/CmsProvider";
import type { AgreementSectionContent } from "@/lib/cms/types";

interface AgreementModalProps {
  isOpen: boolean;
  onClose: () => void;
  onToast: (message: string) => void;
}

export default function AgreementModal({ isOpen, onClose, onToast }: AgreementModalProps) {
  const { company, pricing, agreementDocument, sectionCopy:copy } = useCms();

  const dialog = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!isOpen) return;
    const previous = document.activeElement as HTMLElement | null;
    const root = dialog.current;
    root?.querySelector<HTMLButtonElement>("button")?.focus();
    function trap(event: KeyboardEvent) {
      if (event.key === "Escape") { onClose(); return; }
      if (event.key !== "Tab") return;
      const items = root?.querySelectorAll<HTMLElement>('button, a[href], input, select, textarea, [tabindex="0"]');
      if (!items?.length) return;
      const first=items[0], last=items[items.length-1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
    document.addEventListener("keydown", trap);
    return () => { document.removeEventListener("keydown", trap); previous?.focus(); };
  }, [isOpen, onClose]);
  if (!isOpen) return null;
  return (
    <div id="agreement-dialog" ref={dialog} role="dialog" aria-modal="true" aria-label={agreementDocument.title} className={`modal-overlay ${isOpen ? "active" : ""}`} onClick={(event) => event.target === event.currentTarget && onClose()}>
      <div className="modal-content max-w-5xl mx-3 sm:mx-auto my-3 sm:my-8 bg-[#0a0a0a] border border-[#242424]">
        <div className="sticky top-0 bg-[#0a0a0a]/95 backdrop-blur-md border-b border-[#242424] p-4 sm:p-6 flex justify-between items-center gap-3 z-10">
          <div>
            <div className="font-cond text-xs tracking-[0.25em] uppercase text-accent">{company.name} · {copy.agreementModalKicker}</div>
            <h2 className="font-display text-2xl sm:text-3xl md:text-4xl mt-1">{agreementDocument.title}</h2>
          </div>
          <button onClick={onClose} className="w-11 h-11 border border-[#242424] hover:border-accent hover:text-accent transition flex items-center justify-center" aria-label="Close agreement">
            <i className="fas fa-times" />
          </button>
        </div>

        <div className="p-4 sm:p-6 md:p-10">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-8 pb-6 border-b border-[#242424]">
            <div className="flex items-center gap-3">
              <span className="font-cond text-xs tracking-[0.2em] uppercase text-[#808080]">{copy.agreementVersionLabel} {agreementDocument.version}</span>
            </div>
            <div className="agreement-tools flex flex-wrap sm:flex-nowrap gap-3">
              <button onClick={() => window.print()} className="btn-secondary px-5 py-2.5 font-cond tracking-wider text-xs uppercase"><i className="fas fa-download mr-2" /> {copy.agreementPrintLabel}</button>
              <button onClick={async () => { try { await navigator.clipboard.writeText(`${window.location.origin}/#agreement`); onToast(copy.agreementCopySuccess); } catch { onToast(copy.agreementCopyError); } }} className="btn-secondary px-5 py-2.5 font-cond tracking-wider text-xs uppercase"><i className="fas fa-link mr-2" /> {copy.agreementCopyLabel}</button>
            </div>
          </div>

          <p className="text-[#9a9a9a] text-sm leading-relaxed mb-8">{agreementDocument.intro}</p>
          <div className="grid md:grid-cols-2 gap-4">
            {agreementDocument.sections.map((section) => (
              <AgreementSection key={`${section.number}-${section.title}`} section={section} company={company} pricing={pricing} copy={copy} />
            ))}
          </div>

          <div className="mt-8 pt-8 border-t border-[#242424]">
            <div className="grid md:grid-cols-2 gap-8">
              <Signature label={agreementDocument.carrierSignatureLabel} help={agreementDocument.carrierSignatureHelp} />
              <Signature label={agreementDocument.companySignatureLabel} help={agreementDocument.companySignatureHelp} />
            </div>
          </div>

          <div className="agreement-tools mt-8 flex flex-wrap gap-3 justify-end">
            <button onClick={onClose} className="btn-secondary w-full sm:w-auto px-6 py-3 font-cond tracking-wider text-sm uppercase">{copy.agreementCloseLabel}</button>
            <a href={`mailto:${company.email}?subject=${encodeURIComponent(copy.agreementContactSubject)}`} className="btn-primary w-full sm:w-auto px-6 py-3 font-cond tracking-wider text-sm uppercase"><i className="fas fa-signature mr-2" /> {copy.agreementContactLabel}</a>
          </div>
        </div>
      </div>
    </div>
  );
}

function AgreementSection({ section, company, pricing,copy }: {
  section: AgreementSectionContent;
  company: ReturnType<typeof useCms>["company"];
  pricing: ReturnType<typeof useCms>["pricing"];
  copy:ReturnType<typeof useCms>["sectionCopy"];
}) {
  return (
    <div className={`agreement-section${section.wide ? " md:col-span-2" : ""}`}>
      <div className="flex items-center justify-between mb-3">
        <span className="agreement-num">{copy.agreementSectionPrefix} {section.number}</span>
      </div>
      <h3 className="font-display text-xl mb-3 tracking-wide">{section.title}</h3>
      {section.kind === "company" ? (
        <div className="text-sm text-[#9a9a9a] space-y-2 leading-relaxed">
          <div>{copy.agreementLegalNameLabel}: <span className="text-[#f0f0f0]">{company.legalName}</span></div>
          <div>{copy.agreementDotLabel}: <span className="text-[#f0f0f0]">{company.dot}</span></div>
          <div>{copy.agreementMcLabel}: <span className="text-[#f0f0f0]">{company.mc}</span></div>
          <div>{copy.agreementAddressLabel}: <span className="text-[#f0f0f0]">{company.address}, {company.city}</span></div>
          <div>{copy.agreementPhoneLabel}: <span className="text-[#f0f0f0]">{company.phone}</span></div>
          <div>{copy.agreementEmailLabel}: <span className="text-[#f0f0f0]">{company.email}</span></div>
        </div>
      ) : section.kind === "pricing" ? (
        <div className="text-sm text-[#9a9a9a] space-y-2 leading-relaxed">
          {pricing.map((item) => <div key={item.name}>{item.name}: <span className="text-accent font-bold">{item.value} {item.agreementSuffix ?? item.unit}</span></div>)}
          {section.description && <p className="mt-3 text-xs">{section.description}</p>}
        </div>
      ) : (
        <div className="text-sm text-[#9a9a9a] leading-relaxed">
          {section.description && <p className="mb-3 whitespace-pre-line">{section.description}</p>}
          {section.items && (
            <ul className="space-y-1.5">
              {section.items.map((item, index) => (
                <li key={`${item.description}-${index}`} className={section.kind === "list" ? "flex gap-2" : ""}>
                  {section.kind === "list" && <i className="fas fa-check text-accent mt-1 text-xs" />}
                  <span>{item.name && <strong className="text-[#f0f0f0]">{item.name}: </strong>}{item.description}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

function Signature({ label, help }: { label: string; help: string }) {
  return <div><div className="font-cond text-xs tracking-[0.2em] uppercase text-accent mb-4">{label}</div><div className="border-b border-[#363636] h-12 mb-2" /><div className="text-xs text-[#808080] font-cond tracking-wider uppercase">{help}</div></div>;
}
