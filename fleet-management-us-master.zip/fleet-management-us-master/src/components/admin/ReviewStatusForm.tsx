"use client";
import { useActionState } from "react";
import { reviewStatuses, type ReviewStatus } from "@/lib/cms/review-validation";
import { setReviewStatus } from "../../../app/admin/(dashboard)/reviews/actions";
import SubmitButton from "./SubmitButton";

export default function ReviewStatusForm({id,status,name}:{id:number;status:ReviewStatus;name:string}) {
  const [state,action]=useActionState(async (_state:string,data:FormData)=>{try{await setReviewStatus(data);return "Saved.";}catch{return "Unable to save. Please try again.";}},"");
  return <form action={action} onSubmit={event=>{const status=new FormData(event.currentTarget).get("status");if((status==="archived"||status==="rejected")&&!window.confirm(`Confirm ${status} for this review?`))event.preventDefault();}}>
    <input type="hidden" name="id" value={id}/><input type="hidden" name="confirmed" value="yes"/>
    <div className="flex gap-2"><select name="status" defaultValue={status} aria-label={`Status for ${name}`} className="form-input px-2 py-2 text-xs">{reviewStatuses.map(value=><option key={value} value={value}>{value}</option>)}</select><SubmitButton className="text-xs text-accent">Apply</SubmitButton></div>
    {state&&<p role="status" className="mt-2 text-xs">{state}</p>}
  </form>;
}
