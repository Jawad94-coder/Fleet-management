"use client";

import type { FleetService } from "@/data/content";
import { saveService } from "../../../app/admin/(dashboard)/cms-actions";
import CmsForm, { Field, StatusOrderFields } from "./CmsForm";
import ServiceDetailEditor from "./ServiceDetailEditor";
import ImageEditor, { type MediaOption } from "./ImageEditor";

const emptyDetail: FleetService["detail"] = { heading: "", intro: "", sections: [] };

export default function ServiceForm({service,media}:{service?:FleetService&{id:number;sortOrder:number;status:string};media:MediaOption[]}){
  return <CmsForm action={saveService} submitLabel={service?"Save service":"Create service"} className="border border-[#242424] bg-[#141414] p-5 sm:p-8">{service&&<input type="hidden" name="id" value={service.id}/>}<div className="grid gap-5 sm:grid-cols-2"><Field label="Service number" name="num" defaultValue={service?.num??""}/><Field label="Slug" name="slug" defaultValue={service?.slug??""}/><Field label="Title" name="title" defaultValue={service?.title??""}/><Field label="Font Awesome icon" name="icon" defaultValue={service?.icon??"fa-truck"}/><div className="sm:col-span-2"><ImageEditor name="image" label="Optional service image" value={service?.image} alt={service?.imageAlt} media={media}/></div><div className="sm:col-span-2"><Field label="Card description" name="description" type="textarea" rows={5} defaultValue={service?.desc??""}/></div><Field label="CTA label" name="ctaLabel" defaultValue={service?.ctaLabel??"View service"}/><Field label="CTA destination" name="ctaHref" defaultValue={service?.ctaHref??(service?`/services/${service.slug}`:"")}/><Field label="SEO title" name="seoTitle" required={false} defaultValue={service?.seoTitle??""}/><Field label="SEO keywords (comma separated)" name="seoKeywords" required={false} defaultValue={service?.seoKeywords?.join(", ")??""}/><div className="sm:col-span-2"><Field label="SEO description" name="seoDescription" type="textarea" required={false} defaultValue={service?.seoDescription??""}/></div><StatusOrderFields status={service?.status} sortOrder={service?.sortOrder}/></div><div className="mt-6"><ServiceDetailEditor value={service?.detail??emptyDetail}/></div></CmsForm>;
}
