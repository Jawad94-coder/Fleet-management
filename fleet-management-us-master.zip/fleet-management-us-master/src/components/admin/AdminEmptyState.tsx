export default function AdminEmptyState({ title, description }: { title: string; description: string }) {
  return <div className="border border-dashed border-[#363636] px-6 py-16 text-center"><i className="fas fa-inbox text-3xl text-[#4a4a4a]" aria-hidden="true" /><h2 className="font-display mt-4 text-2xl">{title}</h2><p className="mx-auto mt-2 max-w-md text-sm text-[#9a9a9a]">{description}</p></div>;
}
