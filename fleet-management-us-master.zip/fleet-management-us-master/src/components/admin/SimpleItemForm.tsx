"use client";

import CmsForm, { Field, StatusOrderFields } from "./CmsForm";
import DeleteConfirmation from "./DeleteConfirmation";
import { deleteSimpleItem, saveSimpleItem } from "../../../app/admin/(dashboard)/cms-actions";

export interface SimpleFieldConfig { name: string; label: string; value?: string | number | null; type?: "text" | "url" | "number" | "textarea"; required?: boolean; checkbox?: boolean }

export default function SimpleItemForm({ entity, id, title, fields, status = "published", sortOrder = 0 }: { entity: string; id?: number; title: string; fields: SimpleFieldConfig[]; status?: string; sortOrder?: number }) {
  return <article className="border border-[#242424] bg-[#141414] p-5"><div className="mb-4 flex items-center justify-between gap-3"><h3 className="font-display text-xl">{title}</h3>{id && <DeleteConfirmation action={deleteSimpleItem} id={id} itemName={title} entity={entity} />}</div><CmsForm action={saveSimpleItem} submitLabel={id ? "Save item" : "Add item"}><input type="hidden" name="entity" value={entity} />{id && <input type="hidden" name="id" value={id} />}<div className="grid gap-4 sm:grid-cols-2">{fields.map((field) => field.checkbox ? <label key={field.name} className="flex items-center gap-3 self-end py-3 text-sm"><input type="checkbox" name={field.name} defaultChecked={Boolean(field.value)} className="h-4 w-4 accent-[#FF6B00]" />{field.label}</label> : <Field key={field.name} label={field.label} name={field.name} defaultValue={field.value} type={field.type} required={field.required} />)}<StatusOrderFields status={status} sortOrder={sortOrder} /></div></CmsForm></article>;
}
