"use client";

import { useActionState, useEffect, useRef } from "react";
import type { ReviewFormState, ReviewValues } from "@/lib/cms/review-validation";
import ImageEditor, { type MediaOption } from "./ImageEditor";
import SubmitButton from "./SubmitButton";

type ReviewAction = (state: ReviewFormState, formData: FormData) => Promise<ReviewFormState>;
const inputClass = "form-input w-full px-4 py-3 text-sm";

export default function ReviewForm({ action, initialValues, id, resetOnSuccess = false, media }: { media:MediaOption[]; action: ReviewAction; initialValues?: Partial<ReviewValues>; id?: number; resetOnSuccess?: boolean }) {
  const [state, formAction] = useActionState(action, {});
  const form = useRef<HTMLFormElement>(null);
  useEffect(() => { if (state.success && resetOnSuccess) form.current?.reset(); }, [resetOnSuccess, state.success]);
  const error = (name: keyof ReviewValues) => state.fieldErrors?.[name];
  const field = (name: keyof ReviewValues, label: string, options: { required?: boolean; maxLength?: number; type?: string } = {}) => <div><label htmlFor={name} className="font-cond mb-2 block text-[10px] uppercase tracking-[0.2em] text-[#9a9a9a]">{label}{options.required ? " *" : ""}</label><input id={name} name={name} required={options.required} maxLength={options.maxLength} type={options.type} defaultValue={String(initialValues?.[name] ?? (name === "rating" ? 5 : name === "sortOrder" ? 0 : ""))} className={inputClass} aria-invalid={Boolean(error(name))} aria-describedby={error(name) ? `${name}-error` : undefined}/>{error(name)&&<p id={`${name}-error`} className="mt-1 text-xs text-red-400">{error(name)}</p>}</div>;
  return <form ref={form} action={formAction} onSubmit={event=>{const status=new FormData(event.currentTarget).get("status");if((status==="archived"||status==="rejected")&&!window.confirm(`Confirm ${status} for this review?`))event.preventDefault();}} className="border border-[#242424] bg-[#141414] p-5 sm:p-8">
    <input type="hidden" name="confirmed" value="yes"/>{id&&<input type="hidden" name="id" value={id}/>}<div><label htmlFor="quote" className="font-cond mb-2 block text-[10px] uppercase tracking-[0.2em] text-[#9a9a9a]">Review text *</label><textarea id="quote" name="quote" required minLength={20} maxLength={3000} rows={7} defaultValue={initialValues?.quote} className={inputClass} aria-invalid={Boolean(error("quote"))} aria-describedby={error("quote")?"quote-error":undefined}/>{error("quote")&&<p id="quote-error" className="mt-1 text-xs text-red-400">{error("quote")}</p>}</div>
    <div className="mt-5 grid gap-5 sm:grid-cols-2">{field("name","Carrier name",{required:true,maxLength:160})}{field("company","Company",{maxLength:200})}{field("role","Role",{required:true,maxLength:200})}{field("location","Location",{maxLength:160})}{field("equipment","Equipment / truck type",{maxLength:160})}{field("tenure","Tenure",{maxLength:160})}{field("initials","Initials",{required:true,maxLength:4})}<div className="sm:col-span-2"><ImageEditor name="avatarPath" label="Reviewer image" value={initialValues?.avatarPath??""} alt={initialValues?.avatarAlt??""} media={media}/></div>{field("rating","Rating (1–5)",{required:true,type:"number"})}{field("sortOrder","Display order",{required:true,type:"number"})}
      <div><label htmlFor="status" className="font-cond mb-2 block text-[10px] uppercase tracking-[0.2em] text-[#9a9a9a]">Status *</label><select id="status" name="status" defaultValue={initialValues?.status??"pending"} className={inputClass}><option value="pending">Pending</option><option value="published">Published</option>{id&&<><option value="rejected">Rejected</option><option value="archived">Archived</option></>}</select>{error("status")&&<p className="mt-1 text-xs text-red-400">{error("status")}</p>}</div>
      <label className="flex items-center gap-3 self-end py-3 text-sm"><input type="checkbox" name="featured" defaultChecked={initialValues?.featured??false} className="h-4 w-4 accent-[#FF6B00]"/> Featured review</label>
      <div className="sm:col-span-2"><label htmlFor="internalNotes" className="font-cond mb-2 block text-[10px] uppercase tracking-[0.2em] text-[#9a9a9a]">Internal admin notes</label><textarea id="internalNotes" name="internalNotes" maxLength={5000} rows={4} defaultValue={initialValues?.internalNotes??""} className={inputClass}/><p className="mt-1 text-xs text-[#6a6a6a]">Never shown publicly.</p></div>
    </div>{state.error&&<p role="alert" className="mt-5 border border-red-400/30 bg-red-400/5 p-3 text-sm text-red-400">{state.error}</p>}{state.success&&<p role="status" className="mt-5 border border-green-400/30 bg-green-400/5 p-3 text-sm text-green-400">{state.success}</p>}<div className="mt-6"><SubmitButton>{id?"Save changes":"Create review"}</SubmitButton></div>
  </form>;
}
