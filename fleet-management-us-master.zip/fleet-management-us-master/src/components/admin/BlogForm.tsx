"use client";

import { saveBlog } from "../../../app/admin/(dashboard)/blogs/actions";
import CmsForm, { Field } from "./CmsForm";
import type { BlogStatus } from "@/db/schema";
import ImageEditor, { type MediaOption } from "./ImageEditor";

export interface BlogFormValue {
  id: number;
  title: string;
  slug: string;
  excerpt: string | null;
  body: string;
  featuredImage: string | null;
  featuredImageAlt: string | null;
  author: string;
  category: string;
  tags: string[];
  publishedAt: Date | null;
  status: BlogStatus;
  readingTime: number;
  seoTitle: string | null;
  seoDescription: string | null;
  seoKeywords: string[] | null;
}

export default function BlogForm({ post, media }: { post?: BlogFormValue; media: MediaOption[] }) {
  return <CmsForm action={saveBlog} submitLabel={post ? "Save blog" : "Create blog"} className="border border-[#242424] bg-[#141414] p-5 sm:p-8">
    {post && <input type="hidden" name="id" value={post.id}/>}<div className="grid gap-5 sm:grid-cols-2">
      <Field label="Title" name="title" defaultValue={post?.title}/>
      <Field label="Slug" name="slug" defaultValue={post?.slug}/>
      <Field label="Author" name="author" defaultValue={post?.author}/>
      <Field label="Category" name="category" defaultValue={post?.category}/>
      <Field label="Tags (comma separated)" name="tags" required={false} defaultValue={post?.tags.join(", ")}/>
      <Field label="Reading time (minutes)" name="readingTime" type="number" defaultValue={post?.readingTime ?? 1}/>
      <label className="block"><span className="font-cond mb-2 block text-[10px] uppercase tracking-[0.2em] text-[#9a9a9a]">Status</span><select name="status" defaultValue={post?.status ?? "draft"} className="form-input w-full px-4 py-3 text-sm"><option value="draft">Draft</option><option value="published">Published</option><option value="archived">Archived</option></select></label>
      <label className="block"><span className="font-cond mb-2 block text-[10px] uppercase tracking-[0.2em] text-[#9a9a9a]">Published date</span><input name="publishedAt" type="datetime-local" defaultValue={post?.publishedAt?.toISOString().slice(0,16) ?? ""} className="form-input w-full px-4 py-3 text-sm"/></label>
      <div className="sm:col-span-2"><Field label="Excerpt" name="excerpt" type="textarea" required={false} rows={4} defaultValue={post?.excerpt}/></div>
      <div className="sm:col-span-2"><Field label="Content (Markdown)" name="body" type="textarea" rows={18} defaultValue={post?.body}/><p className="mt-2 text-xs text-[#777]">Supports headings, paragraphs, **bold**, *italic*, lists, [links](https://…), and ![images](https://…). Raw HTML is shown as text.</p></div>
      <div className="sm:col-span-2"><ImageEditor name="bodyImage" label="Append a body image" media={media}/></div>
      <div className="sm:col-span-2"><ImageEditor name="featuredImage" label="Featured image" value={post?.featuredImage??""} alt={post?.featuredImageAlt??""} media={media}/></div>
      <Field label="SEO title" name="seoTitle" required={false} defaultValue={post?.seoTitle}/>
      <Field label="SEO keywords (comma separated)" name="seoKeywords" required={false} defaultValue={post?.seoKeywords?.join(", ")}/>
      <Field label="SEO description" name="seoDescription" type="textarea" required={false} defaultValue={post?.seoDescription}/>
    </div>
  </CmsForm>;
}
