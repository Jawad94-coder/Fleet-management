"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const links = [
  ["/admin", "Dashboard", "fa-gauge-high"],
  ["/admin/content", "Content", "fa-file-lines"],
  ["/admin/services", "Services", "fa-gears"],
  ["/admin/truck-types", "Truck Types", "fa-truck"],
  ["/admin/pricing", "Pricing & Agreement", "fa-file-invoice-dollar"],
  ["/admin/reviews", "Reviews", "fa-star"],
  ["/admin/blogs", "Blogs", "fa-newspaper"],
  ["/admin/media", "Media", "fa-photo-film"],
  ["/admin/leads", "Carrier Leads", "fa-address-card"],
  ["/admin/audit", "Audit Log", "fa-clock-rotate-left"],
  ["/admin/settings", "Settings", "fa-sliders"],
] as const;

export default function AdminSidebar() {
  const pathname = usePathname();
  return (
    <nav aria-label="Admin navigation" className="flex gap-2 overflow-x-auto p-3 lg:block lg:space-y-1 lg:p-4">
      {links.map(([href, label, icon]) => {
        const active = href === "/admin" ? pathname === href : pathname.startsWith(href);
        return (
          <Link key={href} href={href} className={`flex shrink-0 items-center gap-3 px-4 py-3 font-cond text-xs uppercase tracking-[0.14em] transition ${active ? "bg-accent text-black" : "text-[#9a9a9a] hover:bg-[#181818] hover:text-white"}`}>
            <i className={`fas ${icon} w-4`} aria-hidden="true" /> {label}
          </Link>
        );
      })}
    </nav>
  );
}
