import Link from "next/link";
import type { ReactNode } from "react";
import AdminSidebar from "./AdminSidebar";

export default function AdminShell({ children, logoutAction }: { children: ReactNode; logoutAction: () => Promise<void> }) {
  return (
    <div className="min-h-screen bg-[#0a0a0a] lg:grid lg:grid-cols-[260px_1fr]">
      <aside className="border-b border-[#242424] bg-[#0d0d0d] lg:min-h-screen lg:border-b-0 lg:border-r">
        <div className="border-b border-[#242424] px-5 py-6">
          <p className="font-cond text-[10px] uppercase tracking-[0.25em] text-accent">Fleet Management US</p>
          <strong className="font-display mt-1 block text-2xl">CMS ADMIN</strong>
        </div>
        <AdminSidebar />
      </aside>
      <div className="min-w-0">
        <header className="flex items-center justify-end gap-3 border-b border-[#242424] bg-[#0d0d0d] px-4 py-4 sm:px-6 lg:px-8">
          <Link href="/" target="_blank" rel="noreferrer" prefetch={false} className="btn-secondary font-cond px-4 py-2 text-xs uppercase tracking-wider">View site</Link>
          <form action={logoutAction}>
            <button type="submit" className="font-cond border border-[#363636] px-4 py-2 text-xs uppercase tracking-wider text-[#9a9a9a] transition hover:border-red-400 hover:text-red-400">Logout</button>
          </form>
        </header>
        <main className="mx-auto max-w-[1500px] px-4 py-8 sm:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
