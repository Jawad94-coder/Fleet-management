"use client";

import { useEffect, useState } from "react";

export interface MediaOption { path: string; fileName: string }

export default function ImageEditor({ name, label, value = "", alt = "", media, required = false, removable = true }: { name: string; label: string; value?: string; alt?: string; media: MediaOption[]; required?: boolean; removable?: boolean }) {
  const [url, setUrl] = useState(value);
  const [preview, setPreview] = useState("");
  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);
  const listId = `${name.replace(/[^a-z0-9_-]/gi, "-")}-media`;
  return <fieldset className="border border-[#363636] p-4">
    <legend className="font-cond px-2 text-xs uppercase tracking-wider text-accent">{label}</legend>
    <label className="block text-xs text-[#999]">Image URL or existing upload{required ? " *" : ""}<input name={name} required={required} value={url} onChange={(event) => setUrl(event.target.value)} list={listId} placeholder="https://… or /images/…" className="form-input mt-2 w-full px-4 py-3 text-sm"/></label>
    <datalist id={listId}>{media.map((asset) => <option key={asset.path} value={asset.path}>{asset.fileName}</option>)}</datalist>
    <label className="mt-4 block text-xs text-[#999]">Upload replacement<input name={`${name}File`} type="file" accept="image/jpeg,image/png,image/webp,image/avif" onChange={(event) => { const file=event.target.files?.[0]; setPreview((current) => { if (current) URL.revokeObjectURL(current); return file ? URL.createObjectURL(file) : ""; }); }} className="form-input mt-2 block w-full p-3"/></label>
    <label className="mt-4 block text-xs text-[#999]">Image alternative text<input name={`${name}Alt`} required={required || Boolean(url || preview)} defaultValue={alt} maxLength={500} className="form-input mt-2 w-full px-4 py-3 text-sm"/></label>
    <p className="mt-2 text-xs text-[#777]">Upload to Cloudinary or paste an external URL. The saved image changes only after the form succeeds.</p>
    {(preview || url) && <div role="img" aria-label={`${label} preview`} className="mt-4 h-48 w-full border border-[#242424] bg-contain bg-center bg-no-repeat" style={{backgroundImage:`url(${JSON.stringify(preview || url)})`}}/>}
    {removable && url && <button type="button" onClick={() => { setUrl(""); setPreview(""); }} className="mt-3 text-xs text-red-400">Remove image</button>}
  </fieldset>;
}
