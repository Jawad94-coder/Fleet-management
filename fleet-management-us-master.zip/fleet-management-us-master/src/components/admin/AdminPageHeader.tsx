import type { ReactNode } from "react";

export default function AdminPageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: ReactNode }) {
  return (
    <header className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
      <div>
        <p className="font-cond text-[10px] uppercase tracking-[0.25em] text-accent">{eyebrow}</p>
        <h1 className="font-display mt-2 text-4xl sm:text-5xl">{title}</h1>
        {description && <p className="mt-3 max-w-2xl text-sm leading-relaxed text-[#9a9a9a]">{description}</p>}
      </div>
      {action}
    </header>
  );
}
