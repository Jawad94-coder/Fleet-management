"use client";

import { useActionState, useEffect, useRef } from "react";
import SubmitButton from "./SubmitButton";

export default function DeleteConfirmation({ action, id, itemName, entity, archive = true }: { action: (formData: FormData) => void | Promise<void>; id: number; itemName: string; entity?: string; archive?: boolean }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [state,run]=useActionState<{error?:string;success?:boolean},FormData>(async (_state:{error?:string;success?:boolean},data:FormData)=>{try{await action(data);return{success:true};}catch{return{error:"Removal failed. Refresh and try again."};}},{});
  useEffect(()=>{if(state.success)dialog.current?.close();},[state]);
  return <><button type="button" onClick={() => dialog.current?.showModal()} className="border border-red-400/40 px-3 py-2 font-cond text-xs uppercase tracking-wider text-red-400 transition hover:bg-red-400 hover:text-black">Remove</button><dialog aria-label="Confirm removal" ref={dialog} className="m-auto w-[min(92vw,460px)] border border-[#363636] bg-[#141414] p-0 text-[#f0f0f0] backdrop:bg-black/80"><div className="p-6 sm:p-8"><p className="font-cond text-xs uppercase tracking-[0.2em] text-red-400">Confirm removal</p><h2 className="font-display mt-3 text-3xl">REMOVE ITEM?</h2><p className="mt-4 text-sm leading-relaxed text-[#9a9a9a]">&ldquo;{itemName}&rdquo; will be {archive ? "unpublished and archived" : "permanently deleted"}.</p><form action={run} className="mt-7 flex justify-end gap-3"><input type="hidden" name="confirmed" value="yes"/><input type="hidden" name="id" value={id} />{entity && <input type="hidden" name="entity" value={entity} />}<button type="button" onClick={() => dialog.current?.close()} className="btn-secondary px-5 py-3 font-cond text-xs uppercase tracking-wider">Cancel</button><SubmitButton pendingLabel="Removing..." className="border border-red-400 bg-red-400 px-5 py-3 font-cond text-xs uppercase tracking-wider text-black disabled:opacity-50">Remove</SubmitButton></form>{state.error&&<p role="alert" className="mt-3 text-sm text-red-400">{state.error}</p>}</div></dialog></>;
}
