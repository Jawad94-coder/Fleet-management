"use client";

import { useState } from "react";
import ImageEditor, { type MediaOption } from "./ImageEditor";

export default function HeroImagesEditor({ images, alts, media }: { images: string[]; alts: string[]; media: MediaOption[] }) {
  const [items,setItems]=useState(() => images.map((url,index) => ({id:index,url,alt:alts[index]??""})));
  const move=(index:number,direction:-1|1)=>setItems(current=>{const next=[...current],target=index+direction;if(target<0||target>=next.length)return current;[next[index],next[target]]=[next[target],next[index]];return next;});
  return <fieldset className="mt-5 border border-[#242424] p-4"><legend className="font-cond px-2 text-xs uppercase tracking-wider text-accent">Hero slideshow images</legend>
    <input type="hidden" name="heroImageCount" value={items.length}/>
    <div className="space-y-4">{items.map((item,index)=><div key={item.id}><ImageEditor name={`heroImage${index}`} label={`Hero image ${index+1}`} value={item.url} alt={item.alt} media={media} required removable={false}/><div className="mt-2 flex gap-2"><button type="button" onClick={()=>move(index,-1)} className="btn-secondary px-3 py-2">↑</button><button type="button" onClick={()=>move(index,1)} className="btn-secondary px-3 py-2">↓</button><button type="button" onClick={()=>setItems(current=>current.filter((_,i)=>i!==index))} className="border border-red-400/40 px-3 py-2 text-xs text-red-400">Remove</button></div></div>)}</div>
    <button type="button" onClick={()=>setItems(current=>[...current,{id:Math.max(-1,...current.map(item=>item.id))+1,url:"",alt:""}])} disabled={items.length>=20} className="btn-secondary mt-4 px-4 py-2 text-xs disabled:opacity-50">Add image</button>
  </fieldset>;
}
