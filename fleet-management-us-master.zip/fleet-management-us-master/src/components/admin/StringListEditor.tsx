"use client";

import { useState } from "react";

export default function StringListEditor({ name, label, values }: { name: string; label: string; values: string[] }) {
  const [items, setItems] = useState(values);
  const move = (index: number, direction: -1 | 1) => setItems((current) => { const next = [...current]; const target = index + direction; if (target < 0 || target >= next.length) return current; [next[index], next[target]] = [next[target], next[index]]; return next; });
  return <fieldset className="border border-[#242424] p-4"><legend className="font-cond px-2 text-xs uppercase tracking-wider text-accent">{label}</legend><input type="hidden" name={name} value={JSON.stringify(items)} /><div className="space-y-3">{items.map((item, index) => <div key={index} className="flex gap-2"><input value={item} onChange={(event) => setItems((current) => current.map((value, itemIndex) => itemIndex === index ? event.target.value : value))} className="form-input min-w-0 flex-1 px-3 py-2 text-sm" aria-label={`${label} item ${index + 1}`} /><button type="button" onClick={() => move(index, -1)} className="btn-secondary px-3" aria-label="Move up">↑</button><button type="button" onClick={() => move(index, 1)} className="btn-secondary px-3" aria-label="Move down">↓</button><button type="button" onClick={() => setItems((current) => current.filter((_, itemIndex) => itemIndex !== index))} className="border border-red-400/40 px-3 text-red-400" aria-label="Remove item">×</button></div>)}</div><button type="button" onClick={() => setItems((current) => [...current, ""])} className="btn-secondary mt-3 px-4 py-2 text-xs">Add item</button></fieldset>;
}
