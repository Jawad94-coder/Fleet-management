"use client";

import { useActionState } from "react";
import { updateApplicationStatus, type LeadStatusFormState } from "../../../app/admin/actions";
import type { ApplicationStatus } from "@/db/schema";
import SubmitButton from "./SubmitButton";

const statuses: ApplicationStatus[] = ["new", "contacted", "qualified", "onboarding", "closed", "rejected"];
const labels: Record<ApplicationStatus, string> = {
  new: "New",
  contacted: "Contacted",
  qualified: "Qualified",
  onboarding: "Onboarding",
  closed: "Closed",
  rejected: "Rejected",
};

export default function LeadStatusForm({ id, status }: { id: number; status: ApplicationStatus }) {
  const [state, action] = useActionState(updateApplicationStatus, {} as LeadStatusFormState);

  return (
    <form action={action} className="flex min-w-56 flex-wrap gap-2">
      <input type="hidden" name="id" value={id} />
      <select name="status" defaultValue={status} className="form-input min-w-28 px-2 py-2 text-xs" aria-label="Carrier lead status">
        {statuses.map((value) => <option key={value} value={value}>{labels[value]}</option>)}
      </select>
      <SubmitButton pendingLabel="Saving..." className="border border-accent/40 px-3 py-2 text-xs text-accent disabled:opacity-50">Save</SubmitButton>
      {state.success && <span className="basis-full text-xs text-green-400" role="status">{state.success}</span>}
      {state.error && <span className="basis-full text-xs text-red-400" role="alert">{state.error}</span>}
    </form>
  );
}
