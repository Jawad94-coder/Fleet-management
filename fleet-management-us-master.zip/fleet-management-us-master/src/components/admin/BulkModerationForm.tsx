"use client";

import { useActionState, type FormEvent, type ReactNode } from "react";

export default function BulkModerationForm({ action, kind, children }: { action: (formData: FormData) => void | Promise<void>; kind: "reviews" | "leads"; children: ReactNode }) {
  const [state, run, pending] = useActionState(async (_state: string, data: FormData) => {
    try { await action(data); return "Changes saved."; }
    catch { return "The changes could not be saved. Select at least one record and try again."; }
  }, "");
  function prepare(event: FormEvent<HTMLFormElement>) {
    const value=((event.nativeEvent as SubmitEvent).submitter as HTMLButtonElement|null)?.value;
    if((value==="archived"||value==="rejected")&&!window.confirm(`Confirm ${value} for the selected ${kind}?`))event.preventDefault();
    const confirmation=event.currentTarget.elements.namedItem("confirmed") as HTMLInputElement;
    confirmation.value="yes";
  }
  return <>{children}<form id={`bulk-${kind}`} action={run} onSubmit={prepare}><input type="hidden" name="confirmed" value="yes"/><fieldset disabled={pending}><div className="mt-4 flex flex-wrap items-center gap-2" aria-label={`Bulk ${kind} actions`}><span className="mr-2 text-xs text-[#777]">Selected:</span>{kind==="reviews"?<><button name="bulkStatus" value="published" className="btn-secondary px-4 py-2 text-xs">Publish</button><button name="bulkStatus" value="pending" className="btn-secondary px-4 py-2 text-xs">Unpublish</button><button name="bulkStatus" value="rejected" className="btn-secondary px-4 py-2 text-xs">Reject</button><button name="bulkStatus" value="archived" className="border border-red-400/40 px-4 py-2 text-xs text-red-400">Archive</button></>:<><button name="bulkStatus" value="contacted" className="btn-secondary px-4 py-2 text-xs">Mark contacted</button><button name="bulkStatus" value="qualified" className="btn-secondary px-4 py-2 text-xs">Mark qualified</button>{["new","onboarding","closed","rejected"].map(status=><button key={status} name="bulkStatus" value={status} className="btn-secondary px-4 py-2 text-xs capitalize">{status}</button>)}<button name="bulkStatus" value="archived" className="border border-red-400/40 px-4 py-2 text-xs text-red-400">Archive</button></>}</div></fieldset>{state && <p role="status" className="mt-3 text-sm">{state}</p>}</form></>;
}
