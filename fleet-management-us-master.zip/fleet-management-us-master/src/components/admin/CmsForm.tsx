"use client";

import { useActionState } from "react";
import SubmitButton from "./SubmitButton";
import type { CmsFormState } from "@/lib/cms/admin-validation";

export type CmsAction = (state: CmsFormState, formData: FormData) => Promise<CmsFormState>;

export default function CmsForm({ action, children, submitLabel = "Save changes", className = "" }: { action: CmsAction; children: React.ReactNode; submitLabel?: string; className?: string }) {
  const [state, formAction] = useActionState(action, {} as CmsFormState);
  return <form action={formAction} className={className}>{children}{state.error && <p role="alert" className="mt-4 border border-red-400/30 bg-red-400/5 p-3 text-sm text-red-400">{state.error}</p>}{state.success && <p role="status" className="mt-4 border border-green-400/30 bg-green-400/5 p-3 text-sm text-green-400">{state.success}</p>}<div className="mt-5"><SubmitButton>{submitLabel}</SubmitButton></div></form>;
}

export function Field({ label, name, defaultValue, type = "text", required = true, rows = 4 }: { label: string; name: string; defaultValue?: string | number | null; type?: "text" | "url" | "email" | "tel" | "number" | "textarea"; required?: boolean; rows?: number }) {
  const className = "form-input w-full px-4 py-3 text-sm";
  return <label className="block"><span className="font-cond mb-2 block text-[10px] uppercase tracking-[0.2em] text-[#9a9a9a]">{label}{required ? " *" : ""}</span>{type === "textarea" ? <textarea name={name} required={required} rows={rows} defaultValue={defaultValue ?? ""} className={className} /> : <input name={name} type={type} required={required} defaultValue={defaultValue ?? ""} className={className} />}</label>;
}

export function StatusOrderFields({ status = "draft", sortOrder = 0 }: { status?: string; sortOrder?: number }) {
  return <><label className="block"><span className="font-cond mb-2 block text-[10px] uppercase tracking-[0.2em] text-[#9a9a9a]">Status</span><select name="status" defaultValue={status} className="form-input w-full px-4 py-3 text-sm"><option value="published">Published</option><option value="draft">Draft / hidden</option></select></label><Field label="Display order" name="sortOrder" type="number" defaultValue={sortOrder} /></>;
}
