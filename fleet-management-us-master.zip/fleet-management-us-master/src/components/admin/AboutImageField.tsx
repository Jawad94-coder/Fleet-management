import ImageEditor, { type MediaOption } from "./ImageEditor";

export default function AboutImageField({value,alt,media}:{value:string;alt:string;media:MediaOption[]}) {
  return <div className="sm:col-span-2"><ImageEditor name="image" label="About image" value={value} alt={alt} media={media}/></div>;
}
