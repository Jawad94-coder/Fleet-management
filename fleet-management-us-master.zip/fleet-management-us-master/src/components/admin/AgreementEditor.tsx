"use client";

import { useState } from "react";
import type { AgreementDocumentContent, AgreementSectionContent } from "@/lib/cms/types";
import { updateAgreement } from "../../../app/admin/(dashboard)/cms-actions";
import CmsForm, { Field } from "./CmsForm";

const renderItems = (items: AgreementSectionContent["items"] = []) => items.map((item) => item.name ? `${item.name}:: ${item.description}` : item.description).join("\n");
const parseItems = (value: string) => value.split("\n").map((line) => line.trim()).filter(Boolean).map((line) => {
  const [name, ...description] = line.split("::");
  return description.length ? { name: name.trim(), description: description.join("::").trim() } : { description: line };
});

export default function AgreementEditor({ agreement }: { agreement: AgreementDocumentContent }) {
  const [sections, setSections] = useState(agreement.sections);
  const update = (index: number, value: Partial<AgreementSectionContent>) => setSections((current) => current.map((section, i) => i === index ? { ...section, ...value } : section));
  const move = (index: number, direction: -1 | 1) => setSections((current) => { const next=[...current]; const target=index+direction; if(target<0||target>=next.length)return current; [next[index],next[target]]=[next[target],next[index]]; return next; });
  return <CmsForm action={updateAgreement} className="border border-[#242424] bg-[#141414] p-5 sm:p-8">
    <div className="grid gap-4 sm:grid-cols-2"><Field label="Version" name="version" defaultValue={agreement.version}/><Field label="Document title" name="title" defaultValue={agreement.title}/><div className="sm:col-span-2"><Field label="Introduction" name="intro" type="textarea" rows={5} defaultValue={agreement.intro}/></div><Field label="Carrier signature label" name="carrierSignatureLabel" defaultValue={agreement.carrierSignatureLabel}/><Field label="Carrier signature help" name="carrierSignatureHelp" defaultValue={agreement.carrierSignatureHelp}/><Field label="Company signature label" name="companySignatureLabel" defaultValue={agreement.companySignatureLabel}/><Field label="Company signature help" name="companySignatureHelp" defaultValue={agreement.companySignatureHelp}/></div>
    <input type="hidden" name="sections" value={JSON.stringify(sections)}/><h3 className="font-display mt-8 text-2xl">Agreement sections</h3>
    <p className="mt-2 text-xs text-[#777]">For named list items, use <code>Name:: Description</code>, one item per line.</p>
    <div className="mt-4 space-y-4">{sections.map((section,index)=><article key={index} className="border border-[#303030] p-4"><div className="grid gap-3 sm:grid-cols-3"><input aria-label="Section number" value={section.number} onChange={(event)=>update(index,{number:event.target.value})} className="form-input px-3 py-2"/><input aria-label="Section title" value={section.title} onChange={(event)=>update(index,{title:event.target.value})} className="form-input px-3 py-2 sm:col-span-2"/><select aria-label="Section type" value={section.kind} onChange={(event)=>update(index,{kind:event.target.value as AgreementSectionContent["kind"]})} className="form-input px-3 py-2"><option value="text">Text</option><option value="list">List</option><option value="carrier">Carrier details</option><option value="company">Company details</option><option value="pricing">Pricing table</option></select><label className="flex items-center gap-2"><input type="checkbox" checked={Boolean(section.wide)} onChange={(event)=>update(index,{wide:event.target.checked})}/> Wide layout</label><div className="flex gap-2"><button type="button" className="btn-secondary px-3" onClick={()=>move(index,-1)}>Move up</button><button type="button" className="btn-secondary px-3" onClick={()=>move(index,1)}>Move down</button></div><textarea aria-label="Description" value={section.description??""} onChange={(event)=>update(index,{description:event.target.value})} rows={4} placeholder="Description" className="form-input px-3 py-2 sm:col-span-3"/><textarea aria-label="List items" value={renderItems(section.items)} onChange={(event)=>update(index,{items:parseItems(event.target.value)})} rows={5} placeholder="One list item per line" className="form-input px-3 py-2 sm:col-span-3"/></div><button type="button" onClick={()=>setSections((current)=>current.filter((_,i)=>i!==index))} className="mt-3 text-xs text-red-400">Remove section</button></article>)}</div>
    <button type="button" onClick={()=>setSections((current)=>[...current,{number:String(current.length+1).padStart(2,"0"),title:"New section",kind:"text",description:""}])} className="btn-secondary mt-4 px-4 py-2">Add section</button>
  </CmsForm>;
}
