"use client";

import { useRef } from "react";
import type { BlogStatus } from "@/db/schema";

export default function BlogStatusForm({ id, status, action }: { id: number; status: BlogStatus; action: (formData: FormData) => void | Promise<void> }) {
  const select = useRef<HTMLSelectElement>(null);
  return <form action={action} className="flex items-center gap-2" onSubmit={event=>{
    if (status === "published" && select.current?.value === "draft" && !window.confirm("Unpublish this blog post? It will disappear from the public website.")) event.preventDefault();
  }}><input type="hidden" name="id" value={id}/><select ref={select} name="status" defaultValue={status === "archived" ? "draft" : status} className="form-input px-2 py-2 text-xs"><option value="draft">Draft</option><option value="published">Published</option></select><button className="btn-secondary px-3 py-2 text-xs">Apply</button></form>;
}
