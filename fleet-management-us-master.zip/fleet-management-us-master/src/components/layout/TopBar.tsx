"use client";

import { useCms } from "@/components/CmsProvider";
import { SocialIcon } from "@/components/ui/SocialIcon";

export default function TopBar() {
  const { company, socialLinks, dispatchStatusText } = useCms();
  return (
    <div className="border-b border-[#1a1a1a] bg-[#070707] text-xs">
      <div className="site-container py-2.5 flex justify-between items-center gap-3 sm:gap-4">
        <div className="flex items-center gap-4 sm:gap-6 text-[#9a9a9a] flex-wrap">
          <a
            href={company.phoneHref}
            className="flex items-center gap-2 hover:text-accent transition"
          >
            <i className="fas fa-phone text-accent text-[10px]"></i>
            <span className="font-cond tracking-wider">{company.phone}</span>
          </a>
          <a
            href={company.emailHref}
            className="hidden md:flex items-center gap-2 hover:text-accent transition"
          >
            <i className="fas fa-envelope text-accent text-[10px]"></i>
            <span className="font-cond tracking-wider">
              {company.email}
            </span>
          </a>
          <span className="hidden lg:flex items-center gap-2">
            <i className="fas fa-clock text-accent text-[10px]"></i>
            <span className="font-cond tracking-wider">
              {company.hours}
            </span>
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-[#b8b8b8]">
          {socialLinks.slice(0, 4).map((s) => (
            <a
              key={s.label}
              href={s.href}
              aria-label={s.label}
              title={s.label}
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-7 w-7 items-center justify-center rounded-full border border-[#343434] hover:border-accent hover:bg-accent hover:text-black transition"
            >
              <SocialIcon icon={s.icon} label={s.label} className="h-3.5 w-3.5" />
            </a>
          ))}
          <span className="hidden md:inline mx-2 text-[#363636]">|</span>
          <span className="hidden md:flex items-center gap-2">
            <span className="pulse-dot"></span>
            <span className="font-cond tracking-wider text-accent">
              {dispatchStatusText}
            </span>
          </span>
        </div>
      </div>
    </div>
  );
}
