"use client";

import { useEffect } from "react";
import { useCms } from "@/components/CmsProvider";
import { navHref } from "@/lib/navigation";

interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
  fromSubpage?: boolean;
}

export default function MobileNav({ isOpen, onClose, fromSubpage = false }: MobileNavProps) {
  const { navLinks, heroPrimaryCtaHref, heroPrimaryCtaLabel, sectionCopy } = useCms();

  useEffect(() => {
    if (!isOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [isOpen]);

  return (
    <div
      id="site-mobile-menu"
      className={`mobile-nav lg:hidden ${isOpen ? "active" : ""}`}
      aria-hidden={!isOpen}
      inert={!isOpen}
    >
      <div className="p-4 sm:p-6">
        <div className="flex justify-between items-center mb-12">
          <div className="font-display text-2xl">{sectionCopy.mobileMenuLabel}</div>
          <button
            onClick={onClose}
            className="w-10 h-10 border border-[#363636] flex items-center justify-center"
            aria-label="Close menu"
          >
            <i className="fas fa-times"></i>
          </button>
        </div>
        <nav className="flex flex-col gap-1">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={navHref(link.href, fromSubpage)}
              onClick={onClose}
              className="mobile-link font-display text-3xl sm:text-4xl py-3 sm:py-4 border-b border-[#1a1a1a]"
            >
              {link.label}
            </a>
          ))}
        </nav>
        <a
          href={navHref(heroPrimaryCtaHref, fromSubpage)}
          onClick={onClose}
          className="mobile-link btn-primary w-full mt-8 py-4 font-cond tracking-wider uppercase"
        >
          {heroPrimaryCtaLabel}
        </a>
      </div>
    </div>
  );
}
