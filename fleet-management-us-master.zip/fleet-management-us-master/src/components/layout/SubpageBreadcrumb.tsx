"use client";

import Link from "next/link";
import { useCms } from "@/components/CmsProvider";

interface SubpageBreadcrumbProps {
  parentHref: string;
  parentLabel: string;
  currentLabel: string;
  rootOnly?: boolean;
}

export default function SubpageBreadcrumb({ parentHref, parentLabel, currentLabel, rootOnly = false }: SubpageBreadcrumbProps) {
  const {sectionCopy}=useCms();
  return (
    <div className="border-b border-[#1a1a1a] bg-[#0d0d0d]">
      <div className="site-container flex min-w-0 items-center justify-between gap-4 py-3">
        <Link href={parentHref} className="shrink-0 font-cond text-xs font-semibold uppercase tracking-[0.16em] text-accent transition hover:text-[#ff8533]">
          <i className="fas fa-arrow-left mr-2"></i> {sectionCopy.breadcrumbBackPrefix} {parentLabel}
        </Link>
        <nav aria-label="Breadcrumb" className="hidden min-w-0 items-center gap-2 font-cond text-xs uppercase tracking-wider text-[#808080] sm:flex">
          <Link href="/#home" className="transition hover:text-accent">{sectionCopy.breadcrumbHomeLabel}</Link>
          {!rootOnly && <><i className="fas fa-chevron-right text-[8px]"></i><Link href={parentHref} className="transition hover:text-accent">{parentLabel}</Link></>}
          <i className="fas fa-chevron-right text-[8px]"></i>
          <span aria-current="page" className="truncate text-[#c0c0c0]">{currentLabel}</span>
        </nav>
      </div>
    </div>
  );
}
