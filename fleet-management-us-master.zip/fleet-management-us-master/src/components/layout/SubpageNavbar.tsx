"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useCms } from "@/components/CmsProvider";
import { navHref, subpageActiveNavHref } from "@/lib/navigation";
import { bypassImageOptimization } from "@/lib/image";
import DesktopNav from "./DesktopNav";
import MobileNav from "./MobileNav";

export default function SubpageNavbar() {
  const { company, sectionCopy } = useCms();
  const pathname = usePathname();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  return (
    <>
      <nav className="sticky top-0 z-50 border-b border-[#1a1a1a] bg-[#0a0a0a]/95 backdrop-blur-md">
        <div className="site-container py-4 flex items-center justify-between gap-4">
          <Link href="/#home" className="flex min-w-0 items-center gap-2 sm:gap-3">
            <Image src={company.logo} alt={company.logoAlt} unoptimized={bypassImageOptimization(company.logo)} width={56} height={56} sizes="(max-width: 639px) 48px, 56px" loading="eager" className="h-12 w-12 shrink-0 object-contain sm:h-14 sm:w-14" />
            <span className="min-w-0">
              <span className="block truncate font-display text-base leading-none sm:text-xl">{company.shortName}</span>
              <span className="mt-1 block font-cond text-[9px] tracking-[0.3em] text-accent">{company.tagline}</span>
            </span>
          </Link>
          <DesktopNav activeHref={subpageActiveNavHref(pathname)} fromSubpage />
          <div className="flex shrink-0 items-center gap-2">
            <Link href={navHref(sectionCopy.subpageCtaHref, true)} className="subpage-cta btn-primary px-5 py-2.5 font-cond text-xs uppercase tracking-wider">
              {sectionCopy.subpageCtaLabel} <i className="fas fa-arrow-right ml-2"></i>
            </Link>
            <button
              type="button"
              onClick={() => setMobileNavOpen(true)}
              className="flex h-10 w-10 items-center justify-center border border-[#363636] lg:hidden"
              aria-label="Open menu"
              aria-controls="site-mobile-menu"
              aria-expanded={mobileNavOpen}
            >
              <i className="fas fa-bars" aria-hidden="true"></i>
            </button>
          </div>
        </div>
      </nav>
      <MobileNav isOpen={mobileNavOpen} onClose={() => setMobileNavOpen(false)} fromSubpage />
    </>
  );
}
