"use client";

import Link from "next/link";
import Image from "next/image";
import { useCms } from "@/components/CmsProvider";
import { navHref } from "@/lib/navigation";
import { bypassImageOptimization } from "@/lib/image";
import { SocialIcon } from "@/components/ui/SocialIcon";

export default function Footer() {
  const { company, navLinks, socialLinks, heroShowAuthority, sectionCopy:copy } = useCms();
  const policyLinks = [
    { href: copy.footerPrivacyHref, label: copy.footerPrivacyLabel },
    { href: copy.footerTermsHref, label: copy.footerTermsLabel },
    { href: copy.footerBrochureHref, label: copy.footerBrochureLabel },
  ].filter((link) => link.href && link.href !== "#");
  return (
    <footer className="bg-[#070707] border-t border-[#1a1a1a] pt-14 sm:pt-20 pb-8 relative">
      <div className="site-container">
        <div className="grid md:grid-cols-12 gap-10 sm:gap-12 mb-14">
          <div className="md:col-span-5">
            <Link href="/#home" className="flex items-center gap-3 mb-6">
              <Image src={company.logo} alt={company.logoAlt} unoptimized={bypassImageOptimization(company.logo)} width={600} height={600} sizes="64px" className="h-16 w-16 object-contain" />
              <div>
                <div className="font-display text-xl">{company.shortName}</div>
                <div className="font-cond text-[10px] tracking-[0.35em] text-accent mt-1">{company.tagline}</div>
              </div>
            </Link>
            <p className="text-[#9a9a9a] max-w-md leading-relaxed mb-6 text-sm">
              {copy.footerDescription}
            </p>
            {socialLinks.length>0&&<div className="mb-6">
              <span className="mb-3 block font-cond text-xs tracking-[0.2em] uppercase text-[#a0a0a0]">{copy.footerFollowLabel}</span>
              <div className="flex flex-wrap gap-2">
                {socialLinks.map((s) => (
                  <a
                    key={s.label}
                    href={s.href}
                    aria-label={s.label}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex min-h-10 items-center gap-2 border border-[#303030] px-3 text-[#c2c2c2] hover:border-accent hover:bg-accent hover:text-black transition"
                  >
                    <SocialIcon icon={s.icon} label={s.label} className="h-4 w-4 shrink-0" />
                    <span className="font-cond text-xs uppercase tracking-wider">{s.label}</span>
                  </a>
                ))}
              </div>
            </div>}
            {heroShowAuthority && <div className="flex flex-wrap gap-3">
              <span className="tag">DOT #{company.dot}</span>
              <span className="tag">MC #{company.mc}</span>
            </div>}
          </div>

          <div className="md:col-span-3">
            <h2 className="font-cond tracking-[0.2em] uppercase text-sm mb-5 text-accent">{copy.footerNavigationLabel}</h2>
            <ul className="space-y-3 text-[#9a9a9a] text-sm">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <Link href={navHref(link.href, true)} className="hover:text-accent transition flex items-center gap-2">
                    <i className="fas fa-chevron-right text-[8px]"></i> {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-4">
            <h2 className="font-cond tracking-[0.2em] uppercase text-sm mb-5 text-accent">{copy.footerContactLabel}</h2>
            <ul className="space-y-4 text-[#9a9a9a] text-sm">
              <li className="flex items-start gap-3">
                <i className="fas fa-location-dot text-accent mt-1"></i>
                <span>{company.address}<br />{company.city}</span>
              </li>
              <li className="flex items-center gap-3">
                <i className="fas fa-phone text-accent"></i>
                <a href={company.phoneHref} className="hover:text-accent transition">{company.phone}</a>
              </li>
              <li className="flex items-center gap-3">
                <i className="fas fa-envelope text-accent"></i>
                <a href={company.emailHref} className="hover:text-accent transition break-all">{company.email}</a>
              </li>
              <li className="flex items-center gap-3">
                <i className="fas fa-clock text-accent"></i>
                <span>{company.hours}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-[#1a1a1a] flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[#808080] text-xs font-cond tracking-wider">{company.copyright}</p>
          {policyLinks.length > 0 && <div className="flex flex-wrap sm:flex-nowrap justify-center sm:justify-start items-center gap-x-6 gap-y-3 sm:gap-6 text-[#808080] text-xs font-cond tracking-wider">
            {policyLinks.map((link) => <Link key={link.label} href={link.href}>{link.label}</Link>)}
          </div>}
        </div>
      </div>

      <div className="h-1 bg-gradient-to-r from-transparent via-accent to-transparent mt-8"></div>
    </footer>
  );
}
