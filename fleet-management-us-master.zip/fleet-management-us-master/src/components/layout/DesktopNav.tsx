"use client";

import Link from "next/link";
import { useCms } from "@/components/CmsProvider";
import { navHref } from "@/lib/navigation";

export default function DesktopNav({ activeHref, fromSubpage = false }: { activeHref: string; fromSubpage?: boolean }) {
  const { navLinks, services, truckTypes } = useCms();

  return <div className="hidden items-center gap-5 lg:flex xl:gap-8">
    {navLinks.map((link) => {
      const children = link.href === "#services"
        ? services.map((service) => ({ href: `/services/${service.slug}`, label: service.title }))
        : link.href === "#trucks"
          ? truckTypes.map((truck) => ({ href: `/truck-types/${truck.slug}`, label: truck.name }))
          : [];

      return <div key={link.href} className="group relative">
        <Link
          href={navHref(link.href, fromSubpage)}
          aria-haspopup={children.length ? "menu" : undefined}
          className={`nav-link font-cond text-xs uppercase tracking-wider xl:text-sm ${activeHref === link.href ? "active" : ""}`}
        >
          <span className="inline-flex items-center gap-1.5">
            {link.label}
            {children.length > 0 && <i className="fas fa-chevron-down text-[8px] transition-transform group-hover:rotate-180 group-focus-within:rotate-180" aria-hidden="true" />}
          </span>
        </Link>
        {children.length > 0 && <div className="pointer-events-none invisible absolute left-1/2 top-full z-[60] w-64 -translate-x-1/2 pt-5 opacity-0 transition group-hover:pointer-events-auto group-hover:visible group-hover:opacity-100 group-focus-within:pointer-events-auto group-focus-within:visible group-focus-within:opacity-100">
          <div className="border border-[#363636] bg-[#0d0d0d] p-2 shadow-2xl">
            {children.map((child) => <Link key={child.href} href={child.href} className="block border-b border-[#242424] px-4 py-3 font-cond text-xs uppercase tracking-[0.12em] text-[#aaa] transition last:border-0 hover:bg-[#181818] hover:text-accent focus:bg-[#181818] focus:text-accent">
              {child.label}
            </Link>)}
          </div>
        </div>}
      </div>;
    })}
  </div>;
}
