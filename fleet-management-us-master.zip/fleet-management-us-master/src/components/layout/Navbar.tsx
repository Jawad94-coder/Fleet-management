import Image from "next/image";
import { useCms } from "@/components/CmsProvider";
import { bypassImageOptimization } from "@/lib/image";
import DesktopNav from "./DesktopNav";

interface NavbarProps {
  activeSection: string;
  mobileNavOpen: boolean;
  onMobileToggle: () => void;
}

export default function Navbar({ activeSection, mobileNavOpen, onMobileToggle }: NavbarProps) {
  const { company, heroPrimaryCtaHref, heroPrimaryCtaLabel } = useCms();
  return (
    <nav className="sticky top-0 z-50 bg-[#0a0a0a]/95 backdrop-blur-md border-b border-[#1a1a1a]">
      <div className="site-container py-4 flex justify-between items-center">
        <a href="#home" className="flex items-center gap-2 sm:gap-3 min-w-0">
          <Image src={company.logo} alt={company.logoAlt} unoptimized={bypassImageOptimization(company.logo)} width={56} height={56} sizes="(max-width: 639px) 48px, 56px" loading="eager" className="w-12 h-12 sm:w-14 sm:h-14 shrink-0 object-contain" />
          <div>
            <div className="font-display text-base sm:text-xl leading-none whitespace-nowrap">{company.shortName}</div>
            <div className="font-cond text-[8px] sm:text-[10px] tracking-[0.25em] sm:tracking-[0.35em] text-accent mt-1">{company.tagline}</div>
          </div>
        </a>
        <DesktopNav activeHref={`#${activeSection}`} />
        <div className="flex items-center gap-2 md:gap-3">
          <a
            href={heroPrimaryCtaHref}
            className="navbar-cta btn-primary shrink-0 whitespace-nowrap px-3 md:px-6 py-2 md:py-3 font-cond tracking-wider text-[11px] md:text-sm uppercase"
          >
            {heroPrimaryCtaLabel} <i className="fas fa-arrow-right hidden min-[360px]:inline ml-1.5 md:ml-2 text-[10px] md:text-xs"></i>
          </a>
          <button
            onClick={onMobileToggle}
            className="lg:hidden w-10 h-10 border border-[#363636] flex items-center justify-center"
            aria-label="Open menu"
            aria-controls="site-mobile-menu"
            aria-expanded={mobileNavOpen}
          >
            <i className="fas fa-bars"></i>
          </button>
        </div>
      </div>
    </nav>
  );
}
