"use client";

import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { CmsProvider } from "@/components/CmsProvider";
import TopBar from "@/components/layout/TopBar";
import Navbar from "@/components/layout/Navbar";
import MobileNav from "@/components/layout/MobileNav";
import Hero from "@/components/sections/Hero";
import MarqueeBanner from "@/components/ui/MarqueeBanner";
import About from "@/components/sections/About";
import Services from "@/components/sections/Services";
import TruckTypes from "@/components/sections/TruckTypes";
import AgreementPricing from "@/components/sections/AgreementPricing";
import HowItWorks from "@/components/sections/HowItWorks";
import Contact from "@/components/sections/Contact";
import Testimonials from "@/components/sections/Testimonials";
import Footer from "@/components/layout/Footer";
import AgreementModal from "@/components/modals/AgreementModal";
import Toast from "@/components/ui/Toast";
import { useActiveSection } from "@/hooks/useActiveSection";
import type { PublicSiteContent } from "@/lib/cms/types";

export default function HomePage({ content, children }: { content: PublicSiteContent; children?: ReactNode }) {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [agreementOpen, setAgreementOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState("Done.");
  const [toastShow, setToastShow] = useState(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const activeSection = useActiveSection(content.sectionIds);

  const showToast = useCallback((message: string) => {
    setToastMessage(message);
    setToastShow(true);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastShow(false), 3500);
  }, []);

  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") setAgreementOpen(false);
    }

    function clearHash() {
      window.history.replaceState(window.history.state, "", window.location.pathname + window.location.search);
    }

    function handleHashClick(e: MouseEvent) {
      if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || !(e.target instanceof Element)) return;
      const anchor = e.target.closest<HTMLAnchorElement>('a[href^="#"]');
      const target = anchor?.hash && document.getElementById(anchor.hash.slice(1));
      if (!target) return;
      e.preventDefault();
      target.scrollIntoView({ behavior: "smooth" });
      clearHash();
    }

    const initialTarget = document.getElementById(window.location.hash.slice(1));
    if (initialTarget) {
      initialTarget.scrollIntoView();
      clearHash();
    }

    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("click", handleHashClick);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("click", handleHashClick);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = agreementOpen ? "hidden" : "";
  }, [agreementOpen]);

  return (
    <CmsProvider content={content}>
      <TopBar />
      <Navbar activeSection={activeSection} mobileNavOpen={mobileNavOpen} onMobileToggle={() => setMobileNavOpen(true)} />
      <MobileNav isOpen={mobileNavOpen} onClose={() => setMobileNavOpen(false)} />
      <main>
        <Hero />
        <MarqueeBanner />
        <About />
        <Services />
        <TruckTypes />
        <AgreementPricing onOpenAgreement={() => setAgreementOpen(true)} />
        <HowItWorks />
        {children}
        <Testimonials />
        <Contact onToast={showToast} />
      </main>
      <Footer />
      <AgreementModal isOpen={agreementOpen} onClose={() => setAgreementOpen(false)} onToast={showToast} />
      <Toast message={toastMessage} show={toastShow} />
    </CmsProvider>
  );
}
