"use client";

import { Fragment } from "react";
import { useCms } from "@/components/CmsProvider";

export default function MarqueeBanner() {
  const { marqueeItems: items } = useCms();
  const renderGroup = (key: string) => (
    <div className="flex items-center gap-8 px-4">
      {items.map((item) => (
        <Fragment key={`${key}-${item}`}>
          <span>{item}</span>
          <span>★</span>
        </Fragment>
      ))}
    </div>
  );

  return (
    <div className="bg-accent text-[#0a0a0a] py-4 overflow-hidden border-y-2 border-accent-hover">
      <div className="scroll-banner flex whitespace-nowrap font-display text-2xl tracking-wide">
        {renderGroup("group-a")}
        {renderGroup("group-b")}
      </div>
    </div>
  );
}
