interface ToastProps {
  message: string;
  show: boolean;
}

export default function Toast({ message, show }: ToastProps) {
  return (
    <div className={`toast ${show ? "show" : ""}`}>
      <div className="flex items-center gap-3">
        <i className="fas fa-circle-check text-accent"></i>
        <span className="font-cond tracking-wide text-sm">{message}</span>
      </div>
    </div>
  );
}
