import type { AgreementDocumentContent } from "../lib/cms/types";

// A discussion checklist, not an approved contract or a representation of authority.
export const DEFAULT_AGREEMENT: AgreementDocumentContent = {
  version: "2026-10-review",
  title: "CARRIER AGREEMENT DISCUSSION",
  intro: "Use this checklist to request written terms for your operation. It is not an executed contract, a price quote or confirmation of operating authority. Confirm the contracting entities, service scope and responsibilities before signing an agreement.",
  sections: [
    { number: "01", title: "CARRIER INFORMATION", kind: "text", description: "Confirm the carrier's legal business name, contact details, applicable identifiers, equipment and operating requirements through the agreed secure onboarding process." },
    { number: "02", title: "SERVICE SCOPE", kind: "text", description: "List the dispatch, load coordination, paperwork and administrative tasks to be provided. Identify the contracting entity and the limits of its authorization. Any lease-on arrangement needs separate confirmation of the proposed operating carrier and written terms." },
    { number: "03", title: "FEES AND CHARGES", kind: "pricing", description: "Request an itemized written quote. Define the fee base, timing, third-party charges and treatment of cancellations, inactive periods and disputed invoices." },
    { number: "04", title: "LOAD APPROVAL AND COMMUNICATION", kind: "text", description: "Agree who approves loads, what rate and lane criteria apply, how changes are recorded, and which service hours and escalation contacts are available." },
    { number: "05", title: "PAYMENT AND DOCUMENTS", kind: "text", description: "Specify the document workflow, invoicing responsibilities and payment arrangements. Broker and factoring agreements govern their own approval, deductions and funding timing." },
    { number: "06", title: "INSURANCE AND OPERATING RESPONSIBILITIES", kind: "text", description: "Verify current carrier authority and applicable insurance requirements with official records and the responsible providers. Agree which party handles each task. Administrative or dispatch support does not replace the carrier's safety and operating obligations." },
    { number: "07", title: "EXIT AND RECORD RETURN", kind: "text", description: "Confirm notice periods, final reconciliation, document return and removal of account access. Obtain qualified review of the proposed agreement and applicable requirements before signing.", wide: true },
  ],
  carrierSignatureLabel: "CARRIER REPRESENTATIVE",
  carrierSignatureHelp: "Discussion notes · Name · Date",
  companySignatureLabel: "SERVICE REPRESENTATIVE",
  companySignatureHelp: "Discussion notes · Name · Date",
};
