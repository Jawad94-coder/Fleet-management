import { SERVICE_COPY } from "./service-copy.ts";
import type { PricingItem, TestimonialContent } from "../lib/cms/types";

const COMPANY = {
  name: "Fleet Management US",
  legalName: "Fleet Management US LLC",
  shortName: "FLEET MANAGEMENT",
  tagline: "US",
  estYear: 2014,
  dot: "3148297",
  mc: "098421",
  phone: "(929) 622 7250",
  phoneHref: "tel:+19296227250",
  email: "hadi@fleetmanagementus.com",
  emailHref: "mailto:hadi@fleetmanagementus.com",
  address: "1223 Desmond Ct Apt 3",
  city: "Brooklyn, NY 11235",
  website: "www.fleetmanagementus.com",
  hours: "Contact us to confirm dispatch coverage hours",
  copyright: "© 2024 FLEET MANAGEMENT US · ALL RIGHTS RESERVED",
  logo: "/images/logo.png",
  logoAlt: "Fleet Management US",
  seoTitle: "Truck Dispatch Services for US Carriers | Fleet Management US",
  seoDescription: "Truck dispatch support for US owner-operators and fleets. Explore load planning, broker communication, carrier onboarding and back-office services.",
};

const NAV_LINKS = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#services", label: "Services" },
  { href: "#trucks", label: "Truck Types" },
  { href: "#agreement", label: "Agreement" },
  { href: "/blogs", label: "Blog" },
  { href: "#contact", label: "Contact" },
];

const PRICING: PricingItem[] = [
  { name: "Dispatch support", value: "Quote", unit: "on request", description: "Confirm the fee structure, included tasks and any additional charges in writing.", highlight: true },
  { name: "Lease-on discussion", value: "Review", unit: "terms first", description: "Confirm availability, the proposed carrier, insurance responsibilities and itemized deductions.", highlight: false },
  { name: "Back-office support", value: "Quote", unit: "by scope", description: "Describe your paperwork and reporting needs to agree the administrative service scope.", highlight: false },
  { name: "Third-party charges", value: "Review", unit: "with provider", description: "Factoring, insurance and regulatory charges are governed by the responsible provider or agency.", highlight: true },
];

export interface FleetService {
  num: string;
  slug: string;
  icon: string;
  image?: string;
  imageAlt?: string;
  title: string;
  desc: string;
  ctaLabel?: string;
  ctaHref?: string;
  seoTitle?: string | null;
  seoDescription?: string | null;
  seoKeywords?: string[] | null;
  detail: {
    heading: string;
    intro: string;
    fee?: string;
    sections: Array<{
      title: string;
      intro?: string;
      items?: Array<{ name?: string; description: string }>;
      highlight?: boolean;
    }>;
    revenueTargets?: {
      note: string;
      targets: Array<{
        truckType: string;
        weeklyGrossMin: number;
        weeklyGrossMax: number;
        avgMilesPerWeek: string;
      }>;
      disclaimer: string;
    };
    closing?: string;
  };
}

const SERVICES: FleetService[] = [
  { num: "01", slug: "mc-leasing", icon: "fa-file-contract", title: "MC LEASING", ...SERVICE_COPY["mc-leasing"] },
  { num: "02", slug: "dispatch-services", icon: "fa-headset", title: "DISPATCH SERVICES", ...SERVICE_COPY["dispatch-services"] },
  { num: "03", slug: "load-assistance", icon: "fa-boxes-stacked", title: "LOAD ASSISTANCE", ...SERVICE_COPY["load-assistance"] },
  { num: "04", slug: "factoring-support", icon: "fa-money-bill-transfer", title: "FACTORING SUPPORT", ...SERVICE_COPY["factoring-support"] },
  { num: "05", slug: "insurance-support", icon: "fa-shield", title: "INSURANCE SUPPORT", ...SERVICE_COPY["insurance-support"] },
  { num: "06", slug: "back-office-support", icon: "fa-folder-open", title: "BACK OFFICE SUPPORT", ...SERVICE_COPY["back-office-support"] },
  { num: "07", slug: "carrier-setup-assistance", icon: "fa-clipboard-check", title: "CARRIER SETUP ASSISTANCE", ...SERVICE_COPY["carrier-setup-assistance"] },
];

export interface FleetTruckType {
  num: string;
  slug: string;
  icon: string;
  name: string;
  spec: string;
  image: string;
  imageAlt?: string;
  intro: string;
  bestFor: string;
  commonFreight: string[];
  equipmentNotes: string;
  weeklyGrossMin?: number;
  weeklyGrossMax?: number;
  avgMilesPerWeek?: string;
  seoTitle?: string | null;
  seoDescription?: string | null;
  seoKeywords?: string[] | null;
}

const TRUCK_TYPES: FleetTruckType[] = [
  {
    num: "01",
    slug: "semi-truck",
    icon: "fa-truck-front",
    name: "Semi Truck",
    spec: "CLASS 8",
    image: "/images/hero-fleet-highway.webp",
    intro: "Class 8 tractors give carriers the flexibility to move high-volume freight across regional and long-haul lanes with the trailer best suited to the load.",
    bestFor: "Long-haul and high-volume freight",
    commonFreight: ["General freight", "Retail and consumer goods", "Industrial materials", "Broker and dedicated-lane freight"],
    equipmentNotes: "Road-ready tractor, active insurance, current inspection, ELD, and a compatible 53-foot trailer or approved power-only setup.",
  },
  {
    num: "02",
    slug: "box-truck",
    icon: "fa-truck",
    name: "Box Truck",
    spec: "26FT STANDARD",
    image: "/images/truck-box.webp",
    intro: "Box trucks are a strong fit for regional freight, final-mile work, and time-sensitive loads that need enclosed protection without a full tractor-trailer.",
    bestFor: "Regional, expedited, and final-mile freight",
    commonFreight: ["Retail inventory", "Palletized goods", "Furniture and appliances", "Expedited shipments"],
    equipmentNotes: "A 26-foot box, working liftgate when required, securement equipment, pallet jack, current inspection, and accurate payload capacity.",
  },
  {
    num: "03",
    slug: "straight-truck",
    icon: "fa-truck-ramp-box",
    name: "Straight Truck",
    spec: "CLASS 5–7",
    image: "/images/truck-straight.webp",
    intro: "Straight trucks combine the cab and cargo body on one chassis, making them agile for regional distribution and deliveries where a semi cannot easily access the site.",
    bestFor: "Urban and regional distribution",
    commonFreight: ["Palletized cargo", "Commercial deliveries", "Event equipment", "Local distribution freight"],
    equipmentNotes: "Cargo dimensions and payload vary by unit, so every truck is reviewed individually before lanes and rates are planned.",
  },
  {
    num: "04",
    slug: "flatbed",
    icon: "fa-truck-pickup",
    name: "Flatbed",
    spec: "OPEN DECK",
    image: "/images/truck-flatbed.webp",
    intro: "Flatbeds handle freight that needs side, top, or crane loading. Our team screens dimensions, securement needs, permits, and weather exposure before booking.",
    bestFor: "Construction, machinery, and oversized freight",
    commonFreight: ["Steel and lumber", "Construction materials", "Machinery", "Crated industrial equipment"],
    equipmentNotes: "Chains, straps, binders, edge protectors, tarps, and required PPE must be in serviceable condition before dispatch.",
  },
  {
    num: "05",
    slug: "step-deck",
    icon: "fa-truck-monster",
    name: "Step Deck",
    spec: "DROP DECK",
    image: "/images/truck-step-deck.webp",
    intro: "Step decks provide extra vertical clearance for taller freight while keeping the loading flexibility of an open-deck trailer.",
    bestFor: "Tall machinery and specialized open-deck freight",
    commonFreight: ["Agricultural equipment", "Tall machinery", "Building materials", "Specialized industrial loads"],
    equipmentNotes: "Deck dimensions, ramp availability, securement inventory, and permit requirements are confirmed before each load is accepted.",
  },
  {
    num: "06",
    slug: "reefer",
    icon: "fa-snowflake",
    name: "Reefer",
    spec: "TEMP CONTROLLED",
    image: "/images/truck-reefer.webp",
    intro: "Refrigerated trailers protect temperature-sensitive freight with continuous monitoring and precise pickup, transit, and delivery requirements.",
    bestFor: "Food, produce, and temperature-sensitive freight",
    commonFreight: ["Fresh and frozen food", "Produce", "Beverages", "Temperature-controlled consumer goods"],
    equipmentNotes: "A serviced reefer unit, clean trailer, fuel for continuous operation, washout capability, and reliable temperature documentation are essential.",
  },
  {
    num: "07",
    slug: "dry-van",
    icon: "fa-truck-moving",
    name: "Dry Van",
    spec: "53FT ENCLOSED",
    image: "/images/truck-dry-van.webp",
    intro: "The 53-foot dry van is the most versatile enclosed trailer for moving non-temperature-controlled freight across nationwide lanes.",
    bestFor: "General freight and consistent long-haul lanes",
    commonFreight: ["Packaged food", "Retail goods", "Paper products", "Manufacturing supplies"],
    equipmentNotes: "Trailer floors, walls, roof, doors, seals, and load securement equipment must be clean, dry, and ready for inspection.",
  },
  {
    num: "08",
    slug: "hotshot",
    icon: "fa-truck-pickup",
    name: "Hotshot",
    spec: "GOOSENECK / 30–40FT",
    image: "/images/truck-hotshot.webp",
    intro: "Hotshot setups move smaller, urgent, and specialized loads quickly, often reaching shippers and receivers that do not need a full-size tractor-trailer.",
    bestFor: "Expedited and time-sensitive open-deck freight",
    commonFreight: ["Small machinery", "Construction materials", "Oilfield equipment", "Urgent partial loads"],
    equipmentNotes: "Truck and trailer ratings, CDL status, securement gear, dimensions, and operating radius are reviewed before dispatch planning.",
  },
  {
    num: "09",
    slug: "other",
    icon: "fa-truck-arrow-right",
    name: "Other",
    spec: "CUSTOM CONFIG",
    image: "/images/hero-fleet-terminal.webp",
    intro: "Specialized or uncommon equipment is evaluated case by case. We review your dimensions, capacity, operating area, and freight goals before recommending a lane strategy.",
    bestFor: "Specialized equipment and custom operations",
    commonFreight: ["Power-only opportunities", "Specialized trailers", "Local and regional equipment", "Custom freight requirements"],
    equipmentNotes: "Send the exact truck and trailer specifications, photos, payload limits, endorsements, and preferred operating lanes for review.",
  },
];

export const SITE_CONTENT = {
  company: COMPANY,
  navLinks: NAV_LINKS,
  sectionIds: NAV_LINKS.map((link) => link.href.slice(1)),
  socialLinks: [
    { label: "Facebook", icon: "fab fa-facebook-f", href: "https://www.facebook.com/profile.php?id=61594693000154" },
    { label: "LinkedIn", icon: "fab fa-linkedin-in", href: "#" },
    { label: "Instagram", icon: "fab fa-instagram", href: "https://www.instagram.com/fleetmangementus/" },
    { label: "YouTube", icon: "fab fa-youtube", href: "#" },
    { label: "X", icon: "fab fa-x-twitter", href: "https://x.com/fleetmngmentus" },
    { label: "Quora", icon: "fab fa-quora", href: "https://www.quora.com/profile/Fleet-Managementus" },
  ],
  truckTypes: TRUCK_TYPES,
  pricing: PRICING,

  services: SERVICES,

  steps: [
    { num: "01", label: "Step One", title: "SUBMIT TRUCK DETAILS", desc: "Tell us your truck type, base location, equipment specs, and preferred lanes via our contact form." },
    { num: "02", label: "Step Two", title: "COMPLETE CARRIER SETUP", desc: "We guide you through the carrier packet, insurance verification, and broker onboarding — no guesswork." },
    { num: "03", label: "Step Three", title: "REVIEW SERVICES", desc: "Pick the services that fit your operation — dispatch only, full back-office, MC lease, or everything bundled." },
    { num: "04", label: "Step Four", title: "SIGN THE AGREEMENT", desc: "Review the written service scope, fees, approval procedures and termination terms before signing." },
    { num: "05", label: "Step Five", title: "START HAULING", desc: "After onboarding, review suitable load opportunities and confirm approval before booking. Availability and start dates vary." },
  ],

  testimonials: [] as Array<Omit<TestimonialContent, "id" | "rating" | "featured">>,

  heroStats: [
    { value: "US", label: "Carrier Support", accent: true },
    { value: "LOADS", label: "Planning & Coordination" },
    { value: "LANES", label: "Equipment-Based Research" },
    { value: "RECORDS", label: "Back-Office Support", accent: true },
  ],

  heroTagline: "Your Partner for Reliable Trucking Operations",
  heroDescription:
    "Load planning, broker communication and paperwork support for US owner-operators and trucking fleets. Tell us your equipment, current location and preferred lanes so we can discuss the services your operation needs.",

  aboutImage: "/images/hero-fleet-terminal.webp",
  aboutYears: "",
  aboutDescription1:
    "Fleet Management US provides truck dispatch and fleet-support services for US owner-operators, independent carriers and small fleets. Our service options cover load coordination, carrier paperwork and administrative support.",
  aboutDescription2:
    "Start with your equipment, lanes and operating requirements. Agree which tasks we will handle, how load approvals and updates will work, and what the service costs before onboarding. Factoring, insurance and lease-on arrangements need their own written terms and provider review.",

  aboutFeatures: [
    { icon: "fa-shield-halved", title: "Defined Service Scope", description: "Discuss responsibilities and written terms before onboarding.", accent: true },
    { icon: "fa-route", title: "Equipment & Lane Fit", description: "Plan around your truck, availability and preferred routes." },
    { icon: "fa-headset", title: "Connected Paperwork", description: "Coordinate load information, delivery records and invoices." },
  ],

  marqueeItems: [
    "SEMI TRUCKS",
    "BOX TRUCKS",
    "FLATBEDS",
    "REEFERS",
    "STEP DECKS",
    "DRY VANS",
    "STRAIGHT TRUCKS",
  ],

  agreementSummary: [
    { num: "01", title: "Services Provided", description: "Dispatch, MC leasing, load assistance, factoring coordination, insurance support, back-office, and carrier setup — selectable a la carte or as a complete package." },
    { num: "02", title: "Carrier Responsibilities", description: "Maintain valid CDL, current medical card, clean DAC/PSP, road-ready equipment, and comply with all FMCSA/HOS regulations during operations." },
    { num: "03", title: "Fleet Management US Responsibilities", description: "Responsibilities, authorizations and administrative tasks must be listed in the written service agreement." },
    { num: "04", title: "Payment Terms", description: "Payment timing and deductions depend on complete paperwork and the applicable broker, factoring and service agreements." },
    { num: "05", title: "Termination Terms", description: "Confirm notice periods, outstanding settlements and document-return procedures in the agreement before onboarding." },
  ],

  contactCards: [
    { icon: "fa-envelope", label: "Email", href: COMPANY.emailHref, value: COMPANY.email },
    { icon: "fa-phone", label: "Phone", href: COMPANY.phoneHref, value: COMPANY.phone },
    { icon: "fa-globe", label: "Website", value: COMPANY.website },
    { icon: "fa-location-dot", label: "Office Address", href: "https://www.google.com/maps/search/?api=1&query=1223+Desmond+Ct+Apt+3%2C+Brooklyn%2C+NY+11235", value: `${COMPANY.address}\n${COMPANY.city}` },
  ],

  contactDescription:
    "Share your equipment, current ZIP code, preferred lanes and service needs. Use the carrier enquiry form to start a discussion about scope, fees and availability.",
  dispatchResponseTime: "",
};

export type SiteContent = typeof SITE_CONTENT;
