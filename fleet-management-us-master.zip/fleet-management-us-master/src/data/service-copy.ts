import type { FleetService } from "./content";

// Editorial copy used by the seed and the guarded CMS content update.
export const SERVICE_COPY: Record<string, Pick<FleetService, "desc" | "detail" | "seoTitle" | "seoDescription">> = {
  "mc-leasing": {
    seoTitle: "MC Lease-On Support for Owner-Operators",
    seoDescription: "Understand MC lease-on arrangements, equipment review, insurance questions and settlement terms before discussing carrier options with Fleet Management US.",
    desc: "Explore carrier lease-on arrangements, equipment requirements and written settlement terms before deciding how to operate your truck.",
    detail: {
      heading: "MC Lease-On Support for Owner-Operators",
      intro: "A carrier lease-on arrangement places equipment into an authorized carrier's operation under a written agreement. It is different from purchasing or renting an MC number. Discuss the proposed carrier, responsibilities and availability before making a commitment.",
      sections: [
        { title: "Who should discuss lease-on options?", intro: "An owner-operator considering another carrier's operating framework should first compare the full arrangement with operating independently. Equipment condition, driver qualifications, insurance acceptance and the carrier's own criteria affect eligibility." },
        { title: "What should the written agreement explain?", items: [
          { name: "Operating carrier", description: "Identify the legal entity responsible for transportation and verify its current authority in official FMCSA records." },
          { name: "Compensation", description: "Request an itemized explanation of deductions, insurance charges, deposits, payment conditions and termination terms." },
          { name: "Equipment and records", description: "Clarify who manages permits, registration, maintenance records and safety responsibilities for your specific arrangement." },
        ] },
        { title: "Does lease-on change a truck's VIN?", intro: "No. A vehicle identification number identifies the vehicle. Discuss the actual insurance, equipment scheduling and registration requirements with the proposed carrier and insurance provider; these are separate from the vehicle's identity." },
        { title: "Is operating authority confirmed here?", intro: "No specific operating authority, insurance coverage or lease availability is represented on this page. Ask for the proposed carrier's legal name, current registration and written terms, and have the arrangement reviewed before dispatch begins.", highlight: true },
        { title: "How much does a lease-on arrangement cost?", intro: "Costs depend on the agreement and may include a share of revenue, insurance and other deductions. Request a written breakdown and a sample settlement. Dispatch support and lease-on arrangements should be priced and assessed separately." },
        { title: "What information starts the discussion?", intro: "Share your equipment type, operating experience, preferred lanes and current authority status through the enquiry form. Confirm availability and the scope of assistance before submitting sensitive driver or insurance documents." },
      ],
      closing: "Discuss your operating model before selecting a service. Dispatch assistance alone does not confer operating authority or replace a carrier's safety responsibilities.",
    },
  },
  "dispatch-services": {
    seoTitle: "Independent Truck Dispatch Services for Owner-Operators",
    seoDescription: "Explore independent truck dispatch services for US owner-operators: load research, broker communication, rate negotiation and carrier-approved load coordination.",
    desc: "Load research, broker communication and dispatch coordination built around your equipment, preferred lanes and operating requirements.",
    detail: {
      heading: "Independent Truck Dispatch Services for US Owner-Operators",
      intro: "Truck dispatching helps a carrier research loads, communicate with brokers and organize pickups and deliveries. Fleet Management US offers dispatch support for owner-operators and fleets, with load planning based on the truck's location, equipment and carrier preferences.",
      sections: [
        { title: "How does dispatch support work?", items: [
          { name: "Carrier assessment", description: "Share your truck type, current ZIP code, preferred lanes, availability and service needs." },
          { name: "Onboarding", description: "Agree the service scope, fees, communication arrangements and the dispatcher's authorization before load work begins." },
          { name: "Load research", description: "Compare equipment fit, loaded and empty miles, appointments and the destination market." },
          { name: "Broker communication", description: "Clarify the load details and discuss rates and accessorial terms on the carrier's behalf, within the agreed authorization." },
          { name: "Dispatch coordination", description: "Confirm carrier approval and coordinate load instructions, status updates and delivery paperwork." },
        ] },
        { title: "Who is this service for?", intro: "Owner-operators, independent carriers and small fleets can discuss dispatch assistance. Equipment options include dry van, reefer, box truck, flatbed and hotshot. Load suitability depends on capacity, location, operating status and the requirements of each broker." },
        { title: "How are rates negotiated?", intro: "A dispatcher can discuss the offered rate using lane conditions, pickup distance, equipment needs and appointment timing. The carrier's operating costs and approval criteria guide the decision. Negotiation does not guarantee a particular rate, load volume or weekly revenue." },
        { title: "How much do truck dispatch services cost?", intro: "Dispatch agreements can use a percentage of an agreed revenue base, a flat weekly fee or a per-load fee. Request a written quote stating which services and deductions are included, how cancellations are handled and when the fee is earned. Current business fees must be confirmed directly." },
        { title: "What documents does a dispatcher need?", intro: "A typical onboarding review may include carrier identification, a W-9, insurance information, equipment details and a signed dispatch agreement. Brokers may request additional carrier setup documents. Confirm the secure submission method and exact requirements before sending documents." },
        { title: "Is a dispatcher the same as a freight broker?", intro: "No. Dispatch assistance and freight brokerage have different roles. The actual activities and business relationships determine whether broker authority is required; a dispatch label alone does not settle that question. Review the proposed arrangement against current FMCSA guidance." },
      ],
      closing: "Tell us what you drive, where you are available and what support you need. Confirm coverage hours, approval procedures and fees in writing before onboarding.",
    },
  },
  "load-assistance": {
    seoTitle: "Truck Load Booking Assistance for US Carriers",
    seoDescription: "Review truck load booking assistance covering equipment fit, total-mile economics, pickup schedules, broker questions and return-load planning for US carriers.",
    desc: "Compare load opportunities against your truck's capacity, total trip miles, appointment schedule and next destination before booking.",
    detail: {
      heading: "Truck Load Booking Assistance for US Carriers",
      intro: "Load booking assistance helps a carrier evaluate freight opportunities before committing a truck. Fleet Management US supports load research and coordination so the decision includes equipment fit, timing and the complete trip rather than the posted rate alone.",
      sections: [
        { title: "How are load opportunities compared?", items: [
          { name: "Equipment fit", description: "Review cargo weight, dimensions, loading method and any securement or temperature requirements." },
          { name: "Total trip economics", description: "Include travel to pickup and likely repositioning after delivery, along with fuel, tolls and expected waiting time." },
          { name: "Schedule", description: "Check appointment windows against actual driver availability and realistic travel time." },
          { name: "Destination", description: "Consider compatible outbound freight and home-time requirements before accepting a one-way move." },
        ] },
        { title: "How do dispatchers find loads?", intro: "Load research can use authorized load-board access and broker communications. Available freight changes by equipment, lane and day. Ask which sources will be used for your operation and who is responsible for any subscription costs." },
        { title: "Can load planning reduce deadhead miles?", intro: "Planning can help avoid unnecessary empty travel by comparing pickup distances and return options early. It cannot eliminate every empty mile. A closer load may still be a poor choice if delays, low pay or the destination make the total trip uneconomic." },
        { title: "What should be confirmed with a broker?", intro: "Confirm the facility addresses, appointment type, commodity, weight, equipment needs, tracking requirements, rate and accessorial process. Check the written rate confirmation against what was agreed before the carrier accepts the move." },
        { title: "Are dedicated lanes or loads guaranteed?", intro: "No. Spot loads, return opportunities and recurring lanes depend on actual availability and carrier acceptance. Share your preferred routes, but assess each opportunity using the current load details rather than a promised weekly total." },
        { title: "What do I need to request load assistance?", intro: "Provide your equipment specifications, current location, earliest availability and lane preferences. Explain any liftgate, temperature-control, tarping or payload restrictions so unsuitable loads can be excluded before booking discussions." },
      ],
    },
  },
  "factoring-support": {
    seoTitle: "Freight Factoring Paperwork Support for Carriers",
    seoDescription: "Get freight factoring paperwork support for carrier enrollment, invoices, proof of delivery and factor communication. Funding decisions remain with your provider.",
    desc: "Organize enrollment paperwork, invoices and delivery records, and coordinate questions with the factoring provider you use.",
    detail: {
      heading: "Freight Factoring Paperwork Support",
      intro: "Factoring support helps a carrier prepare and submit documents to a factoring provider. Fleet Management US assists with setup paperwork, invoice submission and related communication; the provider determines approval, eligibility, fees and funding timing.",
      sections: [
        { title: "What paperwork can we help organize?", items: [
          { name: "Enrollment", description: "Coordinate the carrier and business information requested by the provider." },
          { name: "Load records", description: "Keep the invoice, rate confirmation, bill of lading and signed proof of delivery associated with the correct load." },
          { name: "Supporting charges", description: "Collect receipts and approval records for any accessorial charges included on an invoice." },
          { name: "Follow-up", description: "Help communicate missing-document questions and reconcile the provider's settlement information." },
        ] },
        { title: "Does support guarantee same-day funding?", intro: "No. Funding depends on the provider's approval, submission cutoffs, debtor eligibility, document completeness and agreement terms. Confirm expected timing with the factor rather than treating a dispatch service as the lender." },
        { title: "How should I compare factoring offers?", intro: "Compare the fee base, recourse terms, reserves, minimum commitments, additional charges and termination conditions. A headline fee alone does not show the full cost. Request a sample settlement and ask how disputes and unpaid invoices are handled." },
        { title: "Can I use my existing factoring company?", intro: "Tell the team which provider you use and whether a notice of assignment applies. Confirm the workflow before submitting invoices so payment instructions are consistent and the same receivable is not submitted twice." },
        { title: "Who is eligible for factoring?", intro: "Eligibility is set by the factoring provider and may depend on the carrier, customer credit and individual invoice. Administrative support does not constitute credit approval or a commitment to fund." },
      ],
    },
  },
  "insurance-support": {
    seoTitle: "Commercial Trucking Insurance Coordination Support",
    seoDescription: "Explore trucking insurance coordination support for coverage questions, certificates and renewal records. Policy terms and binding decisions require your provider.",
    desc: "Coordinate trucking insurance information, coverage questions and renewal documents with the insurance professionals responsible for your policy.",
    detail: {
      heading: "Commercial Trucking Insurance Coordination Support",
      intro: "Insurance support helps organize the information a trucking insurance professional needs to discuss your operation. Fleet Management US assists with coordination and documentation; coverage, exclusions, pricing and binding must be confirmed by the responsible insurance provider.",
      sections: [
        { title: "What information starts an insurance discussion?", intro: "Prepare your equipment schedule, operating radius, commodities, driver information and current policy details. Requirements depend on the insurer and operation. Use the provider's approved channel for sensitive records." },
        { title: "Which coverage questions should a carrier ask?", items: [
          { name: "Liability", description: "Ask which operations and vehicles the policy covers and which limits your contracts require." },
          { name: "Cargo", description: "Discuss the commodities, limits, deductibles and exclusions relevant to the freight you plan to haul." },
          { name: "Physical damage", description: "Confirm how truck and trailer damage is covered and valued." },
          { name: "Non-trucking use", description: "Ask how coverage applies outside dispatched work. Bobtail and non-trucking liability are not interchangeable descriptions of every policy." },
        ] },
        { title: "Does a certificate prove every load is covered?", intro: "A certificate summarizes insurance information; it does not replace the policy. Confirm the actual terms and any required endorsements with the insurer or licensed professional before accepting a load with special requirements." },
        { title: "Can insurance support guarantee compliance?", intro: "No. Required coverage depends on the carrier's operation and applicable rules and contracts. Confirm current requirements through official sources and qualified insurance advice. Administrative coordination does not independently certify FMCSA compliance." },
        { title: "How do renewal reminders help?", intro: "Keeping renewal dates and current certificates together makes missing information easier to identify. The carrier remains responsible for maintaining required coverage, and the insurer controls whether a policy or change is bound." },
      ],
    },
  },
  "back-office-support": {
    seoTitle: "Trucking Back-Office Support for Small Fleets",
    seoDescription: "Explore trucking back-office support for load records, invoice paperwork, settlement organization and renewal tracking for owner-operators and small fleets.",
    desc: "Organize load records, invoices, settlements and renewal information so dispatch and administrative work stay connected.",
    detail: {
      heading: "Trucking Back-Office Support for Small Fleets",
      intro: "Trucking back-office support organizes the paperwork behind each load and the recurring records behind an operation. Fleet Management US offers administrative assistance for owner-operators and fleets that need a clearer document and follow-up workflow.",
      sections: [
        { title: "What can the back-office workflow include?", items: [
          { name: "Load files", description: "Associate rate confirmations, delivery documents, receipts and invoices with the right truck and load." },
          { name: "Settlements", description: "Organize revenue, deductions and payment records so discrepancies can be raised with the responsible party." },
          { name: "Renewal tracking", description: "Keep document dates visible and coordinate requests for updated records." },
          { name: "Reporting preparation", description: "Discuss mileage, fuel and permit records needed by the people responsible for filings." },
        ] },
        { title: "Who benefits from administrative support?", intro: "An owner-operator handling paperwork after driving, or a small fleet with scattered email and text records, can benefit from an agreed filing and follow-up process. Start by defining which tasks stay with the carrier and which are assigned to the support team." },
        { title: "Does this replace a compliance or tax professional?", intro: "No. Administrative support is separate from legal, tax, safety and regulatory advice. Confirm whether a requested filing is included and who reviews and submits it. The carrier remains accountable for its obligations." },
        { title: "How do dispatch and back-office teams connect?", intro: "Dispatch instructions establish the load details; delivery records support invoicing. A shared load reference helps the team identify missing paperwork before it causes a billing question. Set a clear handoff after delivery and an escalation contact for discrepancies." },
        { title: "How is service scope agreed?", intro: "List your truck count, document systems, outstanding paperwork and recurring tasks in the enquiry. Request a written scope with access permissions, fees and record-return procedures before sharing account access." },
      ],
    },
  },
  "carrier-setup-assistance": {
    seoTitle: "Carrier Onboarding and Setup Assistance",
    seoDescription: "Review carrier onboarding assistance for business information, broker packets, insurance documents and registration questions before starting US freight operations.",
    desc: "Prepare carrier information and broker packets, identify missing onboarding documents and clarify registration questions before booking freight.",
    detail: {
      heading: "Carrier Onboarding and Setup Assistance",
      intro: "Carrier setup assistance organizes the business information and documents needed for onboarding. Fleet Management US helps carriers coordinate paperwork and broker packets. Registration approval, insurance acceptance and a broker's carrier requirements remain separate decisions.",
      sections: [
        { title: "What information is commonly requested?", items: [
          { name: "Business identity", description: "Legal business name, contact information, tax documentation and applicable carrier identifiers." },
          { name: "Insurance documents", description: "Current evidence of coverage in the form requested by the broker or onboarding platform." },
          { name: "Equipment", description: "Truck and trailer type, dimensions, capacity and any special operating restrictions." },
          { name: "Payment instructions", description: "Consistent remittance details and factoring notices where applicable, submitted through an approved channel." },
        ] },
        { title: "Does a USDOT number alone authorize every load?", intro: "No. Registration and operating authority are different concepts, and the requirements depend on the operation. Check current FMCSA registration guidance and confirm your status before hauling regulated freight." },
        { title: "Are BOC-3, UCR and SCAC always the same requirement?", intro: "No. They serve different purposes and their applicability depends on the operation. Ask which filings or identifiers apply to your business rather than purchasing a standard bundle without a review." },
        { title: "Can a newly registered carrier book immediately?", intro: "Not necessarily. Authority status, insurance, broker onboarding criteria and equipment all affect acceptance. Setup assistance cannot promise expedited agency approval, a first-load date or acceptance by every broker." },
        { title: "How should I prepare for onboarding?", intro: "Check that names and contact details match across your records. Identify expired documents and confirm a secure submission method. Agree the dispatch scope, pricing and approval process before allowing anyone to communicate on your behalf." },
      ],
    },
  },
};
