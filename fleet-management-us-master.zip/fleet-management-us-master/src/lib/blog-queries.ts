import "server-only";

import { cache } from "react";
import { and, desc, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { blogPosts } from "@/db/schema";

export const getPublishedBlogs = cache(async () => getDb().select({
  id: blogPosts.id,
  title: blogPosts.title,
  slug: blogPosts.slug,
  excerpt: blogPosts.excerpt,
  featuredImage: blogPosts.featuredImage,
  featuredImageAlt: blogPosts.featuredImageAlt,
  author: blogPosts.author,
  category: blogPosts.category,
  publishedAt: blogPosts.publishedAt,
  readingTime: blogPosts.readingTime,
  createdAt: blogPosts.createdAt,
  updatedAt: blogPosts.updatedAt,
}).from(blogPosts)
  .where(eq(blogPosts.status, "published"))
  .orderBy(desc(blogPosts.publishedAt), desc(blogPosts.createdAt)));

export const getPublishedBlogBySlug = cache(async (slug: string) => {
  const [post] = await getDb().select().from(blogPosts)
    .where(and(eq(blogPosts.slug, slug), eq(blogPosts.status, "published"))).limit(1);
  return post ?? null;
});
