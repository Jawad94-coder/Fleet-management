import type { Metadata } from "next";

// Keep production canonicals independent of preview/deployment host variables.
export const siteUrl = "https://www.fleetmanagementus.com";

export const absoluteUrl = (path: string) => new URL(path, siteUrl).href;

export function truncateDescription(value: string) {
  const description = value.replace(/\s+/g, " ").trim();
  return description.length <= 155 ? description : `${description.slice(0, 152).trimEnd()}...`;
}

export const organizationId = absoluteUrl("/#organization");

export function pageMetadata(title: string, description: string, path: string, image = "/images/hero-fleet-highway.webp", imageAlt = "Commercial truck on a highway"): Metadata {
  const url = absoluteUrl(path);
  const images = [{ url: absoluteUrl(image), alt: imageAlt }];
  return {
    title, description,
    alternates: { canonical: url },
    openGraph: { type: "website", title, description, url, siteName: "Fleet Management US", locale: "en_US", images },
    twitter: { card: "summary_large_image", title, description, images },
  };
}

export function breadcrumbJsonLd(items: Array<{ name: string; item: string }>) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map(({ name, item }, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name,
      item,
    })),
  };
}
