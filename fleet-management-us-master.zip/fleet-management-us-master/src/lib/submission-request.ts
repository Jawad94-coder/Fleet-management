export async function readSubmission(request: Request): Promise<unknown> {
  const origin=request.headers.get("origin");
  if(origin && origin!==new URL(request.url).origin)throw new Error("Invalid submission origin.");
  if (request.headers.get("content-type")?.split(";")[0].trim().toLowerCase() !== "application/json") throw new Error("Invalid submission.");
  if (Number(request.headers.get("content-length") ?? 0) > 16000) throw new Error("Submission is too large.");
  const reader = request.body?.getReader();
  if (!reader) throw new Error("Invalid submission.");
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > 16000) { await reader.cancel(); throw new Error("Submission is too large."); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  return JSON.parse(new TextDecoder().decode(bytes));
}
