const cloudinaryPrefix = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME
  ? `https://res.cloudinary.com/${process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME}/image/upload/`
  : null;

export function bypassImageOptimization(src: string) {
  if (src.startsWith("/")) return false;
  return !cloudinaryPrefix || !src.startsWith(cloudinaryPrefix);
}
