import "server-only";

import { and, eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { cache } from "react";
import { getDb } from "@/db";
import { adminUsers } from "@/db/schema";
import { createSupabaseServerClient, supabaseAuthIsConfigured } from "@/lib/supabase/server";

export interface AdminIdentity {
  id: string;
  email: string;
  role: string;
}

export const getCurrentAdmin = cache(async (): Promise<AdminIdentity | null> => {
  if (!supabaseAuthIsConfigured()) return null;

  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.auth.getClaims();
  const userId = data?.claims?.sub;
  if (error || typeof userId !== "string") return null;

  const [admin] = await getDb()
    .select({ id: adminUsers.userId, email: adminUsers.email, role: adminUsers.role })
    .from(adminUsers)
    .where(and(eq(adminUsers.userId, userId), eq(adminUsers.active, true)))
    .limit(1);

  return admin ?? null;
});

export async function isAdminAuthenticated() {
  return Boolean(await getCurrentAdmin());
}

export async function requireAdmin() {
  const admin = await getCurrentAdmin();
  if (!admin) redirect("/admin/login");
  return admin;
}
