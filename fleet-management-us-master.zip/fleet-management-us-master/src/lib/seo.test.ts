import test from "node:test";
import assert from "node:assert/strict";
import { absoluteUrl, breadcrumbJsonLd, pageMetadata, siteUrl, truncateDescription } from "./seo.ts";

test("canonicals and social URLs use the preferred production origin", () => {
  assert.equal(siteUrl, "https://www.fleetmanagementus.com");
  const meta = pageMetadata("Dispatch support", "Service-specific description", "/services/dispatch-services");
  assert.equal(meta.alternates?.canonical, `${siteUrl}/services/dispatch-services`);
  assert.equal(meta.openGraph?.url, `${siteUrl}/services/dispatch-services`);
  assert.equal(meta.twitter?.title, "Dispatch support");
  assert.equal(absoluteUrl("/#organization"), `${siteUrl}/#organization`);
});

test("descriptions normalize whitespace and breadcrumb positions are contiguous", () => {
  assert.equal(truncateDescription("  Truck\n dispatch   support "), "Truck dispatch support");
  assert.equal(truncateDescription("a".repeat(200)).length, 155);
  const data = breadcrumbJsonLd([{ name: "Home", item: absoluteUrl("/") }, { name: "Blogs", item: absoluteUrl("/blogs") }]);
  assert.deepEqual(data.itemListElement.map(item => item.position), [1, 2]);
});
