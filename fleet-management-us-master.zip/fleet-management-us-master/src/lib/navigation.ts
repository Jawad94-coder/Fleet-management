export function navHref(href: string, fromSubpage = false) {
  return fromSubpage && href.startsWith("#") ? `/${href}` : href;
}

export function subpageActiveNavHref(pathname: string) {
  if (pathname === "/blogs" || pathname.startsWith("/blogs/")) return "/blogs";
  if (pathname.startsWith("/services/")) return "#services";
  if (pathname.startsWith("/truck-types/")) return "#trucks";
  return "";
}
