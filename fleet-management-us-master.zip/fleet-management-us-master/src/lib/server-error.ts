import "server-only";

export function logServerError(context:string,error:unknown){const candidate=error as {name?:unknown;code?:unknown};console.error(context,{name:typeof candidate?.name==="string"?candidate.name:"Error",code:typeof candidate?.code==="string"?candidate.code:"unknown"});}
