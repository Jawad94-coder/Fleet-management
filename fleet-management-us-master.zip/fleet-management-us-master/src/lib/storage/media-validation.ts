import { ValidationError } from "../cms/admin-validation.ts";

const signatures = new Map([["image/jpeg",[0xff,0xd8,0xff]],["image/png",[0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]],["image/webp",[0x52,0x49,0x46,0x46]],["image/avif",[0x66,0x74,0x79,0x70]]]);

export async function validateMediaFile(file: File) {
  if(file.size===0) throw new ValidationError("Choose an image to upload.");
  if(file.size>5*1024*1024) throw new ValidationError("Images must be 5 MB or smaller.");
  const signature=signatures.get(file.type); if(!signature) throw new ValidationError("Only JPEG, PNG, WebP, and AVIF images are allowed.");
  const extension=file.name.split(".").pop()?.toLowerCase();
  const expected=file.type==="image/jpeg"?["jpg","jpeg"]:[file.type.split("/")[1]];
  if(!extension||!expected.includes(extension)) throw new ValidationError("The file extension does not match its image type.");
  const bytes=new Uint8Array(await file.arrayBuffer());
  const offset=file.type==="image/avif"?4:0;
  const matches=signature.every((byte,index)=>bytes[index+offset]===byte) && (file.type!=="image/webp"||String.fromCharCode(...bytes.slice(8,12))==="WEBP") && (file.type!=="image/avif"||["avif","avis"].includes(String.fromCharCode(...bytes.slice(8,12))));
  if(!matches) throw new ValidationError("The file content does not match its image type.");
  return bytes;
}
