import "server-only";

import { Readable } from "node:stream";
import type { UploadApiResponse } from "cloudinary";
import { getCloudinary } from "../cloudinary.ts";

export { validateMediaFile } from "./media-validation.ts";

export const mediaFolders=["hero","about","services","trucks","blogs","testimonials","company"] as const;
export type MediaFolder=(typeof mediaFolders)[number];

export async function uploadMediaObject(file:File,bytes:Uint8Array,folder:MediaFolder){
  const result=await new Promise<UploadApiResponse>((resolve,reject)=>{
    const upload=getCloudinary().uploader.upload_stream({folder:`fleet-management-us/${folder}`,resource_type:"image",overwrite:false,unique_filename:true},(error,response)=>error||!response?reject(error??new Error("Cloudinary upload failed.")):resolve(response));
    Readable.from(Buffer.from(bytes)).pipe(upload);
  });
  if(!result.secure_url||!result.public_id)throw new Error("Cloudinary did not return image metadata.");
  return{publicUrl:result.secure_url,publicId:result.public_id,sizeBytes:result.bytes||file.size,width:result.width,height:result.height};
}

export async function removeMediaObject(publicId:string){
  const result=await getCloudinary().uploader.destroy(publicId,{resource_type:"image",invalidate:true});
  if(result.result!=="ok"&&result.result!=="not found")throw new Error("Cloudinary image deletion failed.");
}
