import assert from "node:assert/strict";
import test from "node:test";
import { validateCarrierApplication } from "./carrier-application.ts";

test("carrier applications validate and normalize trusted fields", () => {
  const result = validateCarrierApplication({
    fullName: "  Jane Driver  ",
    phone: "(312) 555-0100",
    email: " JANE@EXAMPLE.COM ",
    truckType: "Dry Van",
    zip: "60607",
    smsOptIn: true,
  }, new Set(["Dry Van"]));

  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.equal(result.data.fullName, "Jane Driver");
  assert.equal(result.data.email, "jane@example.com");
  assert.equal(result.data.smsOptIn, true);
  assert.ok(result.data.smsConsentAt instanceof Date);
});

test("carrier applications reject invalid equipment and ZIP values", () => {
  const result = validateCarrierApplication({
    fullName: "Jane Driver",
    phone: "(312) 555-0100",
    email: "jane@example.com",
    truckType: "Spaceship",
    zip: "not-a-zip",
  }, new Set(["Dry Van"]));

  assert.equal(result.ok, false);
});
