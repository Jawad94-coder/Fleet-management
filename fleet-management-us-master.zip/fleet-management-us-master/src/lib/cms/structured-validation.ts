import type { FleetService } from "../../data/content";
import type { AgreementSectionContent } from "./types";
import { ValidationError } from "./admin-validation.ts";

function object(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new ValidationError("Expected a structured object.");
  return value as Record<string, unknown>;
}
function text(value: unknown, max = 10000): string {
  if (typeof value !== "string" || !value.trim() || value.length > max) throw new ValidationError("Structured text is missing or too long.");
  return value;
}
function optionalText(value: unknown) {
  if(value === undefined)return undefined;
  if(typeof value !== "string" || value.length > 10000)throw new ValidationError("Optional text is invalid or too long.");
  return value;
}
function list(value: unknown, max = 50): unknown[] {
  if (!Array.isArray(value) || value.length > max) throw new ValidationError(`Expected a list with at most ${max} items.`);
  return value;
}
function optionalBoolean(value: unknown) {
  if (value !== undefined && typeof value !== "boolean") throw new ValidationError("Invalid checkbox value.");
  return value;
}
function items(value: unknown) {
  return value === undefined ? undefined : list(value).map(item => {
    const row = object(item);
    return {name: optionalText(row.name), description: text(row.description)};
  });
}
function amount(value: unknown): number {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0 || value > 2147483647) throw new ValidationError("Revenue must be a non-negative whole number.");
  return value;
}

export function validateServiceDetail(value: unknown): FleetService["detail"] {
  const row = object(value);
  const detail: FleetService["detail"] = {
    heading: text(row.heading, 240), intro: text(row.intro), fee: optionalText(row.fee), closing: optionalText(row.closing),
    sections: list(row.sections).map(value => {
      const section = object(value);
      return {title:text(section.title, 240), intro:optionalText(section.intro), items:items(section.items), highlight:optionalBoolean(section.highlight)};
    }),
  };
  if (row.revenueTargets !== undefined) {
    const revenue = object(row.revenueTargets);
    detail.revenueTargets = {note:text(revenue.note), disclaimer:text(revenue.disclaimer), targets:list(revenue.targets).map(value => {
      const target = object(value);
      const weeklyGrossMin = amount(target.weeklyGrossMin), weeklyGrossMax = amount(target.weeklyGrossMax);
      if (weeklyGrossMin > weeklyGrossMax) throw new ValidationError("Revenue minimum cannot exceed maximum.");
      return {truckType:text(target.truckType, 200), weeklyGrossMin, weeklyGrossMax, avgMilesPerWeek:text(target.avgMilesPerWeek, 120)};
    })};
  }
  return detail;
}

export function validateAgreementSections(value: unknown): AgreementSectionContent[] {
  const rows = list(value);
  if (!rows.length) throw new ValidationError("At least one agreement section is required.");
  const numbers = new Set<string>();
  return rows.map(value => {
    const row = object(value);
    const kind = row.kind;
    if (kind !== "text" && kind !== "list" && kind !== "carrier" && kind !== "company" && kind !== "pricing") throw new ValidationError("Invalid agreement section kind.");
    const number = text(row.number, 20);
    if (numbers.has(number)) throw new ValidationError("Agreement section numbers must be unique.");
    numbers.add(number);
    return {number, title:text(row.title, 240), kind, description:optionalText(row.description), items:items(row.items), wide:optionalBoolean(row.wide)};
  });
}
