import "server-only";
import { sql } from "drizzle-orm";
import type { getDb } from "@/db";

type Transaction = Parameters<Parameters<ReturnType<typeof getDb>["transaction"]>[0]>[0];

export async function lockContent(tx: Transaction) {
  // ponytail: one CMS writer lock; use normalized media references if editorial throughput grows.
  await tx.execute(sql`SELECT pg_advisory_xact_lock(726401)`);
}

export async function mediaReferences(tx: Transaction, path: string) {
  // Include drafts and archived records so restoring content cannot restore a broken image.
  const result = await tx.execute(sql`
    SELECT 'Hero' AS section FROM cms_hero_content WHERE images @> jsonb_build_array(${path}::text)
    UNION SELECT 'Company settings' FROM cms_site_settings WHERE logo = ${path}
    UNION SELECT 'Navigation' FROM cms_navigation_links WHERE href = ${path}
    UNION SELECT 'Social links' FROM cms_social_links WHERE href = ${path}
    UNION SELECT 'Contact cards' FROM cms_contact_cards WHERE href = ${path}
    UNION SELECT 'About' FROM cms_about_content WHERE image = ${path}
    UNION SELECT 'Truck Types' FROM cms_truck_types WHERE image = ${path}
    UNION SELECT 'Services' FROM cms_services WHERE image = ${path} OR strpos(detail::text, ${JSON.stringify(path).slice(1,-1)}) > 0
    UNION SELECT 'Reviews' FROM cms_testimonials WHERE avatar_path = ${path}
    UNION SELECT 'Blogs' FROM cms_blog_posts WHERE featured_image = ${path} OR strpos(body, ${path}) > 0
    UNION SELECT 'Section copy' FROM cms_section_copy WHERE strpos(content::text, ${JSON.stringify(path).slice(1,-1)}) > 0
    UNION SELECT 'Agreement' FROM cms_agreement_document WHERE strpos(sections::text, ${JSON.stringify(path).slice(1,-1)}) > 0
    UNION SELECT 'Agreement history' FROM cms_agreement_revisions WHERE strpos(snapshot::text, ${JSON.stringify(path).slice(1,-1)}) > 0
  `);
  return result.rows.map(row => String(row.section));
}
