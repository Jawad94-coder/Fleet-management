import type { FleetService, FleetTruckType } from "@/data/content";

export interface CompanyContent { name: string; legalName: string; shortName: string; tagline: string; estYear: number; dot: string; mc: string; phone: string; phoneHref: string; email: string; emailHref: string; address: string; city: string; website: string; hours: string; copyright: string; logo: string; logoAlt: string; seoTitle: string; seoDescription: string }
export interface NavigationLink { href: string; label: string }
export interface SocialLink { label: string; icon: string; href: string }
export interface HeroStatistic { value: string; label: string; accent?: boolean }
export interface AboutFeature { icon: string; title: string; description: string; accent?: boolean }
export interface PricingItem {
  name: string;
  value: string;
  unit: string;
  agreementSuffix?: string;
  description: string;
  highlight: boolean;
}
export interface OnboardingStep { num: string; label: string; title: string; desc: string }
export interface AgreementItem { num: string; title: string; description: string }
export interface ContactCard { icon: string; label: string; href?: string; value: string }
export interface AgreementSectionContent {
  number: string;
  title: string;
  kind: "text" | "list" | "carrier" | "company" | "pricing";
  description?: string;
  items?: Array<{ name?: string; description: string }>;
  wide?: boolean;
}
export interface AgreementDocumentContent {
  version: string;
  title: string;
  intro: string;
  sections: AgreementSectionContent[];
  carrierSignatureLabel: string;
  carrierSignatureHelp: string;
  companySignatureLabel: string;
  companySignatureHelp: string;
}
export interface TestimonialContent {
  id: number;
  quote: string;
  name: string;
  company?: string;
  role: string;
  equipment?: string;
  location?: string;
  tenure?: string;
  initials: string;
  avatarPath?: string;
  avatarAlt?: string;
  rating: number;
  featured: boolean;
}
export interface SectionCopyContent {
  servicesLabel: string; servicesHeading: string; servicesHeadingAccent: string; servicesDescription: string; servicesLinkLabel: string;
  trucksLabel: string; trucksHeading: string; trucksHeadingAccent: string; trucksDescription: string; trucksCustomNote: string; trucksLinkLabel: string;
  howLabel: string; howHeading: string; howHeadingAccent: string; howCtaLabel: string; howCtaHeading: string; howCtaAccent: string; howCtaDescription: string; howCtaButton: string;
  agreementLabel: string; agreementHeading: string; agreementHeadingAccent: string; agreementDescription: string; agreementSummaryTitle: string; pricingTitle: string; pricingNote: string; agreementButtonLabel: string; quoteButtonLabel: string;
  heroEyebrow: string; heroRailText: string; heroScrollLabel: string;
  mobileMenuLabel: string; subpageCtaLabel: string; subpageCtaHref: string; breadcrumbBackPrefix: string; breadcrumbHomeLabel: string;
  testimonialsLabel: string; testimonialsHeading: string; testimonialsHeadingAccent: string; testimonialsDescription: string; testimonialsDisclaimer: string;
  footerDescription: string; footerFollowLabel: string; footerNavigationLabel: string; footerContactLabel: string; footerPrivacyLabel: string; footerPrivacyHref: string; footerTermsLabel: string; footerTermsHref: string; footerBrochureLabel: string; footerBrochureHref: string;
  serviceBreadcrumbLabel: string; serviceItemLabel: string; serviceFeeLabel: string; serviceRevenueLabel: string; serviceRevenueHeading: string; serviceEquipmentColumn: string; serviceGrossColumn: string; serviceMilesColumn: string; serviceCtaLabel: string; serviceCtaHeading: string; serviceCtaAccent: string; serviceCtaDescription: string; serviceCtaButton: string; callButtonPrefix: string;
  truckBreadcrumbLabel: string; truckItemLabel: string; truckImageBadge: string; truckBestForLabel: string; truckReadinessLabel: string; truckFreightHeading: string; truckRevenueLabel: string; truckGrossPrefix: string; truckCustomValue: string; truckCustomDescription: string; truckRevenueDisclaimer: string; truckCtaLabel: string; truckCtaHeading: string; truckCtaAccent: string; truckCtaDescription: string; truckCtaButton: string;
  blogsSeoTitle: string; blogsSeoDescription: string; blogsLabel: string; blogsHeading: string; blogsHeadingAccent: string; blogsDescription: string; blogsEmptyTitle: string; blogsEmptyDescription: string; blogsReadMoreLabel: string; blogBreadcrumbLabel: string; blogTagsLabel: string; blogReadingTimeSuffix: string;
  contactAverageResponseLabel: string; contactFormLabel: string; contactFormHeading: string; contactNameLabel: string; contactNamePlaceholder: string; contactCompanyLabel: string; contactCompanyPlaceholder: string; contactPhoneLabel: string; contactPhonePlaceholder: string; contactEmailLabel: string; contactEmailPlaceholder: string; contactTruckLabel: string; contactTruckPlaceholder: string; contactZipLabel: string; contactZipPlaceholder: string; contactLanesLabel: string; contactLanesPlaceholder: string; contactMessageLabel: string; contactMessagePlaceholder: string; contactSmsConsent: string; contactSubmitLabel: string; contactSubmittingLabel: string; contactSuccessMessage: string; contactSubmitError: string; contactConnectionError: string;
  agreementDocumentOneLabel: string; agreementDocumentTwoLabel: string; agreementModalKicker: string; agreementEditableLabel: string; agreementVersionLabel: string; agreementPrintLabel: string; agreementCopyLabel: string; agreementCloseLabel: string; agreementContactLabel: string; agreementContactSubject: string;
  detailCountConnector: string; truckMilesSuffix: string; truckSeoSuffix: string; agreementSectionPrefix: string; agreementLegalNameLabel: string; agreementDotLabel: string; agreementMcLabel: string; agreementAddressLabel: string; agreementPhoneLabel: string; agreementEmailLabel: string; agreementCopySuccess: string; agreementCopyError: string;
}

export interface PublicSiteContent {
  company: CompanyContent;
  navLinks: NavigationLink[];
  sectionIds: string[];
  socialLinks: SocialLink[];
  truckTypes: FleetTruckType[];
  pricing: PricingItem[];
  services: FleetService[];
  steps: OnboardingStep[];
  heroStats: HeroStatistic[];
  heroHeading: string;
  heroHeadingAccent: string;
  heroTagline: string;
  heroDescription: string;
  heroPrimaryCtaLabel: string;
  heroPrimaryCtaHref: string;
  heroSecondaryCtaLabel: string;
  heroSecondaryCtaHref: string;
  heroShowAuthority: boolean;
  heroImages: string[];
  heroImageAlts: string[];
  mediaAlt: Record<string, string>;
  sectionCopy: SectionCopyContent;
  aboutImage: string;
  aboutImageAlt: string;
  aboutEnabled: boolean;
  aboutSectionLabel: string;
  aboutHeading: string;
  aboutHeadingAccent: string;
  aboutEstablishedText: string;
  aboutYearsLabel: string;
  aboutYears: string;
  aboutDescription1: string;
  aboutDescription2: string;
  aboutFeatures: AboutFeature[];
  marqueeItems: string[];
  agreementSummary: AgreementItem[];
  agreementDocument: AgreementDocumentContent;
  contactCards: ContactCard[];
  contactSectionLabel: string;
  contactHeading: string;
  contactHeadingAccent: string;
  contactDescription: string;
  dispatchStatusText: string;
  dispatchResponseTime: string;
  contactAfterHoursText: string;
  contactPrivacyDisclaimer: string;
  testimonials: TestimonialContent[];
}
