import "server-only";

import { and, eq, isNull } from "drizzle-orm";
import { getDb } from "@/db";
import { mediaAssets } from "@/db/schema";
import { imageHrefFrom, text, ValidationError } from "./admin-validation";
import { lockContent, mediaReferences } from "./media-safety";
import { removeMediaObject, uploadMediaObject, validateMediaFile, type MediaFolder } from "../storage/media";

type Transaction = Parameters<Parameters<ReturnType<typeof getDb>["transaction"]>[0]>[0];
export type PreparedImage = { url: string; alt: string; file?: File; upload?: Awaited<ReturnType<typeof uploadMediaObject>> };

export async function prepareImage(formData: FormData, name: string, folder: MediaFolder, required = false): Promise<PreparedImage | null> {
  const file = formData.get(`${name}File`);
  const alt = text(formData, `${name}Alt`, 500, false);
  let url = imageHrefFrom(formData, name, false);
  let upload: PreparedImage["upload"];
  if (file instanceof File && file.size) {
    upload = await uploadMediaObject(file, await validateMediaFile(file), folder);
    url = upload.publicUrl;
  }
  if (required && !url) throw new ValidationError(`${name} is required.`);
  if (url && !alt) throw new ValidationError(`Alternative text is required for ${name}.`);
  return url ? { url, alt, ...(file instanceof File && file.size ? { file } : {}), ...(upload ? { upload } : {}) } : null;
}

export async function persistImage(tx: Transaction, image: PreparedImage | null, actor: string) {
  if (!image) return;
  const [existing] = await tx.select({ id: mediaAssets.id }).from(mediaAssets).where(and(eq(mediaAssets.path, image.url), isNull(mediaAssets.deletedAt))).limit(1);
  if (existing) {
    await tx.update(mediaAssets).set({ altText: image.alt, updatedAt: new Date(), updatedBy: actor }).where(eq(mediaAssets.id, existing.id));
    return;
  }
  if (!image.upload && !/^https?:\/\//i.test(image.url)) throw new ValidationError("Choose an active local image or enter a public HTTP(S) URL.");
  await tx.insert(mediaAssets).values(image.upload && image.file ? {
    path: image.url, fileName: image.file.name.slice(0, 260), mimeType: image.file.type, cloudinaryPublicId: image.upload.publicId, source: "cloudinary", sizeBytes: image.upload.sizeBytes, width: image.upload.width, height: image.upload.height, altText: image.alt, createdBy: actor, updatedBy: actor,
  } : {
    path: image.url, fileName: new URL(image.url).pathname.split("/").at(-1)?.slice(0,260) || "External image", mimeType: "image/external", source: "external", altText: image.alt, createdBy: actor, updatedBy: actor,
  });
}

export async function cleanupUpload(image: PreparedImage | null) {
  if (image?.upload) try { await removeMediaObject(image.upload.publicId); } catch { console.error("Unable to clean up failed CMS image upload."); }
}

export async function removeReplacedImage(path: string | null | undefined, replacement: string | null | undefined, actor: string) {
  if (!path || path === replacement) return;
  const asset = await getDb().transaction(async tx => {
    await lockContent(tx);
    const [row] = await tx.select().from(mediaAssets).where(and(eq(mediaAssets.path,path),isNull(mediaAssets.deletedAt))).limit(1);
    if (!row || row.source !== "cloudinary" || !row.cloudinaryPublicId || (await mediaReferences(tx,path)).length) return null;
    await tx.update(mediaAssets).set({deletedAt:new Date(),updatedAt:new Date(),updatedBy:actor}).where(eq(mediaAssets.id,row.id));
    return row;
  });
  if (!asset) return;
  try { await removeMediaObject(asset.cloudinaryPublicId!); }
  catch (error) { await getDb().update(mediaAssets).set({deletedAt:null,updatedAt:new Date(),updatedBy:actor}).where(eq(mediaAssets.id,asset.id)); throw error; }
}
