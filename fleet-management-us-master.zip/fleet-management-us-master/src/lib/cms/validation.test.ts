import assert from "node:assert/strict";
import test from "node:test";
import { SITE_CONTENT } from "../../data/content.ts";
import { validateReview } from "./review-validation.ts";
import { actionError, hrefFrom, idFrom, selectedIds, slugFrom, requireConfirmation } from "./admin-validation.ts";
import { validateServiceDetail, validateAgreementSections } from "./structured-validation.ts";
import { validateMediaFile } from "../storage/media-validation.ts";
import { readSubmission } from "../submission-request.ts";
import { validateCarrierApplication } from "../carrier-application.ts";
import { validateBlog } from "./blog-validation.ts";

const form = (values:Record<string,string>) => {const data=new FormData();for(const [key,value] of Object.entries(values))data.set(key,value);return data;};

test("nested content preserves source and rejects malformed objects",()=>{
  for(const service of SITE_CONTENT.services) assert.deepEqual(JSON.parse(JSON.stringify(validateServiceDetail(service.detail))),service.detail);
  assert.throws(()=>validateServiceDetail({heading:"x",intro:"y",sections:[{title:"z",items:[null]}]}));
  assert.throws(()=>validateServiceDetail({heading:"x",intro:"y",sections:[],revenueTargets:{targets:[{weeklyGrossMin:9,weeklyGrossMax:1}]}}));
  assert.throws(()=>validateAgreementSections([{number:"01",title:"x",kind:"list",items:[{description:{unsafe:true}}]}]));
  assert.deepEqual(validateServiceDetail({heading:"x",intro:"y",sections:[]}).sections,[]);
});
test("review statuses, notes, rating and URL bounds",()=>{
  const data=form({name:"Validation test",role:"Carrier",quote:"A validation-only review; never stored.",initials:"VT",rating:"5",status:"pending",sortOrder:"0"});
  assert.equal(validateReview(data).ok,true);
  for(const [key,value] of [["rating","0"],["rating","6"],["status","draft"],["avatarPath","javascript:alert(1)"],["avatarPath","/\\evil.test/a.png"],["internalNotes","x".repeat(5001)]]){
    const invalid=form(Object.fromEntries(data) as Record<string,string>);invalid.set(key,value);assert.equal(validateReview(invalid).ok,false,key);
  }
});
test("strict identifiers, safe links, confirmation, sanitized errors",()=>{
  for(const id of ["-1","0","2147483648","NaN"])assert.throws(()=>idFrom(form({id}),true));
  const selection=form({selectedId:"1"});selection.append("selectedId","bad");assert.throws(()=>selectedIds(selection));
  for(const slug of ["../admin","two words","Upper","a--b"])assert.throws(()=>slugFrom(form({slug})));
  for(const href of ["javascript:alert(1)","data:text/html,x","//evil.test","/\\evil.test","https:\\evil.test"])assert.throws(()=>hrefFrom(form({href}),"href"));
  assert.equal(hrefFrom(form({href:"#contact"}),"href"),"#contact");
  assert.throws(()=>requireConfirmation(new FormData()));requireConfirmation(form({confirmed:"yes"}));
  assert.equal(actionError(new Error("postgresql://secret")).error?.includes("secret"),false);
  assert.match(actionError({cause:{code:"23505"}}).error!,/already in use/);
});
test("carrier input rejects overlong optional fields and invalid types",()=>{
  const valid={fullName:"Test",phone:"5551234567",email:"test@example.invalid",truckType:"Dry Van",zip:"60607"};
  assert.equal(validateCarrierApplication(valid,new Set(["Dry Van"])).ok,true);
  for(const extra of [{message:"x".repeat(5001)},{company:{}},{phone:"......."},{smsOptIn:"true"}])assert.equal(validateCarrierApplication({...valid,...extra},new Set(["Dry Van"])).ok,false);
});
test("media rejects unsafe types, misleading extensions, invalid signatures and oversize uploads",async()=>{
  const avif=new Uint8Array(12);avif.set([0x66,0x74,0x79,0x70,0x61,0x76,0x69,0x66],4);
  assert.equal((await validateMediaFile(new File([avif],"image.avif",{type:"image/avif"}))).length,avif.length);
  for(const file of [
    new File(["<svg/>"],"image.svg",{type:"image/svg+xml"}),
    new File(["<script>"],"image.jpg",{type:"image/jpeg"}),
    new File([new Uint8Array([255,216,255])],"image.exe",{type:"image/jpeg"}),
    new File([new Uint8Array(5*1024*1024+1)],"image.jpg",{type:"image/jpeg"}),
  ])await assert.rejects(validateMediaFile(file));
});
test("public JSON requests enforce type, size and origin",async()=>{
  const request=(body:string,headers:Record<string,string>={})=>new Request("https://site.test/api/reviews",{method:"POST",headers:{"content-type":"application/json",...headers},body});
  assert.deepEqual(await readSubmission(request('{"ok":true}')),{ok:true});
  await assert.rejects(readSubmission(request("not-json")));
  await assert.rejects(readSubmission(request('"'+"x".repeat(16001)+'"')));
  await assert.rejects(readSubmission(request("{}",{"origin":"https://evil.test"})));
  await assert.rejects(readSubmission(request("{}",{"content-type":"text/plain"})));
});
test("blog input accepts safe Markdown and rejects unsafe image URLs",()=>{
  const valid=form({title:"Test post",slug:"test-post",body:"# Safe\n\n<script>alert(1)</script>",author:"Admin",category:"Operations",tags:"fleet, safety, fleet",seoKeywords:"dispatch, carriers, dispatch",readingTime:"4",status:"draft",featuredImage:"https://example.com/truck.webp"});
  const blog=validateBlog(valid);assert.deepEqual(blog.tags,["fleet","safety"]);assert.deepEqual(blog.seoKeywords,["dispatch","carriers"]);assert.equal(blog.status,"draft");
  valid.set("featuredImage","javascript:alert(1)");assert.throws(()=>validateBlog(valid));valid.set("featuredImage","mailto:test@example.com");assert.throws(()=>validateBlog(valid));
  valid.set("featuredImage","");valid.set("slug","Bad Slug");assert.throws(()=>validateBlog(valid));
});
