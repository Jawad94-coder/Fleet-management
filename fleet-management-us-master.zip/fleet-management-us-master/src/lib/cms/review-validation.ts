export const reviewStatuses = ["pending", "published", "rejected", "archived"] as const;
export type ReviewStatus = (typeof reviewStatuses)[number];

export interface ReviewValues {
  quote: string;
  name: string;
  company: string | null;
  role: string;
  equipment: string | null;
  location: string | null;
  tenure: string | null;
  initials: string;
  avatarPath: string | null;
  avatarAlt: string | null;
  rating: number;
  featured: boolean;
  internalNotes: string | null;
  status: ReviewStatus;
  sortOrder: number;
}

export interface ReviewFormState {
  success?: string;
  error?: string;
  fieldErrors?: Partial<Record<keyof ReviewValues, string>>;
}

function field(formData: FormData, name: string) {
  const value = formData.get(name);
  return typeof value === "string" ? value.trim() : "";
}

export function validateReview(formData: FormData): { ok: true; data: ReviewValues } | { ok: false; state: ReviewFormState } {
  const values = {
    quote: field(formData, "quote"), name: field(formData, "name"), company: field(formData, "company"), role: field(formData, "role"), equipment: field(formData, "equipment"), location: field(formData, "location"), tenure: field(formData, "tenure"), initials: field(formData, "initials").toUpperCase(), avatarPath: field(formData, "avatarPath"), avatarAlt: field(formData, "avatarPathAlt"), rating: Number(field(formData, "rating")), featured: formData.get("featured") === "on", internalNotes: field(formData, "internalNotes"), status: field(formData, "status"), sortOrder: Number(field(formData, "sortOrder")),
  };
  const fieldErrors: ReviewFormState["fieldErrors"] = {};
  if (values.quote.length < 20 || values.quote.length > 3000) fieldErrors.quote = "Use between 20 and 3,000 characters.";
  if (!values.name || values.name.length > 160) fieldErrors.name = "Name is required and must be 160 characters or fewer.";
  if (values.company.length > 200) fieldErrors.company = "Company must be 200 characters or fewer.";
  if (!values.role || values.role.length > 200) fieldErrors.role = "Role is required and must be 200 characters or fewer.";
  if (values.equipment.length > 160) fieldErrors.equipment = "Equipment must be 160 characters or fewer.";
  if (values.location.length > 160) fieldErrors.location = "Location must be 160 characters or fewer.";
  if (values.tenure.length > 160) fieldErrors.tenure = "Tenure must be 160 characters or fewer.";
  if (!/^[A-Z0-9]{1,4}$/.test(values.initials)) fieldErrors.initials = "Use 1–4 letters or numbers.";
  if (values.avatarPath && (values.avatarPath.length > 1000 || !/^(?:\/(?![\/\\])[a-z0-9_./%-]+|https:\/\/[^\s\\]+)$/i.test(values.avatarPath))) fieldErrors.avatarPath = "Choose a safe local or HTTPS image URL.";
  if (values.avatarAlt.length > 500 || (values.avatarPath && !values.avatarAlt)) fieldErrors.avatarAlt = "Alternative text is required for a reviewer image and must be 500 characters or fewer.";
  if (!Number.isInteger(values.rating) || values.rating < 1 || values.rating > 5) fieldErrors.rating = "Rating must be from 1 to 5.";
  if (values.internalNotes.length > 5000) fieldErrors.internalNotes = "Internal notes must be 5,000 characters or fewer.";
  if (!reviewStatuses.includes(values.status as ReviewStatus)) fieldErrors.status = "Choose a valid review status.";
  if (!Number.isInteger(values.sortOrder) || values.sortOrder < 0 || values.sortOrder > 10000) fieldErrors.sortOrder = "Order must be a whole number from 0 to 10,000.";
  if (Object.keys(fieldErrors).length) return { ok: false, state: { error: "Please correct the highlighted fields.", fieldErrors } };
  return { ok: true, data: { quote: values.quote, name: values.name, company: values.company || null, role: values.role, equipment: values.equipment || null, location: values.location || null, tenure: values.tenure || null, initials: values.initials, avatarPath: values.avatarPath || null, avatarAlt: values.avatarAlt || null, rating: values.rating, featured: values.featured, internalNotes: values.internalNotes || null, status: values.status as ReviewStatus, sortOrder: values.sortOrder } };
}
