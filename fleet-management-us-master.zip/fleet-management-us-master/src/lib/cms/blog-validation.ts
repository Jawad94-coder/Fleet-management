import type { BlogStatus } from "@/db/schema";
import { ValidationError, imageHrefFrom, optionalKeywordsFrom, slugFrom, text } from "./admin-validation.ts";

export function blogStatusFrom(formData: FormData): BlogStatus {
  const status = formData.get("status");
  if (status !== "draft" && status !== "published" && status !== "archived") {
    throw new ValidationError("Choose Draft, Published, or Archived.");
  }
  return status;
}

function publishedAtFrom(formData: FormData, status: BlogStatus) {
  const value = text(formData, "publishedAt", 40, false);
  if (!value) return status === "published" ? new Date() : null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) throw new ValidationError("Published date is invalid.");
  return date;
}

export function validateBlog(formData: FormData) {
  const status = blogStatusFrom(formData);
  const readingTime = Number(text(formData, "readingTime", 3));
  if (!Number.isInteger(readingTime) || readingTime < 1 || readingTime > 120) {
    throw new ValidationError("Reading time must be from 1 to 120 minutes.");
  }
  const tags = [...new Set(text(formData, "tags", 2000, false).split(",").map(tag => tag.trim()).filter(Boolean))];
  if (tags.length > 30 || tags.some(tag => tag.length > 80)) throw new ValidationError("Use at most 30 tags, each 80 characters or fewer.");

  return {
    title: text(formData, "title", 240),
    slug: slugFrom(formData),
    excerpt: text(formData, "excerpt", 1000, false) || null,
    body: text(formData, "body", 100000),
    featuredImage: imageHrefFrom(formData, "featuredImage", false) || null,
    featuredImageAlt: text(formData, "featuredImageAlt", 500, false) || null,
    author: text(formData, "author", 160),
    category: text(formData, "category", 160),
    tags,
    publishedAt: publishedAtFrom(formData, status),
    status,
    readingTime,
    seoTitle: text(formData, "seoTitle", 240, false) || null,
    seoDescription: text(formData, "seoDescription", 500, false) || null,
    seoKeywords: optionalKeywordsFrom(formData),
  };
}
