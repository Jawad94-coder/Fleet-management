import "server-only";

import { cache } from "react";
import { and, asc, desc, eq, isNull, ne } from "drizzle-orm";
import { getDb } from "@/db";
import {
  aboutContent,
  aboutFeatures,
  agreementItems,
  agreementDocument,
  contactCards,
  contactSettings,
  heroContent,
  heroStatistics,
  marqueeItems,
  mediaAssets,
  navigationLinks,
  onboardingSteps,
  pricingItems,
  services,
  sectionCopy,
  siteSettings,
  socialLinks,
  slugRedirects,
  testimonials,
  truckTypes,
} from "@/db/schema";
import type { FleetService, FleetTruckType } from "@/data/content";
import type { PublicSiteContent, TestimonialContent } from "./types";

const published = <TStatus, TDeleted>(status: TStatus, deletedAt: TDeleted) =>
  and(eq(status as never, "published"), isNull(deletedAt as never));

function missing(section: string): never {
  throw new Error(`CMS is not seeded: missing ${section}. Run npm run db:seed.`);
}

export const getSiteSettings = cache(async () => {
  const [row] = await getDb().select({
    name: siteSettings.name,
    legalName: siteSettings.legalName,
    shortName: siteSettings.shortName,
    tagline: siteSettings.tagline,
    estYear: siteSettings.estYear,
    dot: siteSettings.dot,
    mc: siteSettings.mc,
    phone: siteSettings.phone,
    phoneHref: siteSettings.phoneHref,
    email: siteSettings.email,
    emailHref: siteSettings.emailHref,
    address: siteSettings.address,
    city: siteSettings.city,
    website: siteSettings.website,
    hours: siteSettings.hours,
    copyright: siteSettings.copyright,
    logo:siteSettings.logo,
    logoAlt:siteSettings.logoAlt,
    seoTitle:siteSettings.seoTitle,
    seoDescription:siteSettings.seoDescription,
  }).from(siteSettings).where(eq(siteSettings.id, 1)).limit(1);
  return row ?? missing("site settings");
});

export const getNavigation = cache(async () => getDb().select({
  href: navigationLinks.href,
  label: navigationLinks.label,
}).from(navigationLinks).where(published(navigationLinks.status, navigationLinks.deletedAt)).orderBy(asc(navigationLinks.sortOrder)));

export const getSocialLinks = cache(async () => getDb().select({
  label: socialLinks.label,
  icon: socialLinks.icon,
  href: socialLinks.href,
}).from(socialLinks).where(and(published(socialLinks.status, socialLinks.deletedAt),ne(socialLinks.href,"#"))).orderBy(asc(socialLinks.sortOrder)));

export const getHeroContent = cache(async () => {
  const [content, statistics] = await Promise.all([
    getDb().select({
      heading: heroContent.heading,
      headingAccent: heroContent.headingAccent,
      tagline: heroContent.tagline,
      description: heroContent.description,
      primaryCtaLabel: heroContent.primaryCtaLabel,
      primaryCtaHref: heroContent.primaryCtaHref,
      secondaryCtaLabel: heroContent.secondaryCtaLabel,
      secondaryCtaHref: heroContent.secondaryCtaHref,
      showAuthority: heroContent.showAuthority,
      images: heroContent.images,
      imageAlts:heroContent.imageAlts,
    }).from(heroContent).where(and(eq(heroContent.id, 1), eq(heroContent.enabled, true))).limit(1),
    getDb().select({ value: heroStatistics.value, label: heroStatistics.label, accent: heroStatistics.accent }).from(heroStatistics).where(published(heroStatistics.status, heroStatistics.deletedAt)).orderBy(asc(heroStatistics.sortOrder)),
  ]);
  return { ...(content[0] ?? missing("hero content")), statistics };
});

export const getAboutContent = cache(async () => {
  const [content, features] = await Promise.all([
    getDb().select({ sectionLabel: aboutContent.sectionLabel, heading: aboutContent.heading, headingAccent: aboutContent.headingAccent, establishedText: aboutContent.establishedText, yearsLabel: aboutContent.yearsLabel, image: aboutContent.image, imageAlt:aboutContent.imageAlt, years: aboutContent.years, description1: aboutContent.description1, description2: aboutContent.description2, enabled:aboutContent.enabled }).from(aboutContent).where(eq(aboutContent.id, 1)).limit(1),
    getDb().select({ icon: aboutFeatures.icon, title: aboutFeatures.title, description: aboutFeatures.description, accent: aboutFeatures.accent }).from(aboutFeatures).where(published(aboutFeatures.status, aboutFeatures.deletedAt)).orderBy(asc(aboutFeatures.sortOrder)),
  ]);
  return { ...(content[0] ?? missing("about content")), features };
});

export const getServices = cache(async () => {
  const rows = await getDb().select({ num: services.num, slug: services.slug, icon: services.icon, image:services.image,imageAlt:services.imageAlt, title: services.title, desc: services.description, ctaLabel:services.ctaLabel, ctaHref:services.ctaHref, detail: services.detail, seoTitle:services.seoTitle, seoDescription:services.seoDescription, seoKeywords:services.seoKeywords, updatedAt: services.updatedAt }).from(services).where(published(services.status, services.deletedAt)).orderBy(asc(services.sortOrder));
  return rows.map(({image,imageAlt,...row})=>({...row,...(image?{image}:{}),...(imageAlt?{imageAlt}:{})}));
});

export const getServiceBySlug = cache(async (slug: string): Promise<FleetService | null> => {
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) || slug.length > 160) return null;
  const [row] = await getDb().select({ num: services.num, slug: services.slug, icon: services.icon, image:services.image,imageAlt:services.imageAlt, title: services.title, desc: services.description, ctaLabel:services.ctaLabel, ctaHref:services.ctaHref, detail: services.detail, seoTitle:services.seoTitle, seoDescription:services.seoDescription, seoKeywords:services.seoKeywords }).from(services).where(and(eq(services.slug, slug), published(services.status, services.deletedAt))).limit(1);
  return row ? (({image,imageAlt,...service})=>({...service,...(image?{image}:{}),...(imageAlt?{imageAlt}:{})}))(row) : null;
});

export const getSlugRedirect = cache(async (entityType: "service" | "truck", oldSlug: string) => {
  const [row] = await getDb().select({ newSlug: slugRedirects.newSlug }).from(slugRedirects).where(and(eq(slugRedirects.entityType, entityType), eq(slugRedirects.oldSlug, oldSlug))).limit(1);
  if (!row || row.newSlug === oldSlug) return null;
  const target = entityType === "service" ? await getServiceBySlug(row.newSlug) : await getTruckTypeBySlug(row.newSlug);
  return target ? row.newSlug : null;
});

const truckSelection = {
  num: truckTypes.num,
  slug: truckTypes.slug,
  icon: truckTypes.icon,
  name: truckTypes.name,
  spec: truckTypes.spec,
  image: truckTypes.image,
  imageAlt:truckTypes.imageAlt,
  intro: truckTypes.intro,
  bestFor: truckTypes.bestFor,
  commonFreight: truckTypes.commonFreight,
  equipmentNotes: truckTypes.equipmentNotes,
  weeklyGrossMin: truckTypes.weeklyGrossMin,
  weeklyGrossMax: truckTypes.weeklyGrossMax,
  avgMilesPerWeek: truckTypes.avgMilesPerWeek,
  seoTitle: truckTypes.seoTitle,
  seoDescription: truckTypes.seoDescription,
  seoKeywords: truckTypes.seoKeywords,
  updatedAt: truckTypes.updatedAt,
};

function mapTruck(row: typeof truckTypes.$inferSelect): FleetTruckType {
  return {
    num: row.num,
    slug: row.slug,
    icon: row.icon,
    name: row.name,
    spec: row.spec,
    image: row.image,
    imageAlt:row.imageAlt,
    intro: row.intro,
    bestFor: row.bestFor,
    commonFreight: row.commonFreight,
    equipmentNotes: row.equipmentNotes,
    weeklyGrossMin: row.weeklyGrossMin ?? undefined,
    weeklyGrossMax: row.weeklyGrossMax ?? undefined,
    avgMilesPerWeek: row.avgMilesPerWeek ?? undefined,
    seoTitle: row.seoTitle,
    seoDescription: row.seoDescription,
    seoKeywords: row.seoKeywords,
  };
}

export const getTruckTypes = cache(async () => {
  const rows = await getDb().select(truckSelection).from(truckTypes).where(published(truckTypes.status, truckTypes.deletedAt)).orderBy(asc(truckTypes.sortOrder));
  return rows.map((row) => ({ ...mapTruck(row as typeof truckTypes.$inferSelect), updatedAt: row.updatedAt }));
});

export const getPublishedTruckTypeNames = cache(async () => {
  const rows = await getDb().select({ name: truckTypes.name }).from(truckTypes).where(published(truckTypes.status, truckTypes.deletedAt)).orderBy(asc(truckTypes.sortOrder));
  return rows.map(({ name }) => name);
});

export const getTruckTypeBySlug = cache(async (slug: string): Promise<FleetTruckType | null> => {
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) || slug.length > 160) return null;
  const [row] = await getDb().select(truckSelection).from(truckTypes).where(and(eq(truckTypes.slug, slug), published(truckTypes.status, truckTypes.deletedAt))).limit(1);
  return row ? mapTruck(row as typeof truckTypes.$inferSelect) : null;
});

export const getPricing = cache(async () => {
  const rows = await getDb().select({ name: pricingItems.name, value: pricingItems.value, unit: pricingItems.unit, agreementSuffix: pricingItems.agreementSuffix, description: pricingItems.description, highlight: pricingItems.highlight }).from(pricingItems).where(published(pricingItems.status, pricingItems.deletedAt)).orderBy(asc(pricingItems.sortOrder));
  return rows.map(({ agreementSuffix, ...row }) => ({ ...row, ...(agreementSuffix ? { agreementSuffix } : {}) }));
});

export const getTestimonials = cache(async (): Promise<TestimonialContent[]> => {
  const rows = await getDb().select({ id:testimonials.id,quote:testimonials.quote,name:testimonials.name,company:testimonials.company,role:testimonials.role,equipment:testimonials.equipment,location:testimonials.location,tenure:testimonials.tenure,initials:testimonials.initials,avatarPath:testimonials.avatarPath,avatarAlt:testimonials.avatarAlt,rating:testimonials.rating,featured:testimonials.featured }).from(testimonials).where(published(testimonials.status,testimonials.deletedAt)).orderBy(desc(testimonials.featured),asc(testimonials.sortOrder),asc(testimonials.id));
  return rows.map(({company,equipment,location,tenure,avatarPath,avatarAlt,...row})=>({...row,...(company?{company}:{}),...(equipment?{equipment}:{}),...(location?{location}:{}),...(tenure?{tenure}:{}),...(avatarPath?{avatarPath}:{}),...(avatarAlt?{avatarAlt}:{})}));
});

export const getContactSettings = cache(async () => {
  const [settings, cards] = await Promise.all([
    getDb().select({ sectionLabel: contactSettings.sectionLabel, heading: contactSettings.heading, headingAccent: contactSettings.headingAccent, description: contactSettings.description, dispatchStatusText: contactSettings.dispatchStatusText, dispatchResponseTime: contactSettings.dispatchResponseTime, afterHoursText: contactSettings.afterHoursText, privacyDisclaimer: contactSettings.privacyDisclaimer }).from(contactSettings).where(and(eq(contactSettings.id, 1), eq(contactSettings.enabled, true))).limit(1),
    getDb().select({ icon: contactCards.icon, label: contactCards.label, href: contactCards.href, value: contactCards.value }).from(contactCards).where(published(contactCards.status, contactCards.deletedAt)).orderBy(asc(contactCards.sortOrder)),
  ]);
  return {
    ...(settings[0] ?? missing("contact settings")),
    cards: cards.map(({ href, ...card }) => ({ ...card, ...(href ? { href } : {}) })),
  };
});

export const getSiteContent = cache(async (): Promise<PublicSiteContent> => {
  const [company, navLinks, social, hero, about, serviceRows, truckRows, pricing, steps, agreement, documentRows, contact, marquee, media, copyRows, reviewRows] = await Promise.all([
    getSiteSettings(),
    getNavigation(),
    getSocialLinks(),
    getHeroContent(),
    getAboutContent(),
    getServices(),
    getTruckTypes(),
    getPricing(),
    getDb().select({ num: onboardingSteps.num, label: onboardingSteps.label, title: onboardingSteps.title, desc: onboardingSteps.description }).from(onboardingSteps).where(published(onboardingSteps.status, onboardingSteps.deletedAt)).orderBy(asc(onboardingSteps.sortOrder)),
    getDb().select({ num: agreementItems.num, title: agreementItems.title, description: agreementItems.description }).from(agreementItems).where(published(agreementItems.status, agreementItems.deletedAt)).orderBy(asc(agreementItems.sortOrder)),
    getDb().select({ version: agreementDocument.version, title: agreementDocument.title, intro: agreementDocument.intro, sections: agreementDocument.sections, carrierSignatureLabel: agreementDocument.carrierSignatureLabel, carrierSignatureHelp: agreementDocument.carrierSignatureHelp, companySignatureLabel: agreementDocument.companySignatureLabel, companySignatureHelp: agreementDocument.companySignatureHelp }).from(agreementDocument).where(eq(agreementDocument.id, 1)).limit(1),
    getContactSettings(),
    getDb().select({ label: marqueeItems.label }).from(marqueeItems).where(published(marqueeItems.status, marqueeItems.deletedAt)).orderBy(asc(marqueeItems.sortOrder)),
    getDb().select({ path: mediaAssets.path, altText: mediaAssets.altText }).from(mediaAssets).where(isNull(mediaAssets.deletedAt)),
    getDb().select({ content: sectionCopy.content }).from(sectionCopy).where(eq(sectionCopy.id, 1)).limit(1),
    getTestimonials(),
  ]);

  return {
    company,
    navLinks,
    sectionIds: navLinks.filter((link) => /^#[a-z][a-z0-9-]*$/i.test(link.href)).map((link) => link.href.slice(1)),
    socialLinks: social,
    truckTypes: truckRows,
    pricing,
    services: serviceRows,
    steps,
    heroStats: hero.statistics,
    heroHeading: hero.heading,
    heroHeadingAccent: hero.headingAccent,
    heroTagline: hero.tagline,
    heroDescription: hero.description,
    heroPrimaryCtaLabel: hero.primaryCtaLabel,
    heroPrimaryCtaHref: hero.primaryCtaHref,
    heroSecondaryCtaLabel: hero.secondaryCtaLabel,
    heroSecondaryCtaHref: hero.secondaryCtaHref,
    heroShowAuthority: hero.showAuthority,
    heroImages: hero.images,
    heroImageAlts:hero.imageAlts,
    mediaAlt: Object.fromEntries(media.filter((asset) => asset.altText).map((asset) => [asset.path, asset.altText!])),
    sectionCopy: copyRows[0]?.content ?? missing("section copy"),
    aboutImage: about.image,
    aboutImageAlt: about.imageAlt,
    aboutEnabled: about.enabled,
    aboutSectionLabel: about.sectionLabel,
    aboutHeading: about.heading,
    aboutHeadingAccent: about.headingAccent,
    aboutEstablishedText: about.establishedText,
    aboutYearsLabel: about.yearsLabel,
    aboutYears: about.years,
    aboutDescription1: about.description1,
    aboutDescription2: about.description2,
    aboutFeatures: about.features,
    marqueeItems: marquee.map(({ label }) => label),
    agreementSummary: agreement,
    agreementDocument: documentRows[0] ?? missing("agreement document"),
    contactCards: contact.cards,
    contactSectionLabel: contact.sectionLabel,
    contactHeading: contact.heading,
    contactHeadingAccent: contact.headingAccent,
    contactDescription: contact.description,
    dispatchStatusText: contact.dispatchStatusText,
    dispatchResponseTime: contact.dispatchResponseTime,
    contactAfterHoursText: contact.afterHoursText,
    contactPrivacyDisclaimer: contact.privacyDisclaimer,
    testimonials: reviewRows,
  };
});
