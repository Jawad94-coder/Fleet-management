import type { ContentStatus } from "@/db/schema";

export class ValidationError extends Error {}

export interface CmsFormState {
  success?: string;
  error?: string;
  fieldErrors?: Record<string, string>;
}

export function text(formData: FormData, name: string, max = 3000, required = true) {
  const raw = formData.get(name);
  const value = typeof raw === "string" ? raw.trim() : "";
  if (required && !value) throw new ValidationError(`${name} is required.`);
  if (value.length > max) throw new ValidationError(`${name} must be ${max} characters or fewer.`);
  return value;
}

export function optionalKeywordsFrom(formData: FormData) {
  const keywords = [...new Set(text(formData, "seoKeywords", 2000, false).split(",").map((keyword) => keyword.trim()).filter(Boolean))];
  if (keywords.length > 30 || keywords.some((keyword) => keyword.length > 80)) throw new ValidationError("Use at most 30 SEO keywords, each 80 characters or fewer.");
  return keywords.length ? keywords : null;
}

export function idFrom(formData: FormData, required = false) {
  const id = Number(formData.get("id"));
  if (!required && !formData.get("id")) return null;
  if (!Number.isSafeInteger(id) || id < 1 || id > 2147483647) throw new ValidationError("Invalid record ID.");
  return id;
}

export function selectedIds(formData: FormData) {
  const raw = formData.getAll("selectedId");
  if (!raw.length || raw.length > 200 || raw.some(value => typeof value !== "string" || !/^[1-9]\d*$/.test(value) || Number(value) > 2147483647)) throw new ValidationError("Select between 1 and 200 valid records.");
  return [...new Set(raw.map(Number))];
}

export function requireConfirmation(formData: FormData) {
  if (formData.get("confirmed") !== "yes") throw new ValidationError("Confirm this destructive action first.");
}

export function orderFrom(formData: FormData) {
  const value = Number(formData.get("sortOrder"));
  if (!Number.isInteger(value) || value < 0 || value > 10000) throw new ValidationError("Order must be from 0 to 10,000.");
  return value;
}

export function statusFrom(formData: FormData): ContentStatus {
  const status = formData.get("status");
  if (status !== "published" && status !== "draft") throw new ValidationError("Choose published or draft.");
  return status;
}

export function booleanFrom(formData: FormData, name: string) {
  return formData.get(name) === "on" || formData.get(name) === "true";
}

export function hrefFrom(formData: FormData, name: string, required = true) {
  const value = text(formData, name, 1000, required);
  if (!value) return value;
  if (/[\\\\\u0000-\u001f\u007f]/.test(value)) throw new ValidationError(`${name} contains unsafe URL characters.`);
  if (value.startsWith("#") && /^#[a-z][a-z0-9-]*$/i.test(value)) return value;
  if (/^\/(?!\/)[a-z0-9_./%-]*(?:\?[a-z0-9_=&.%-]*)?(?:#[a-z0-9-]*)?$/i.test(value)) return value;
  try {
    const url = new URL(value);
    if (["https:", "http:", "mailto:", "tel:"].includes(url.protocol)) return value;
  } catch {}
  throw new ValidationError(`${name} must be a safe anchor, web, email, or phone URL.`);
}

export function imageHrefFrom(formData: FormData, name: string, required = true) {
  const value = text(formData, name, 1000, required);
  if (!value) return value;
  if (/^\/(?!\/)[a-z0-9_./%-]*(?:\?[a-z0-9_=&.%-]*)?$/i.test(value)) return value;
  try {
    const url = new URL(value);
    if (url.protocol === "https:" || url.protocol === "http:") return url.href;
  } catch {}
  throw new ValidationError(`${name} must be an HTTP(S) image URL or a local /path.`);
}

export function slugFrom(formData: FormData) {
  const value = text(formData, "slug", 160);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value)) throw new ValidationError("Slug may contain lowercase letters, numbers, and single hyphens only.");
  return value;
}

export function integerFrom(formData: FormData, name: string, required = false) {
  const raw = text(formData, name, 20, required);
  if (!raw) return null;
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value < 0 || value > 2147483647) throw new ValidationError(`${name} must be a positive whole number.`);
  return value;
}

export function jsonFrom<T>(formData: FormData, name: string): T {
  try {
    return JSON.parse(text(formData, name, 100000)) as T;
  } catch {
    throw new ValidationError(`${name} contains invalid structured content.`);
  }
}

export function actionError(error: unknown): CmsFormState {
  const message = error instanceof Error ? error.message : "The change could not be saved.";
  const candidate = error as { code?: string; cause?: { code?: string } };
  if (candidate?.code === "23505" || candidate?.cause?.code === "23505") return { error: "That slug, number, label, or URL is already in use." };
  return { error: error instanceof ValidationError ? message : "The change could not be saved. Please try again." };
}
