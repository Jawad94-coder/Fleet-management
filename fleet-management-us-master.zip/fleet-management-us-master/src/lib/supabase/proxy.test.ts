import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

test("Supabase session refresh only covers admin pages", () => {
  const source = readFileSync(new URL("../../../proxy.ts", import.meta.url), "utf8");
  const literal = source.match(/matcher:\s*\[\s*("(?:\\.|[^"\\])*")/);
  assert.ok(literal);
  assert.equal(JSON.parse(literal[1]), "/admin/:path*");
});
