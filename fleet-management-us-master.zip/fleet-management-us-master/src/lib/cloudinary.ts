import "server-only";

import { v2 as cloudinary } from "cloudinary";

export function getCloudinary() {
  const cloud_name=process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME;
  const api_key=process.env.CLOUDINARY_API_KEY;
  const api_secret=process.env.CLOUDINARY_API_SECRET;
  if(!cloud_name||!api_key||!api_secret)throw new Error("Cloudinary is not configured.");
  cloudinary.config({cloud_name,api_key,api_secret,secure:true});
  return cloudinary;
}
