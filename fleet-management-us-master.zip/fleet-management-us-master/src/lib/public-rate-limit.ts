import "server-only";

import { createHmac } from "node:crypto";
import { sql } from "drizzle-orm";
import { getDb } from "@/db";

export function submissionFingerprint(request: Request, discriminator: string) {
  const forwarded=(process.env.TRUST_PROXY_HEADERS === "true" ? request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() : null) || "shared";
  const secret=process.env.RATE_LIMIT_SECRET||process.env.DATABASE_URL;
  if(!secret)throw new Error("Rate limiting is not configured.");
  return createHmac("sha256",secret).update(`${discriminator === "source" ? forwarded : discriminator.toLowerCase()}`).digest("hex");
}

export async function consumeRateLimit(action:string,keyHash:string,limit=5,windowMinutes=15){
  const cleanExpiredRows=action==="public_source"&&Math.random()<0.01;
  const result=await getDb().execute(sql`
    WITH cleanup AS (
      DELETE FROM public_rate_limits
      WHERE ${cleanExpiredRows} AND window_started_at < now() - interval '30 days'
    )
    INSERT INTO public_rate_limits (action,key_hash,window_started_at,request_count)
    VALUES (${action},${keyHash},now(),1)
    ON CONFLICT (action,key_hash) DO UPDATE SET
      request_count=CASE WHEN public_rate_limits.window_started_at < now() - (${windowMinutes} * interval '1 minute') THEN 1 ELSE public_rate_limits.request_count + 1 END,
      window_started_at=CASE WHEN public_rate_limits.window_started_at < now() - (${windowMinutes} * interval '1 minute') THEN now() ELSE public_rate_limits.window_started_at END
    RETURNING request_count
  `);
  return Number(result.rows[0]?.request_count??limit+1)<=limit;
}
