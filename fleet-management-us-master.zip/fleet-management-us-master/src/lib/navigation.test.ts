import assert from "node:assert/strict";
import test from "node:test";
import { navHref, subpageActiveNavHref } from "./navigation.ts";

test("subpage navigation links home sections and highlights the current collection", () => {
  assert.equal(navHref("#services", true), "/#services");
  assert.equal(navHref("/blogs", true), "/blogs");
  assert.equal(subpageActiveNavHref("/services/mc-lease-on"), "#services");
  assert.equal(subpageActiveNavHref("/truck-types/dry-van"), "#trucks");
  assert.equal(subpageActiveNavHref("/blogs/example"), "/blogs");
});
