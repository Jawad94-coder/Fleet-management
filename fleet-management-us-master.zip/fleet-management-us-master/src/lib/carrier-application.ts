export interface CarrierApplicationInput {
  fullName: string;
  companyName: string | null;
  phone: string;
  email: string;
  truckType: string;
  currentZip: string;
  preferredLanes: string | null;
  message: string | null;
  smsOptIn: boolean;
  smsConsentAt: Date | null;
}

type ValidationResult =
  | { ok: true; data: CarrierApplicationInput }
  | { ok: false; error: string };

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const zipPattern = /^\d{5}(?:-\d{4})?$/;

function textValue(
  input: Record<string, unknown>,
  key: string,
  maxLength: number,
) {
  const value = input[key];
  const normalized=typeof value === "string"?value.trim():"";
  return normalized.length<=maxLength?normalized:"";
}

export function validateCarrierApplication(input: unknown, allowedTruckTypes: ReadonlySet<string>): ValidationResult {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return { ok: false, error: "Invalid submission." };
  }

  const values = input as Record<string, unknown>;
  const limits: Record<string, number> = {fullName:160,company:200,phone:60,email:200,truckType:100,zip:10,lanes:500,message:5000};
  for (const [key, max] of Object.entries(limits)) {
    if (values[key] != null && (typeof values[key] !== "string" || (values[key] as string).trim().length > max)) return {ok:false,error:`Invalid or overlong ${key} field.`};
  }
  if (values.smsOptIn !== undefined && typeof values.smsOptIn !== "boolean") return {ok:false,error:"Invalid SMS consent."};
  const fullName = textValue(values, "fullName", 160);
  const companyName = textValue(values, "company", 200);
  const phone = textValue(values, "phone", 60);
  const email = textValue(values, "email", 200).toLowerCase();
  const truckType = textValue(values, "truckType", 100);
  const currentZip = textValue(values, "zip", 10);
  const preferredLanes = textValue(values, "lanes", 500);
  const message = textValue(values, "message", 5000);
  const smsOptIn = values.smsOptIn === true;

  if (!fullName || !phone || !email || !truckType || !currentZip) {
    return { ok: false, error: "Please complete every required field." };
  }

  if (!emailPattern.test(email)) {
    return { ok: false, error: "Please enter a valid email address." };
  }

  if (!/^[+()\d\s.-]{7,60}$/.test(phone) || phone.replace(/\D/g, "").length < 7) {
    return { ok: false, error: "Please enter a valid phone number." };
  }

  if (!zipPattern.test(currentZip)) {
    return { ok: false, error: "Please enter a valid US ZIP code." };
  }

  if (!allowedTruckTypes.has(truckType)) {
    return { ok: false, error: "Please select a valid truck type." };
  }

  return {
    ok: true,
    data: {
      fullName,
      companyName: companyName || null,
      phone,
      email,
      truckType,
      currentZip,
      preferredLanes: preferredLanes || null,
      message: message || null,
      smsOptIn,
      smsConsentAt: smsOptIn ? new Date() : null,
    },
  };
}
