# Image sources

The website photographs below are used under the [Unsplash License](https://unsplash.com/license). They were resized and cropped for the website.

| Website asset | Photographer | Source |
| --- | --- | --- |
| `public/images/hero-fleet.webp` | Josiah Farrow | https://unsplash.com/photos/ucuOscdCaO4 |
| `public/images/hero-fleet-highway.webp` | Tom Jackson | https://unsplash.com/photos/H2UzCyX32p4 |
| `public/images/hero-fleet-terminal.webp` | Troy Mortier | https://unsplash.com/photos/xkAIwD0hsbg |
| `public/images/truck-box.webp` | Maxim Tolchinskiy | https://unsplash.com/photos/crHhZlES310 |
| `public/images/truck-straight.webp` | Sander Yigin | https://unsplash.com/photos/ki19VJAGh6w |
| `public/images/truck-flatbed.webp` | Zetong Li | https://unsplash.com/photos/mVqTumQH-c0 |
| `public/images/truck-step-deck.webp` | Roger Starnes Sr | https://unsplash.com/photos/LBWYlnzk2AE |
| `public/images/truck-reefer.webp` | Shay | https://unsplash.com/photos/5n2EemBYQm4 |
| `public/images/truck-dry-van.webp` | Caleb Ruiter | https://unsplash.com/photos/EmEQ6kK_5P0 |
| `public/images/truck-hotshot.webp` | Preston A Larimer | https://unsplash.com/photos/I6i77l3Cyng |
