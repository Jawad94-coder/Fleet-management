ALTER TABLE "cms_media_assets" ADD COLUMN "cloudinary_public_id" varchar(500);--> statement-breakpoint
ALTER TABLE "cms_media_assets" ADD COLUMN "source" varchar(20) DEFAULT 'local' NOT NULL;--> statement-breakpoint
UPDATE "cms_media_assets" SET "source" = CASE WHEN "storage_key" IS NOT NULL THEN 'supabase' WHEN "path" LIKE '/%' THEN 'local' ELSE 'external' END;--> statement-breakpoint
ALTER TABLE "cms_media_assets" ADD CONSTRAINT "cms_media_assets_cloudinary_public_id_unique" UNIQUE("cloudinary_public_id");--> statement-breakpoint
ALTER TABLE "cms_media_assets" ADD CONSTRAINT "cms_media_source_values" CHECK ("cms_media_assets"."source" IN ('local','external','supabase','cloudinary'));
