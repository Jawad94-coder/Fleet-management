DO $$ BEGIN
	CREATE TYPE "public"."carrier_application_status" AS ENUM('new', 'contacted', 'qualified', 'closed');
EXCEPTION
	WHEN duplicate_object THEN null;
END $$;--> statement-breakpoint
DO $$ BEGIN
	CREATE TYPE "public"."cms_content_status" AS ENUM('published', 'draft');
EXCEPTION
	WHEN duplicate_object THEN null;
END $$;--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_about_content" (
	"id" integer PRIMARY KEY NOT NULL,
	"image" varchar(1000) NOT NULL,
	"years" varchar(40) NOT NULL,
	"description_1" text NOT NULL,
	"description_2" text NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_about_features" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" varchar(160) NOT NULL,
	"icon" varchar(120) NOT NULL,
	"description" text NOT NULL,
	"accent" boolean DEFAULT false NOT NULL,
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'published' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_about_features_title_unique" UNIQUE("title")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "admin_audit_records" (
	"id" serial PRIMARY KEY NOT NULL,
	"action" varchar(80) NOT NULL,
	"entity_type" varchar(120) NOT NULL,
	"entity_id" varchar(120) NOT NULL,
	"summary" text NOT NULL,
	"actor" varchar(120) DEFAULT 'admin' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_agreement_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"num" varchar(20) NOT NULL,
	"title" varchar(200) NOT NULL,
	"description" text NOT NULL,
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'published' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_agreement_items_num_unique" UNIQUE("num")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "carrier_applications" (
	"id" serial PRIMARY KEY NOT NULL,
	"full_name" varchar(160) NOT NULL,
	"company_name" varchar(200),
	"phone" varchar(60) NOT NULL,
	"email" varchar(200) NOT NULL,
	"truck_type" varchar(100) NOT NULL,
	"current_zip" varchar(10) NOT NULL,
	"preferred_lanes" varchar(500),
	"message" text,
	"sms_opt_in" boolean DEFAULT false NOT NULL,
	"sms_consent_at" timestamp with time zone,
	"status" "carrier_application_status" DEFAULT 'new' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_contact_cards" (
	"id" serial PRIMARY KEY NOT NULL,
	"label" varchar(160) NOT NULL,
	"icon" varchar(120) NOT NULL,
	"href" varchar(1000),
	"value" text NOT NULL,
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'published' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_contact_cards_label_unique" UNIQUE("label")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_contact_settings" (
	"id" integer PRIMARY KEY NOT NULL,
	"description" text NOT NULL,
	"dispatch_response_time" varchar(80) NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_hero_content" (
	"id" integer PRIMARY KEY NOT NULL,
	"tagline" varchar(240) NOT NULL,
	"description" text NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_hero_statistics" (
	"id" serial PRIMARY KEY NOT NULL,
	"label" varchar(160) NOT NULL,
	"value" varchar(80) NOT NULL,
	"accent" boolean DEFAULT false NOT NULL,
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'published' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_hero_statistics_label_unique" UNIQUE("label")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_marquee_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"label" varchar(160) NOT NULL,
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'published' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_marquee_items_label_unique" UNIQUE("label")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_media_assets" (
	"id" serial PRIMARY KEY NOT NULL,
	"path" varchar(1000) NOT NULL,
	"file_name" varchar(260) NOT NULL,
	"mime_type" varchar(120) NOT NULL,
	"alt_text" varchar(500),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_media_assets_path_unique" UNIQUE("path")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_navigation_links" (
	"id" serial PRIMARY KEY NOT NULL,
	"href" varchar(200) NOT NULL,
	"label" varchar(120) NOT NULL,
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'published' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_navigation_links_href_unique" UNIQUE("href")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_onboarding_steps" (
	"id" serial PRIMARY KEY NOT NULL,
	"num" varchar(20) NOT NULL,
	"label" varchar(120) NOT NULL,
	"title" varchar(200) NOT NULL,
	"description" text NOT NULL,
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'published' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_onboarding_steps_num_unique" UNIQUE("num")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_pricing_items" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" varchar(160) NOT NULL,
	"value" varchar(80) NOT NULL,
	"unit" varchar(120) NOT NULL,
	"agreement_suffix" varchar(240),
	"description" text NOT NULL,
	"highlight" boolean DEFAULT false NOT NULL,
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'published' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_pricing_items_name_unique" UNIQUE("name")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_services" (
	"id" serial PRIMARY KEY NOT NULL,
	"num" varchar(20) NOT NULL,
	"slug" varchar(160) NOT NULL,
	"icon" varchar(120) NOT NULL,
	"title" varchar(200) NOT NULL,
	"description" text NOT NULL,
	"detail" jsonb NOT NULL,
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'published' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_services_num_unique" UNIQUE("num"),
	CONSTRAINT "cms_services_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_site_settings" (
	"id" integer PRIMARY KEY NOT NULL,
	"name" varchar(160) NOT NULL,
	"short_name" varchar(160) NOT NULL,
	"tagline" varchar(160) NOT NULL,
	"est_year" integer NOT NULL,
	"dot" varchar(40) NOT NULL,
	"mc" varchar(40) NOT NULL,
	"phone" varchar(60) NOT NULL,
	"phone_href" varchar(100) NOT NULL,
	"email" varchar(200) NOT NULL,
	"email_href" varchar(240) NOT NULL,
	"address" varchar(240) NOT NULL,
	"city" varchar(160) NOT NULL,
	"website" varchar(240) NOT NULL,
	"hours" varchar(240) NOT NULL,
	"copyright" varchar(240) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_social_links" (
	"id" serial PRIMARY KEY NOT NULL,
	"label" varchar(120) NOT NULL,
	"icon" varchar(120) NOT NULL,
	"href" varchar(1000) NOT NULL,
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'published' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_social_links_label_unique" UNIQUE("label")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_testimonials" (
	"id" serial PRIMARY KEY NOT NULL,
	"quote" text NOT NULL,
	"name" varchar(160) NOT NULL,
	"role" varchar(200) NOT NULL,
	"equipment" varchar(160),
	"location" varchar(160),
	"tenure" varchar(160),
	"initials" varchar(8) NOT NULL,
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'draft' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "cms_truck_types" (
	"id" serial PRIMARY KEY NOT NULL,
	"num" varchar(20) NOT NULL,
	"slug" varchar(160) NOT NULL,
	"icon" varchar(120) NOT NULL,
	"name" varchar(200) NOT NULL,
	"spec" varchar(200) NOT NULL,
	"image" varchar(1000) NOT NULL,
	"intro" text NOT NULL,
	"best_for" text NOT NULL,
	"common_freight" jsonb NOT NULL,
	"equipment_notes" text NOT NULL,
	"weekly_gross_min" integer,
	"weekly_gross_max" integer,
	"avg_miles_per_week" varchar(120),
	"sort_order" integer NOT NULL,
	"status" "cms_content_status" DEFAULT 'published' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "cms_truck_types_num_unique" UNIQUE("num"),
	CONSTRAINT "cms_truck_types_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "cms_testimonials_identity_idx" ON "cms_testimonials" USING btree ("name","quote");
