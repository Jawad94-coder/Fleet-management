CREATE TABLE "cms_section_copy" (
	"id" integer PRIMARY KEY NOT NULL,
	"content" jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL
);
