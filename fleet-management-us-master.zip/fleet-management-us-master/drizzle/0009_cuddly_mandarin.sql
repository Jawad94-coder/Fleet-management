ALTER TABLE "cms_hero_content" ADD COLUMN "image_alts" jsonb DEFAULT '[]'::jsonb NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_services" ADD COLUMN "image_alt" varchar(500);--> statement-breakpoint
ALTER TABLE "cms_site_settings" ADD COLUMN "logo" varchar(1000) DEFAULT '/images/logo.png' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_site_settings" ADD COLUMN "logo_alt" varchar(500) DEFAULT 'Fleet Management US' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_site_settings" ADD COLUMN "seo_title" varchar(240) DEFAULT 'Fleet Management US â€” Your Partner for Reliable Trucking Operations' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_site_settings" ADD COLUMN "seo_description" varchar(500) DEFAULT 'Fleet management, dispatch, leasing, and back-office support for carriers nationwide.' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_testimonials" ADD COLUMN "avatar_alt" varchar(500);--> statement-breakpoint
ALTER TABLE "cms_truck_types" ADD COLUMN "image_alt" varchar(500) DEFAULT '' NOT NULL;--> statement-breakpoint
UPDATE "cms_site_settings" SET "seo_title"=U&'Fleet Management US \2014 Your Partner for Reliable Trucking Operations',"seo_description"='Fleet Management US helps carriers and truck owners across the country streamline operations with premium dispatch services, MC leasing, factoring support, and complete back-office solutions.';--> statement-breakpoint
UPDATE "cms_hero_content" SET "images"='["/images/hero-fleet.webp","/images/hero-fleet-highway.webp","/images/hero-fleet-terminal.webp"]'::jsonb,"image_alts"='["Commercial truck fleet","Commercial truck on the highway","Fleet terminal"]'::jsonb WHERE jsonb_array_length("images")=0;--> statement-breakpoint
UPDATE "cms_truck_types" SET "image_alt"="name" || ' commercial fleet equipment' WHERE "image_alt"='';--> statement-breakpoint
INSERT INTO "cms_media_assets" ("path","file_name","mime_type","source") VALUES ('/images/logo.png','logo.png','image/png','local'),('/images/hero-fleet.webp','hero-fleet.webp','image/webp','local'),('/images/hero-fleet-highway.webp','hero-fleet-highway.webp','image/webp','local'),('/images/hero-fleet-terminal.webp','hero-fleet-terminal.webp','image/webp','local') ON CONFLICT ("path") DO NOTHING;
--> statement-breakpoint
INSERT INTO "cms_media_assets" ("path", "file_name", "mime_type", "source")
SELECT DISTINCT
  refs.path,
  CASE WHEN refs.path LIKE '/%' THEN regexp_replace(refs.path, '^.*/', '') ELSE 'External CMS image' END,
  CASE
    WHEN lower(refs.path) ~ '\\.png([?#].*)?$' THEN 'image/png'
    WHEN lower(refs.path) ~ '\\.webp([?#].*)?$' THEN 'image/webp'
    WHEN lower(refs.path) ~ '\\.avif([?#].*)?$' THEN 'image/avif'
    WHEN lower(refs.path) ~ '\\.gif([?#].*)?$' THEN 'image/gif'
    WHEN lower(refs.path) ~ '\\.svg([?#].*)?$' THEN 'image/svg+xml'
    ELSE 'image/jpeg'
  END,
  CASE WHEN refs.path LIKE '/%' THEN 'local' ELSE 'external' END
FROM (
  SELECT "logo" AS path FROM "cms_site_settings"
  UNION SELECT "image" FROM "cms_about_content"
  UNION SELECT jsonb_array_elements_text("images") FROM "cms_hero_content"
  UNION SELECT "image" FROM "cms_services" WHERE "image" IS NOT NULL
  UNION SELECT "image" FROM "cms_truck_types"
  UNION SELECT "avatar_path" FROM "cms_testimonials" WHERE "avatar_path" IS NOT NULL
  UNION SELECT "featured_image" FROM "cms_blog_posts" WHERE "featured_image" IS NOT NULL
) AS refs
WHERE refs.path <> ''
ON CONFLICT ("path") DO NOTHING;
