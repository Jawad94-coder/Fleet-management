CREATE TYPE "public"."cms_blog_status" AS ENUM('draft', 'published', 'archived');--> statement-breakpoint
CREATE TABLE "cms_blog_posts" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" varchar(240) NOT NULL,
	"slug" varchar(160) NOT NULL,
	"excerpt" text,
	"body" text NOT NULL,
	"featured_image" varchar(1000),
	"featured_image_alt" varchar(500),
	"author" varchar(160) NOT NULL,
	"category" varchar(160) NOT NULL,
	"tags" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"published_at" timestamp with time zone,
	"status" "cms_blog_status" DEFAULT 'draft' NOT NULL,
	"reading_time" integer DEFAULT 1 NOT NULL,
	"seo_title" varchar(240),
	"seo_description" varchar(500),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL,
	CONSTRAINT "cms_blog_posts_slug_unique" UNIQUE("slug"),
	CONSTRAINT "cms_blog_reading_time_range" CHECK ("cms_blog_posts"."reading_time" BETWEEN 1 AND 120)
);
--> statement-breakpoint
ALTER TABLE "cms_blog_posts" ENABLE ROW LEVEL SECURITY;
--> statement-breakpoint
REVOKE ALL ON TABLE public."cms_blog_posts" FROM anon, authenticated;
