ALTER TABLE "cms_services" ADD COLUMN "image" varchar(1000);--> statement-breakpoint
ALTER TABLE "cms_services" ADD COLUMN "cta_label" varchar(120) DEFAULT 'View service' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_services" ADD COLUMN "cta_href" varchar(1000);--> statement-breakpoint
UPDATE "cms_services" SET "cta_href" = '/services/' || "slug";--> statement-breakpoint
ALTER TABLE "cms_services" ALTER COLUMN "cta_href" SET NOT NULL;
