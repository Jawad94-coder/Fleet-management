CREATE TYPE "public"."cms_review_status" AS ENUM('pending', 'published', 'rejected', 'archived');--> statement-breakpoint
ALTER TYPE "public"."carrier_application_status" ADD VALUE 'onboarding' BEFORE 'closed';--> statement-breakpoint
ALTER TYPE "public"."carrier_application_status" ADD VALUE 'rejected';--> statement-breakpoint
CREATE TABLE "cms_agreement_revisions" (
	"id" serial PRIMARY KEY NOT NULL,
	"version" varchar(80) NOT NULL,
	"snapshot" jsonb NOT NULL,
	"source_updated_at" timestamp with time zone NOT NULL,
	"archived_by" varchar(120) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "cms_agreement_revisions" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
CREATE TABLE "public_rate_limits" (
	"id" serial PRIMARY KEY NOT NULL,
	"action" varchar(80) NOT NULL,
	"key_hash" varchar(64) NOT NULL,
	"window_started_at" timestamp with time zone DEFAULT now() NOT NULL,
	"request_count" integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
ALTER TABLE "public_rate_limits" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_about_content" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_about_features" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "admin_audit_records" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_agreement_document" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_agreement_items" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "carrier_applications" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_contact_cards" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_contact_settings" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_hero_content" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_hero_statistics" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_marquee_items" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_media_assets" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_navigation_links" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_onboarding_steps" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_pricing_items" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_section_copy" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_services" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_site_settings" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_slug_redirects" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_social_links" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_testimonials" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_truck_types" ENABLE ROW LEVEL SECURITY;--> statement-breakpoint
ALTER TABLE "cms_testimonials" ALTER COLUMN "status" DROP DEFAULT;--> statement-breakpoint
ALTER TABLE "cms_testimonials" ALTER COLUMN "status" SET DATA TYPE "public"."cms_review_status" USING (CASE WHEN deleted_at IS NOT NULL THEN 'archived' WHEN status::text = 'draft' THEN 'pending' ELSE status::text END)::"public"."cms_review_status";--> statement-breakpoint
ALTER TABLE "cms_testimonials" ALTER COLUMN "status" SET DEFAULT 'pending';--> statement-breakpoint
ALTER TABLE "carrier_applications" ADD COLUMN "internal_notes" text;--> statement-breakpoint
ALTER TABLE "carrier_applications" ADD COLUMN "deleted_at" timestamp with time zone;--> statement-breakpoint
ALTER TABLE "cms_testimonials" ADD COLUMN "company" varchar(200);--> statement-breakpoint
ALTER TABLE "cms_testimonials" ADD COLUMN "avatar_path" varchar(1000);--> statement-breakpoint
ALTER TABLE "cms_testimonials" ADD COLUMN "rating" integer DEFAULT 5 NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_testimonials" ADD COLUMN "featured" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_testimonials" ADD COLUMN "internal_notes" text;--> statement-breakpoint
ALTER TABLE "cms_testimonials" ADD COLUMN "submitted_at" timestamp with time zone DEFAULT now() NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "public_rate_limits_action_key_idx" ON "public_rate_limits" USING btree ("action","key_hash");--> statement-breakpoint
UPDATE "cms_testimonials" SET submitted_at = created_at;--> statement-breakpoint
ALTER TABLE "cms_testimonials" ADD CONSTRAINT "cms_review_rating_range" CHECK ("cms_testimonials"."rating" BETWEEN 1 AND 5);
--> statement-breakpoint
REVOKE ALL ON TABLE public."carrier_applications", public."cms_site_settings", public."cms_hero_content", public."cms_section_copy", public."cms_about_content", public."cms_contact_settings", public."cms_navigation_links", public."cms_social_links", public."cms_hero_statistics", public."cms_about_features", public."cms_services", public."cms_truck_types", public."cms_pricing_items", public."cms_agreement_items", public."cms_agreement_document", public."cms_slug_redirects", public."cms_onboarding_steps", public."cms_testimonials", public."cms_contact_cards", public."cms_marquee_items", public."cms_media_assets", public."admin_audit_records", public."admin_users", public."public_rate_limits", public."cms_agreement_revisions" FROM anon, authenticated;
--> statement-breakpoint
CREATE POLICY "CMS admins may select media" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'cms-media' AND public.is_cms_admin());
