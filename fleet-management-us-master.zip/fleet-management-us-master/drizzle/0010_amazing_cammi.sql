ALTER TABLE "cms_site_settings" ALTER COLUMN "seo_title" SET DEFAULT 'Fleet Management US — Your Partner for Reliable Trucking Operations';--> statement-breakpoint
ALTER TABLE "cms_blog_posts" ADD COLUMN "seo_keywords" jsonb;--> statement-breakpoint
ALTER TABLE "cms_services" ADD COLUMN "seo_title" varchar(240);--> statement-breakpoint
ALTER TABLE "cms_services" ADD COLUMN "seo_description" varchar(500);--> statement-breakpoint
ALTER TABLE "cms_services" ADD COLUMN "seo_keywords" jsonb;--> statement-breakpoint
ALTER TABLE "cms_truck_types" ADD COLUMN "seo_title" varchar(240);--> statement-breakpoint
ALTER TABLE "cms_truck_types" ADD COLUMN "seo_description" varchar(500);--> statement-breakpoint
ALTER TABLE "cms_truck_types" ADD COLUMN "seo_keywords" jsonb;
