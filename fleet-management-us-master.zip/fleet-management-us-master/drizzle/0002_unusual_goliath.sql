CREATE TABLE "cms_agreement_document" (
	"id" integer PRIMARY KEY NOT NULL,
	"version" varchar(80) DEFAULT '2024.1' NOT NULL,
	"title" varchar(200) DEFAULT 'CARRIER AGREEMENT' NOT NULL,
	"intro" text NOT NULL,
	"sections" jsonb NOT NULL,
	"carrier_signature_label" varchar(160) NOT NULL,
	"carrier_signature_help" varchar(240) NOT NULL,
	"company_signature_label" varchar(160) NOT NULL,
	"company_signature_help" varchar(240) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_by" varchar(120) DEFAULT 'seed' NOT NULL,
	"updated_by" varchar(120) DEFAULT 'seed' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "cms_slug_redirects" (
	"id" serial PRIMARY KEY NOT NULL,
	"entity_type" varchar(40) NOT NULL,
	"old_slug" varchar(160) NOT NULL,
	"new_slug" varchar(160) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "cms_about_content" ADD COLUMN "section_label" varchar(160) DEFAULT 'About Fleet Management US' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_about_content" ADD COLUMN "heading" varchar(240) DEFAULT 'BUILT BY DRIVERS,' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_about_content" ADD COLUMN "heading_accent" varchar(240) DEFAULT 'FOR DRIVERS.' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_about_content" ADD COLUMN "established_text" varchar(200) DEFAULT 'EST. 2014 · CHICAGO, IL' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_about_content" ADD COLUMN "years_label" varchar(240) DEFAULT 'Years Building Careers on the Road' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_contact_settings" ADD COLUMN "section_label" varchar(160) DEFAULT 'Contact' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_contact_settings" ADD COLUMN "heading" varchar(240) DEFAULT 'LET''S GET YOUR' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_contact_settings" ADD COLUMN "heading_accent" varchar(240) DEFAULT 'WHEELS ROLLING.' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_contact_settings" ADD COLUMN "dispatch_status_text" varchar(160) DEFAULT 'DISPATCH ONLINE NOW' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_contact_settings" ADD COLUMN "after_hours_text" varchar(240) DEFAULT 'After-hours line available for active carriers.' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_contact_settings" ADD COLUMN "privacy_disclaimer" text DEFAULT 'By submitting, you agree to be contacted by Fleet Management US regarding carrier opportunities. We never share your information.' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_hero_content" ADD COLUMN "heading" varchar(240) DEFAULT 'FLEET
MANAGEMENT' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_hero_content" ADD COLUMN "heading_accent" varchar(120) DEFAULT 'US' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_hero_content" ADD COLUMN "primary_cta_label" varchar(120) DEFAULT 'Get Started' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_hero_content" ADD COLUMN "primary_cta_href" varchar(200) DEFAULT '#contact' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_hero_content" ADD COLUMN "secondary_cta_label" varchar(120) DEFAULT 'View Services' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_hero_content" ADD COLUMN "secondary_cta_href" varchar(200) DEFAULT '#services' NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_hero_content" ADD COLUMN "show_authority" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_hero_content" ADD COLUMN "images" jsonb DEFAULT '[]'::jsonb NOT NULL;--> statement-breakpoint
ALTER TABLE "cms_media_assets" ADD COLUMN "storage_key" varchar(1000);--> statement-breakpoint
ALTER TABLE "cms_media_assets" ADD COLUMN "size_bytes" integer;--> statement-breakpoint
ALTER TABLE "cms_media_assets" ADD COLUMN "width" integer;--> statement-breakpoint
ALTER TABLE "cms_media_assets" ADD COLUMN "height" integer;--> statement-breakpoint
ALTER TABLE "cms_site_settings" ADD COLUMN "legal_name" varchar(200) DEFAULT 'Fleet Management US LLC' NOT NULL;--> statement-breakpoint
CREATE UNIQUE INDEX "cms_slug_redirect_identity_idx" ON "cms_slug_redirects" USING btree ("entity_type","old_slug");--> statement-breakpoint
ALTER TABLE "cms_media_assets" ADD CONSTRAINT "cms_media_assets_storage_key_unique" UNIQUE("storage_key");
--> statement-breakpoint
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('cms-media', 'cms-media', true, 5242880, ARRAY['image/jpeg', 'image/png', 'image/webp'])
ON CONFLICT (id) DO UPDATE SET public = EXCLUDED.public, file_size_limit = EXCLUDED.file_size_limit, allowed_mime_types = EXCLUDED.allowed_mime_types;
--> statement-breakpoint
CREATE OR REPLACE FUNCTION public.is_cms_admin() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = ''
AS $$ SELECT EXISTS (SELECT 1 FROM public.admin_users WHERE user_id = auth.uid() AND active = true) $$;
--> statement-breakpoint
REVOKE ALL ON FUNCTION public.is_cms_admin() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_cms_admin() TO authenticated;
--> statement-breakpoint
CREATE POLICY "CMS admins may upload media" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'cms-media' AND public.is_cms_admin());
--> statement-breakpoint
CREATE POLICY "CMS admins may update media" ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'cms-media' AND public.is_cms_admin())
WITH CHECK (bucket_id = 'cms-media' AND public.is_cms_admin());
--> statement-breakpoint
CREATE POLICY "CMS admins may delete media" ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'cms-media' AND public.is_cms_admin());
