# Fleet Management US - System Flow and Architecture

Last verified against the repository: **September 27, 2026**

This document describes the current implementation. The application is no longer a static, content-file-only landing page: public content is read from PostgreSQL, administrators manage it through a protected CMS, public forms create operational records, Supabase Auth provides admin sessions, and Cloudinary stores uploaded images.

No credentials or environment-specific values belong in this document.

## 1. System at a Glance

```mermaid
flowchart LR
    Visitor[Public visitor] --> Next[Next.js 16 application]
    Admin[CMS administrator] --> Next

    Next --> PublicPages[Public server-rendered pages]
    Next --> PublicAPI[Public submission APIs]
    Next --> AdminUI[Protected admin routes and server actions]

    PublicPages --> CMSQueries[CMS and blog queries]
    PublicAPI --> Validation[Validation, honeypot, and rate limiting]
    AdminUI --> Auth[Supabase Auth and admin allow-list]

    CMSQueries --> Drizzle[Drizzle ORM]
    Validation --> Drizzle
    AdminUI --> Drizzle
    Drizzle --> Postgres[(PostgreSQL / Supabase)]

    AdminUI --> Cloudinary[Cloudinary image storage]
    Cloudinary --> MediaDB[Media metadata in PostgreSQL]
    MediaDB --> Drizzle
```

The main runtime boundaries are:

- **Next.js App Router:** routing, server rendering, metadata, route handlers, and server actions.
- **React client components:** homepage interaction, navigation, modal/toast state, carousels, and form submission.
- **PostgreSQL through Drizzle:** public CMS content, blogs, leads, reviews, admins, audit records, media metadata, redirects, and rate-limit counters.
- **Supabase Auth:** email/password admin identity and cookie-based sessions.
- **Cloudinary:** uploaded image objects. PostgreSQL stores their public URLs and Cloudinary public IDs.

## 2. Technology Stack

| Layer | Current implementation |
| --- | --- |
| Framework | Next.js `16.3.4`, App Router, Turbopack in development |
| Request interception | `proxy.ts` at the repository root (the Next 16 name for `middleware.ts`) |
| UI | React `19.2.8`, TypeScript |
| Styling | Tailwind CSS 3, one global stylesheet, `next/font/google` (Anton, Inter, Oswald), native icon symbols |
| Database | PostgreSQL hosted by Supabase, reached through the `pg` node-postgres driver |
| ORM and migrations | Drizzle ORM and Drizzle Kit |
| Authentication | Supabase Auth through `@supabase/ssr` |
| Image storage | Cloudinary |
| Validation/testing | Server-side validators and Node's built-in test runner |
| Server-only guard | The `server-only` package on every database, storage, and auth module |

Runtime boundaries are enforced by the `server-only` import rather than by convention. `src/db/index.ts`, `src/lib/cms/queries.ts`, `src/lib/cloudinary.ts`, `src/lib/storage/media.ts`, `src/lib/public-rate-limit.ts`, `src/lib/server-error.ts`, `src/lib/admin-auth.ts`, and `src/lib/cms/media-safety.ts` all declare it, so importing them from a client component fails at build time. `src/db/schema.ts` deliberately omits it because Drizzle Kit loads that file outside a server context.

The `pg` pool is created with `max: 1` and is cached on `globalThis` in development only, so hot reloads do not leak connections. In production a fresh pool is built per module load.

## 3. Request and Rendering Flow

### 3.1 Public page request

```mermaid
sequenceDiagram
    participant B as Browser
    participant R as App Router page
    participant Q as CMS query layer
    participant D as PostgreSQL
    participant C as React client tree

    B->>R: Request a public page
    R->>Q: Load published CMS content
    Q->>D: Drizzle SELECT queries
    D-->>Q: Rows
    Q-->>R: Typed PublicSiteContent
    R-->>B: Server-rendered HTML and serialized content
    B->>C: Hydrate interactive components
```

Important behavior:

- `/`, service pages, truck-type pages, and blog pages use five-minute incremental static regeneration (`revalidate = 300`). CMS mutations also invalidate affected paths on demand.
- Published service, truck-type, and blog slugs are generated during the production build; newly published slugs are generated and cached on their first request.
- `src/lib/cms/queries.ts` uses React `cache()` to deduplicate identical reads during a render; it is not a long-lived CMS cache. All fifteen exported query functions and both blog queries are wrapped; the only unwrapped module-scope helpers are synchronous (`published`, `missing`, `mapTruck`) or pure column projections.
- Only published, non-deleted records are exposed by public CMS queries. `cms_blog_posts` has no `deleted_at` column at all; `archived` status already excludes it.
- Admin pages do not use the cached read layer. They issue their own inline `getDb()` queries and are `force-dynamic`, so they always reflect committed state.
- `app/layout.tsx` reads site settings for database-driven metadata and uses `NEXT_PUBLIC_SITE_URL` as the metadata base, falling back to `https://www.fleetmanagementus.com` when the variable is unset.
- There is no runtime fallback to `src/data/content.ts` when the database is unavailable or unseeded.

There is no `/services` index route and no `/truck-types` index route. Both sections exist only as homepage anchors (`/#services`, `/#trucks`); the only public routes they own are the `[slug]` detail pages.

### 3.2 Homepage composition

`app/page.tsx` is a server component. It calls `getSiteContent()` and passes the resulting `PublicSiteContent` object to the client-side `HomePage` component.

```text
app/page.tsx
  -> getSiteContent()
  -> HomePage(content)
       -> CmsProvider
       -> TopBar
       -> Navbar + MobileNav
       -> Hero
       -> MarqueeBanner
       -> About
       -> Services
       -> TruckTypes
       -> AgreementPricing
       -> HowItWorks
       -> Testimonials
       -> Contact
       -> Footer
       -> AgreementModal
       -> Toast
```

`CmsProvider` makes the server-loaded content available to client components through `useCms()`. `HomePage` owns only UI state:

- mobile navigation open/closed;
- agreement modal open/closed;
- current toast message and timeout;
- active homepage section from `useActiveSection()`.

The contact form is the exception to read-only content rendering: it posts to the carrier-application API described below.

### 3.3 Service and truck-type detail requests

Both detail route families validate the slug before querying the database.

```text
/services/[slug]
  -> validate slug
  -> query published service
  -> if missing, look up a service slug redirect
  -> permanent redirect when a valid replacement exists
  -> otherwise 404

/truck-types/[slug]
  -> validate slug
  -> query published truck type
  -> if missing, look up a truck slug redirect
  -> permanent redirect when a valid replacement exists
  -> otherwise 404
```

Changing a service or truck-type slug in the admin creates a `cms_slug_redirects` record, preserving old public URLs. The `entity_type` discriminator is `service` for services and `truck` for truck types, unique on `(entity_type, old_slug)`. A rename also rewrites any redirect rows that previously pointed at the old slug, which collapses redirect chains. Reusing a retired slug is rejected, and a redirect is only followed when its target is still published.

Blog posts are the exception: renaming a blog slug revalidates the old and new URLs but writes no redirect, so the previous blog URL stops resolving.

### 3.4 Blog requests

- `/blogs` lists records whose status is `published`, ordered by publication date and creation date.
- `/blogs/[slug]` validates the slug and returns only a published post.
- Blog metadata includes canonical URL, article Open Graph data, publication time, and featured-image metadata when available.
- Service, truck-type, and blog metadata prefers optional per-record SEO title, description, and keyword overrides, then falls back to the public record copy.
- `BlogMarkdown` renders the stored Markdown body. Draft and archived posts are not publicly queryable.
- Service and truck-type detail pages link to up to four other published records of the same type and to the blog index. Blog articles expose service links only when a published service title is explicitly represented by the article category or tags.

## 4. Route Map

### 4.1 Public routes

| Route | Purpose | Data source |
| --- | --- | --- |
| `/` | Main marketing site and carrier application form | Aggregated published CMS content |
| `/services/[slug]` | Published service detail | `cms_services` plus redirect lookup |
| `/truck-types/[slug]` | Published equipment detail | `cms_truck_types` plus redirect lookup |
| `/blogs` | Published blog index | `cms_blog_posts` |
| `/blogs/[slug]` | Published blog article | `cms_blog_posts` |
| `POST /api/carrier-applications` | Create a carrier lead | `carrier_applications` |
| `POST /api/reviews` | Submit a pending testimonial | `cms_testimonials` |

These are the only two route handlers in the application, and both are `POST`-only. They are intentionally unauthenticated public intake endpoints: neither calls `requireAdmin()`, and `proxy.ts` does not match `/api/*` at all. `POST /api/carrier-applications` pins `export const runtime = "nodejs"`.

The current website UI consumes the carrier-application endpoint. The review endpoint exists for a public or external submission client, while the homepage only displays approved testimonials.

### 4.2 Admin routes

| Route | Purpose |
| --- | --- |
| `/admin/login` | Email/password sign-in |
| `/admin` | Live counts, recent leads, recent audited changes |
| `/admin/content` | Hero, About, statistics, features, onboarding, contact, and marquee content |
| `/admin/services` | List, publish/draft, create, edit, and archive services |
| `/admin/services/new` | Create a service |
| `/admin/services/[id]/edit` | Edit a service and preserve old slugs |
| `/admin/truck-types` | List, publish/draft, create, edit, and archive truck types |
| `/admin/truck-types/new` | Create a truck type |
| `/admin/truck-types/[id]/edit` | Edit a truck type and preserve old slugs |
| `/admin/pricing` | Section copy, pricing rows, agreement summary, and full agreement |
| `/admin/reviews` | Filter, moderate, feature, bulk-update, and archive testimonials |
| `/admin/reviews/new` | Create a testimonial in the CMS |
| `/admin/reviews/[id]/edit` | Edit a testimonial |
| `/admin/blogs` | Manage blog publication state |
| `/admin/blogs/new` | Create a blog post |
| `/admin/blogs/[id]/edit` | Edit a blog post |
| `/admin/media` | Upload, register, edit, and safely remove media |
| `/admin/leads` | Search, filter, sort, paginate, and bulk-update carrier leads |
| `/admin/leads/[id]` | Lead details, status, notes, and archival |
| `/admin/audit` | Search recent authenticated mutations |
| `/admin/settings` | Company identity, SEO, logo, navigation, and social links |

All routes inside `app/admin/(dashboard)` are protected by the route-group layout, which calls `requireAdmin()` before rendering. The layout also sets `export const dynamic = "force-dynamic"`, so the check cannot be skipped by static prerendering. Every page inside the group additionally calls `requireAdmin()` itself; `getCurrentAdmin()` is wrapped in React `cache()`, so those repeat calls cost one Supabase verification and one query per request.

`/admin/login` sits outside the group and self-guards in the opposite direction: it redirects to `/admin` when a session is already valid. `loading.tsx` and `error.tsx` exist only for this route group; public routes use Next's built-in 404 and error handling.

## 5. Public Submission Flows

### 5.1 Carrier application

```mermaid
sequenceDiagram
    participant U as Visitor
    participant F as Contact component
    participant A as POST /api/carrier-applications
    participant L as Rate limiter
    participant D as PostgreSQL
    participant M as Admin dashboard

    U->>F: Submit carrier application
    F->>A: JSON payload
    A->>A: Parse request and reject filled honeypot
    A->>L: Source limit: 30 / 15 minutes
    L->>D: Atomically update hashed counter
    A->>A: Validate fields and published truck type
    A->>L: Identity limit: 5 / 15 minutes
    L->>D: Atomically update hashed counter
    A->>D: Insert lead with status new
    A->>M: Revalidate admin layout
    A-->>F: 201 and application ID
    F-->>U: Reset form and show toast
```

The validator normalizes the browser field names into the database shape. `fullName`, `phone`, `email`, `truckType`, and the ZIP field are required; `company`, preferred lanes, and the message are optional. `smsOptIn` must be a boolean when present and absent values coerce to `false`. SMS consent is stored as a boolean and, when opted in, receives a `sms_consent_at` timestamp set by the validator itself, not by a database default. The submitted `truckType` must match the name of a currently published truck type, so the form's allow-list is CMS data rather than a hardcoded list.

Failed validation returns `400`, rate limiting returns `429` with `Retry-After: 900`, and unexpected server failures return a generic `500` response. `logServerError()` records only the error `name` and `code`, never the message or stack.

### 5.2 Public review submission

```text
POST /api/reviews
  -> parse submission
  -> reject honeypot or invalid shape
  -> copy only nine whitelisted keys into FormData, forcing status=pending and sortOrder=0
  -> validate review fields
  -> apply source (30 / 15 min) and per-reviewer-name (3 / 15 min) hashed rate limits
  -> insert testimonial as pending, createdBy/updatedBy = public
  -> revalidate admin views
  -> administrator publishes, rejects, or archives it
  -> only published reviews appear on the homepage
```

Because the route rebuilds a `FormData` from a fixed key allow-list, a caller cannot set `status`, `featured`, `sortOrder`, `avatarPath`, or `internalNotes`. The same `validateReview()` implementation backs this endpoint and the admin review form.

Review ratings are constrained to 1-5 in both validation and the database.

### 5.3 Submission body parsing

`src/lib/submission-request.ts` is the only path by which either endpoint reads a body. It deliberately avoids `request.json()` and instead enforces four checks before parsing:

1. Rejects a cross-origin `Origin` header.
2. Requires `Content-Type: application/json`.
3. Rejects a declared `Content-Length` above 16 KB.
4. Streams the body and cancels it if the actual byte count exceeds 16 KB, so an absent or understated `Content-Length` cannot bypass the cap.

### 5.4 Rate-limit identity

`src/lib/public-rate-limit.ts` HMAC-hashes each discriminator before storage. The key uses `RATE_LIMIT_SECRET`, falling back to `DATABASE_URL` if the dedicated secret is absent; if neither is set, rate limiting throws rather than degrading open.

Client IP headers are trusted only when `TRUST_PROXY_HEADERS=true`; that setting should be enabled only behind a proxy that overwrites `x-forwarded-for`. With the setting off, the source discriminator collapses to the literal `"shared"`, so the 30-per-15-minutes source budget is a single global pool across all visitors rather than a per-IP cap. Identity budgets are keyed on a normalized value instead — the lowercased email for carrier applications, the submitted reviewer name for reviews — and are unaffected by the proxy setting.

Rate-limit cleanup shares the atomic counter-upsert query and runs probabilistically on source-limit checks (a one-percent chance, deleting rows older than 30 days). It does not add a separate database round trip to every submission.

## 6. Authentication and Authorization Flow

```mermaid
sequenceDiagram
    participant A as Administrator
    participant L as /admin/login action
    participant S as Supabase Auth
    participant D as PostgreSQL
    participant P as Protected admin layout/action

    A->>L: Submit email and password
    L->>S: signInWithPassword
    S-->>L: Authenticated user and session cookies
    L->>D: Find matching active admin_users row
    alt Active allow-listed user
        L-->>A: Redirect to /admin
    else Missing or inactive row
        L->>S: Sign out
        L-->>A: Redirect with forbidden error
    end

    A->>P: Open page or submit mutation
    P->>S: Verify signed claims
    P->>D: Re-check active admin_users row
    P->>D: Read or mutate CMS data
```

Authorization has three gates, all of which must pass:

1. `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` must both be set, otherwise `getCurrentAdmin()` returns `null` before touching Supabase or the database.
2. Supabase must verify a valid session from the cookie (`auth.getClaims()` returning a string `sub`).
3. The user's UUID must exist in `admin_users` with `active = true`.

`proxy.ts` refreshes Supabase sessions only for `/admin/:path*`. Public pages, APIs, and static assets bypass it. When Supabase is unconfigured the refresh helper returns a plain pass-through response rather than failing, so the site still boots. Protected pages and every admin server action independently call `requireAdmin()`; the proxy is session maintenance, not the authorization boundary.

Of the 31 exported server actions, 28 call `requireAdmin()` as their first statement. The three exceptions are deliberate or inherited: `loginAdmin` and `logoutAdmin` cannot require the session they are establishing or clearing, and `archiveReview` delegates to `setReviewStatus`, which does check.

New admins are created in Supabase Auth and then explicitly allow-listed with:

```bash
npm run admin:grant -- admin@example.com
```

Login failure modes surface as a query parameter on the login page: `error=config` when Supabase is unconfigured, `error=forbidden` when the credentials are valid but no active `admin_users` row exists, and `error=invalid` for rejected credentials. A forbidden login signs the Supabase session out with `scope: "local"` so a valid non-admin credential cannot leave a lingering session. `requireAdmin()` itself redirects to a bare `/admin/login` with no parameter, so an unauthenticated visit to a protected route shows a plain login form without a stated reason.

## 7. Admin Mutation Flow

Most CMS writes follow this pattern:

```text
Admin form
  -> server action
  -> requireAdmin()
  -> parse and validate FormData
  -> database transaction
       -> pg_advisory_xact_lock(726401)
       -> create/update/status change/soft delete
       -> insert admin_audit_records entry
       -> create slug redirect or agreement revision when applicable
  -> revalidate affected public and admin paths
  -> return structured success/error state
```

Operational rules:

- Ordered CMS collections use `sortOrder`.
- General content records use `published` or `draft`.
- Reviews use `pending`, `published`, `rejected`, or `archived`.
- Blogs use `draft`, `published`, or `archived`.
- Leads use `new`, `contacted`, `qualified`, `onboarding`, `closed`, or `rejected`.
- Most removals are soft deletes through `deletedAt`; blog removal is represented by `archived` status.
- Destructive and sensitive bulk operations require an explicit `confirmed` hidden field whose value must be the literal `yes`. Archive and delete paths call `requireConfirmation()`; the review status actions call it only for the `archived` and `rejected` transitions. Bulk selections are additionally bounded to 1-200 valid IDs. Unpublishing a blog, service, or truck type does not require confirmation and relies on a client-side dialog only.
- Updating the full agreement archives the previous document in `cms_agreement_revisions` before replacement, under a `SELECT ... FOR UPDATE` row lock. The archive is unconditional, so every save produces a revision even when nothing material changed.

Concurrency and audit caveats:

- The advisory lock in `lockContent()` serializes CMS writers so reference checks and deletions cannot interleave. It is a single global CMS lock, not per-record.
- The audit insert is inside the same transaction as the mutation for 29 of 31 actions. Two are not: `loginAdmin` writes its audit row with no transaction (there is no paired mutation to protect), and `deleteMedia` commits the soft delete, deletes the Cloudinary object, then writes the audit row as a separate statement — a failure in that final insert leaves the asset deleted with no audit trail.
- Soft-deleting a replaced media asset through `removeReplacedImage()` writes no audit record at all. Reached from site settings, hero, About, service, truck-type, blog, and review saves.
- The six singleton updates match on `id = 1` without checking the affected row count, so an unseeded table still records an `updated` audit entry for a write that did nothing.
- Audit summaries carry actor, action, entity, and a short text summary. No passwords, lead notes, review quotes, blog bodies, or agreement sections are recorded, but editorial labels the admin typed — entity titles, labels, slugs, and agreement versions — are interpolated into the summary, bounded by the validator's length caps.

Revalidation is exclusively `revalidatePath()`; there is no `revalidateTag()` and no `unstable_cache` in the codebase. CMS and media mutations revalidate `/` with `type: "layout"`, which cascades over the nested admin layout. Lead actions revalidate `/admin` and `/admin/leads`. Blog actions revalidate `/admin/blogs`, `/blogs`, and the affected post URLs, including the previous slug on a rename. Review actions revalidate `/admin`, `/admin/reviews`, and `/`. Both public APIs revalidate `/admin` with `type: "layout"`. Individual admin pages such as `/admin/content` and `/admin/media` are never revalidated explicitly, which is safe because they are `force-dynamic` and read the database directly.

## 8. Media Flow

### 8.1 Upload

```text
Admin selects an image and CMS folder
  -> validate declared size, MIME type, extension/MIME agreement, and magic-number bytes
  -> upload stream to fleet-management-us/<folder> in Cloudinary
  -> receive secure URL, public ID, size, width, and height
  -> insert cms_media_assets metadata
  -> select the URL from CMS image fields
```

Validation is byte-level, not just header-level. `validateMediaFile()` reads the uploaded bytes and sniffs the signature, including the RIFF/WEBP sub-brand and the AVIF `ftyp` box, so a script or SVG body renamed to `.jpg` is rejected. Accepted types are JPEG, PNG, WebP, and AVIF up to 5 MB. The validated byte array is the one handed to Cloudinary, so what was inspected is what is uploaded.

Supported logical folders are `hero`, `about`, `services`, `trucks`, `blogs`, `testimonials`, and `company`. The admin media form's folder picker offers the first six; `company` is reached through the site logo field rather than the picker.

The media library also permits registration of an external image URL without uploading a file. Existing local and earlier Supabase-backed records remain representable through the `source` field, which is constrained to `local`, `external`, `supabase`, or `cloudinary`.

### 8.2 Update and delete safety

- Alternative text is maintained in `cms_media_assets` and also copied into content-specific fields where required.
- Public content images use `next/image` with explicit dimensions or `fill` plus `sizes`. Local and configured Cloudinary images use Next.js optimization; legacy or registered external URLs remain unoptimized unless their host is explicitly configured.
- `mediaReferences()` checks 13 CMS sources in one query before a media item is removed or replaced. It intentionally includes drafts, archived records, and agreement history, so restoring old content cannot resurrect a broken image.
- Referenced assets cannot be deleted. The error names every referencing section.
- Cloudinary objects are destroyed only for records whose `source` is `cloudinary` and which have a public ID.
- The database record is soft-deleted after reference and storage checks. If the Cloudinary destroy then fails, the soft delete is rolled back so a failed remote delete does not orphan the row.
- An upload that succeeds but whose metadata insert fails has its Cloudinary object removed as compensation.

The migrations still contain Supabase Storage policies and a `cms-media` bucket from the earlier storage implementation, but current uploads use Cloudinary.

## 9. Data Model

All 26 application tables have PostgreSQL row-level security enabled. Migrations revoke direct table access from Supabase `anon` and `authenticated` roles for application data. No RLS policies are ever created on these tables, so with RLS on and zero policies both browser roles are denied every row. The Next.js server accesses PostgreSQL through the private `DATABASE_URL`; browser code never connects directly to these tables, and no Supabase browser client exists in the codebase.

There are no foreign keys between any of these tables. Referential integrity is maintained in application code, and the only cross-table protections are the unique constraints and the CMS advisory lock. `scripts/audit-supabase.ts` re-checks RLS and the role revokes against a live database and is the intended drift detector.

Enums are `carrier_application_status`, `cms_content_status`, `cms_review_status`, and `cms_blog_status`. Check constraints exist on exactly three columns: testimonial rating 1-5, blog reading time 1-120, and media `source` membership.

### 9.1 CMS singletons

| Table | Responsibility |
| --- | --- |
| `cms_site_settings` | Company identity, contact data, logo, and SEO defaults |
| `cms_hero_content` | Hero copy, calls to action, authority visibility, and image arrays |
| `cms_section_copy` | Shared public labels, headings, calls to action, form copy, and blog copy |
| `cms_about_content` | About section copy, image, visibility, and years |
| `cms_contact_settings` | Contact heading, status, response time, consent/privacy copy, and visibility |
| `cms_agreement_document` | Current versioned agreement and structured sections |

Singleton rows use stable integer IDs and must be populated by the seed before the corresponding public/admin pages can render. Each is read with `id = 1`.

### 9.2 Ordered and publishable CMS content

| Table | Responsibility |
| --- | --- |
| `cms_navigation_links` | Public navigation links |
| `cms_social_links` | Social profiles and icons |
| `cms_hero_statistics` | Hero metrics |
| `cms_about_features` | About feature cards |
| `cms_services` | Service cards, structured detail pages, and optional per-record SEO overrides |
| `cms_truck_types` | Truck cards, detail data, freight, revenue, images, and optional per-record SEO overrides |
| `cms_pricing_items` | Pricing table rows |
| `cms_agreement_items` | Public agreement-summary rows |
| `cms_onboarding_steps` | How-it-works sequence |
| `cms_testimonials` | Public/admin reviews and moderation state |
| `cms_contact_cards` | Contact information cards |
| `cms_marquee_items` | Homepage marquee labels |
| `cms_blog_posts` | Markdown articles, publication state, tags, images, and optional per-record SEO overrides |

### 9.3 Operational and control data

| Table | Responsibility |
| --- | --- |
| `carrier_applications` | Public carrier leads, workflow status, SMS consent, and internal notes |
| `cms_media_assets` | Image URL, source, Cloudinary/storage identifiers, dimensions, and alt text |
| `cms_slug_redirects` | Previous-to-current service and truck slugs |
| `cms_agreement_revisions` | Immutable snapshots of replaced agreements |
| `admin_users` | Active admin allow-list keyed by Supabase user UUID |
| `admin_audit_records` | Authenticated mutation log |
| `public_rate_limits` | Atomic hashed request counters and window start times |

## 10. Source Layout

```text
app/
  layout.tsx                       Root metadata, fonts, global shell
  page.tsx                         Database-backed homepage entry
  services/[slug]/page.tsx         Dynamic service detail
  truck-types/[slug]/page.tsx      Dynamic truck-type detail
  blogs/                           Public blog index and article routes
  globals.css                      The only stylesheet
  api/
    carrier-applications/route.ts  Lead submission endpoint
    reviews/route.ts               Review submission endpoint
  admin/
    actions.ts                     Login/logout and lead actions
    login/page.tsx                 Public admin login route
    (dashboard)/                   Protected admin pages and CMS actions
      layout.tsx                   requireAdmin() gate, force-dynamic
      loading.tsx                  Route-group skeleton
      error.tsx                    Route-group error boundary
      cms-actions.ts               Singleton, collection, service, and truck actions
      blogs/actions.ts             Blog create/status/archive actions
      media/actions.ts             Upload, register, edit, and delete actions
      reviews/actions.ts           Review create/edit/status/bulk actions

src/
  components/
    HomePage.tsx                   Homepage client composition and UI state
    CmsProvider.tsx                Public content context and useCms()
    admin/                         Admin forms, editors, shell, and controls
    blog/                          Markdown article renderer
    layout/                        Nav, subpage nav/breadcrumb, top bar, footer
    sections/                      Homepage sections
    modals/                        Agreement modal
    ui/                            Marquee and toast
  data/                            Original content retained for seeding/types
  db/
    index.ts                       Lazy server-only Drizzle/PostgreSQL client
    schema.ts                      Tables, enums, checks, and TypeScript types
  hooks/
    useActiveSection.ts            IntersectionObserver section scroll-spy
  lib/
    admin-auth.ts                  Supabase claims plus admin allow-list
    blog-queries.ts                Published blog reads
    carrier-application.ts         Lead validation
    cloudinary.ts                  Server-only Cloudinary configuration
    navigation.ts                  Pure subpage anchor and active-nav helpers
    public-rate-limit.ts           Database-backed HMAC rate limiting
    server-error.ts                Sanitized server error logging
    submission-request.ts          Same-origin, size-capped body parsing
    cms/                           Queries, validators, media safety, image saves
    storage/                       Media validation, Cloudinary upload/removal
    supabase/                      SSR client, config check, cookie refresh
    *.test.ts                      Unit tests (carrier, CMS, navigation, proxy)

drizzle/                           Versioned SQL migrations and snapshots
scripts/                           Seed, verification, audit, and admin-grant tools
proxy.ts                           Supabase session refresh entry point
drizzle.config.ts                  Drizzle Kit config; throws without DATABASE_URL
```

There is exactly one React context (`CmsContext` in `CmsProvider.tsx`) and one custom hook in the codebase. `useCms()` throws rather than returning `null` when the provider is absent, so a section cannot silently render empty content. Navigation behavior is not a hook; it is two pure functions in `src/lib/navigation.ts` that rewrite same-page anchors to home routes on subpages and map a subpage path back to the nav link that should be highlighted.

`src/data/content.ts`, `src/data/agreement.ts`, and `src/data/section-copy.ts` are seed sources and shared type inputs. They are not the current production content store and should remain until the migration/seed dependency is intentionally removed.

## 11. Environment and Secret Boundaries

| Variable | Exposure | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | Server only | PostgreSQL connection and Drizzle commands |
| `NEXT_PUBLIC_SITE_URL` | Public | Canonical metadata base |
| `NEXT_PUBLIC_SUPABASE_URL` | Public | Supabase project URL for Auth |
| `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` | Public | Supabase publishable Auth key |
| `NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME` | Public | Cloudinary cloud identifier |
| `CLOUDINARY_API_KEY` | Server only | Authenticated Cloudinary operations |
| `CLOUDINARY_API_SECRET` | Server only | Cloudinary signing secret |
| `RATE_LIMIT_SECRET` | Server only | HMAC key for stored submission fingerprints |
| `TRUST_PROXY_HEADERS` | Server only | Whether to trust a proxy-provided client IP |

The `NEXT_PUBLIC_*` values are compiled for browser visibility by design. Database passwords, Cloudinary credentials, and rate-limit secrets must never be exposed to client components, logs, documentation, or commits.

## 12. Database Lifecycle and Operational Commands

```bash
npm run db:generate       # Generate a migration from the Drizzle schema
npm run db:migrate        # Apply committed migrations
npm run db:push           # Push the schema directly, without a migration file
npm run db:seed           # Idempotently seed original site content
npm run admin:grant -- admin@example.com

npm run typecheck
npm run lint
npm test
npm run build
```

Targeted verification commands:

```bash
npm run db:verify         # CMS singleton and content checks
npm run db:verify:blog    # Published blog checks
npm run db:verify:batch3  # Later content batch checks
npm run db:audit:supabase # Live RLS and role-revoke audit
npm run verify:cloudinary # Cloudinary configuration and object checks
```

Some of these accept `VERIFY_BASE_URL` when exercising a running deployment.

`npm test` runs four files through Node's built-in runner with `--experimental-strip-types`, so there is no test-framework dependency. The file list is written out explicitly in the `test` script rather than globbed, which means a newly added test file will not run until it is registered there.

The seed uses stable singleton IDs and unique entity keys. It may be run repeatedly and intentionally avoids overwriting later CMS edits.

## 13. Failure and Security Behavior

- Missing `DATABASE_URL` throws in two distinct places. `drizzle.config.ts` throws at config load, so every Drizzle Kit command fails immediately. `src/db/index.ts` is lazy and safe to import; it throws `DATABASE_URL is not configured.` on the first `getDb()` call instead, so the failure surfaces at request time on any page with a database read.
- Missing Supabase Auth configuration leaves public pages available but prevents admin authentication. The session-refresh proxy passes requests through untouched, and `requireAdmin()` redirects to a bare login page.
- Missing Cloudinary configuration throws `Cloudinary is not configured.` on the first upload or destroy, not at import, so ordinary CMS reads are unaffected.
- An unseeded CMS fails loudly. Each singleton read throws `CMS is not seeded: missing <section>. Run npm run db:seed.` rather than falling back to bundled content. Note that the hero and contact reads filter on `enabled = true`, so an administrator who disables either section sees this same "not seeded" message even though the row exists — a seeded deployment in that state serves a 500 on the homepage.
- Invalid public submissions return generic errors and never expose raw database exceptions. `logServerError()` records only the error `name` and `code`.
- Invalid numeric admin IDs and invalid public slugs result in 404 behavior. No custom `not-found.tsx` exists, so these render Next's built-in 404 page.
- Public forms use a hidden honeypot plus database-backed limits; these reduce automated abuse but do not replace upstream bot/WAF controls. Without `TRUST_PROXY_HEADERS=true` the source limit is a single global pool rather than a per-IP cap.
- RLS and revoked Supabase roles prevent browser-side table access, while admin authorization is rechecked in pages and actions.
- Public content is cached for up to five minutes. CMS mutations call `revalidatePath()` so affected route trees refresh on the next request without waiting for the interval. There is no tag-based or cross-request data cache.
- Existing `fa-*` CMS icon values are rendered by lightweight native-symbol CSS; the public layout does not load the external Font Awesome stylesheet or webfonts. Icon values outside the ~62 mapped classes fall back to a bullet glyph.

## 14. End-to-End Business Flows

### Content publishing

```text
Admin signs in
  -> protected CMS form
  -> validated server action
  -> transactional PostgreSQL write + audit record
  -> route revalidation
  -> next public request reads the new published content
```

### Lead management

```text
Visitor submits contact form
  -> validated and rate-limited API insert
  -> lead appears as new in /admin and /admin/leads
  -> admin records notes and moves it through statuses
  -> every admin change is audited
  -> lead can be archived with a soft delete
```

### Review moderation

```text
Public endpoint or admin creates review
  -> pending by default for public submissions
  -> admin edits/moderates and may feature it
  -> published reviews are selected for the homepage carousel
  -> rejected/archived reviews remain non-public
```

### Media-backed content

```text
Admin uploads image to Cloudinary
  -> asset metadata enters the media library
  -> CMS entity stores the selected public URL and alt text
  -> public server render supplies that image to the component
  -> deletion is blocked while the URL is referenced anywhere, drafts included
  -> replacing an image archives the old asset and destroys its Cloudinary object
```

---

This file is the architecture source of truth for the current repository. Update it whenever routes, tables, authentication boundaries, storage providers, or major content flows change.
