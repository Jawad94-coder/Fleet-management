import type { NextConfig } from "next";

const cloudName = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME;

const nextConfig: NextConfig = {
  redirects() {
    return [{
      source: "/:path*",
      has: [{ type: "host", value: "fleetmanagementus\\.com" }],
      destination: "https://www.fleetmanagementus.com/:path*",
      permanent: true,
    }];
  },
  images: {
    minimumCacheTTL: 2592000,
    remotePatterns: cloudName ? [{ protocol: "https", hostname: "res.cloudinary.com", pathname: `/${cloudName}/image/upload/**` }] : [],
  },
  headers() {
    return [
      {
        source: "/admin/:path*",
        headers: [{ key: "X-Robots-Tag", value: "noindex, nofollow" }],
      },
      {
        source: "/api/:path*",
        headers: [{ key: "X-Robots-Tag", value: "noindex, nofollow" }],
      },
      {
        source: "/images/:path*",
        headers: [
          {
            key: "Cache-Control",
            value: "public, max-age=2592000, stale-while-revalidate=86400",
          },
        ],
      },
    ];
  },
  experimental: {
    // 5 MB image plus multipart headers; image validation still enforces 5 MB.
    serverActions: { bodySizeLimit: "6mb" },
  },
};

export default nextConfig;
