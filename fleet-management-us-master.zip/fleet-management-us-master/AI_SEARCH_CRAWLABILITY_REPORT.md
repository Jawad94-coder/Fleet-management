# AI search crawlability and final release gate

Audit/retest date: **19 October 2026**. Scope: all indexable sitemap URLs, documented search/retrieval agents, the existing enquiry API, admin access, local production build and live Hostinger responses.

## Verdict

**Local implementation: PASS. Live production release gate: NOT CLEARED.**

The repository fixes are implemented and the configured CMS has been updated. The local production-build check covers **22 pages** with **2,410 passing assertions and zero failures**. These include repeated per-page, per-agent and per-link assertions, not 2,410 separate SEO features.

The latest live run at **10:01 UTC / 15:01 Pakistan time** found **22 sitemap pages, 2,284 passing assertions and 35 failures**. The failures represent a small set of repeated deployment issues listed below. All **176** simulated search/retrieval page requests passed. CMS text and new articles have reached the live site after revalidation; the source-level metadata, header, component and redirect changes still need deployment. No Hostinger deployment credentials or accessible hosting/WAF configuration were available, so no live configuration change or deployment is claimed.

Machine-readable evidence: `docs/seo-verification-summary.json`. Complete local logs remain in `.local/`, including `local-final.json`, `live-final.json`, `build.log`, `lint.log`, `typecheck.log`, `tests.log`, `cms-verification.log`, `blog-workflow.log` and `mobile-qa.json`.

## Actual findings and fixes

| Finding independently rechecked | Root cause / smallest implemented fix | Local result | Latest live result |
| --- | --- | --- | --- |
| Apex root, service and blog return 200 | No hostname redirect. Added one host-scoped permanent 308 in `next.config.ts`. | Three tested path/query combinations redirect once to www; destination 200. | All three still 200 without Location. Deploy app rule, or equivalent Hostinger rule if original Host is not forwarded. |
| Missing homepage/blog-index canonical | Page-level metadata omitted canonicals. Added shared canonical/social metadata helper and route metadata. | One correct self-canonical per page; www everywhere. | Both canonicals still absent. |
| Page-specific Twitter title missing | Root Twitter metadata inherited by child pages. Added route-specific Twitter metadata. | Page-specific Open Graph/Twitter on all 22 URLs. | Twitter remains the general company title on all 22 pages. |
| Blog listing has no JSON-LD | Listing lacked breadcrumb data. Added matching `BreadcrumbList`. | Valid JSON syntax and breadcrumb type. | Listing still has no JSON-LD. |
| Homepage unsupported local/history schema | Original page emitted `LocalBusiness` and founding year from template settings. Replaced with factual `Organization` and `WebSite`; omitted unverified contact/location/history schema. | No unsupported local/rating/history schema. | Older homepage schema still served. |
| Remaining navbar establishment badge | `Navbar.tsx` rendered `company.estYear` even after about-copy cleanup. Removed the unsupported badge after browser QA found it. | Absent in final source/build. | Older navbar still shows the template establishment claim. |
| Robots excludes admin subtree but not bare root | `/admin/` path prefix does not match `/admin`. Changed exclusion to `/admin`, kept wildcard/public access and API exclusion. | Bare root and subtree excluded for documented search crawlers. | Old robots still misses bare root, producing five repeated assertions. Auth still protects admin. |
| Administrative indexing defense incomplete | Added admin/API noindex response headers and protected-layout noindex metadata. | Public pages remain indexable; login/admin restrictions hold. | Existing login noindex and authentication pass; deploy response-header changes. |
| Contact/fee/history/template conflicts | Database-backed public copy used incompatible settings and seed promises. Applied compare-before-update CMS transaction and aligned seed source. | Clean public copy and consistent existing business contacts. | Current service text/new articles now visible; obsolete component output remains until deployment. |

The **35 latest live failures** comprise: 22 repeated social-metadata failures; 2 missing canonicals; 1 missing blog-listing JSON-LD; 1 homepage unverified-schema failure; 1 homepage old-template/badge failure; 5 robots-root exclusions; and 3 apex redirect failures. They are not evidence of 35 distinct root causes.

Earlier live observations had only 20 sitemap entries and stale CMS content. The latest gate rechecked the actual responses and found 22 entries after content revalidation. Historical results are retained in `.local/live-before.json`; they are not used as the latest verdict.

## Crawlers evaluated

Official provider documentation was fetched and read on 19 October 2026. The existing wildcard policy already allows public crawling; unnecessary explicit groups were not added.

| Agent | Purpose | Robots permission for public pages | HTTP test |
| --- | --- | --- | --- |
| Googlebot | Google Search, including AI Overviews/AI Mode eligibility | Allowed | Initial HTML retrieved locally and live |
| bingbot | Bing indexing, relevant to Bing/Copilot discovery | Allowed | Initial HTML retrieved locally and live |
| OAI-SearchBot | ChatGPT search discovery | Allowed | Initial HTML retrieved locally and live |
| PerplexityBot | Perplexity search discovery | Allowed | Initial HTML retrieved locally and live |
| Claude-SearchBot | Claude search indexing | Allowed | Initial HTML retrieved locally and live |
| ChatGPT-User | User-triggered retrieval; separate from search indexing | Wildcard permits access; provider says robots may not apply to these actions | Initial HTML retrieved locally and live |
| Perplexity-User | User-triggered retrieval | Wildcard permits access; provider notes different robots handling | Initial HTML retrieved locally and live |
| Claude-User | User-triggered retrieval | Wildcard permits access | Initial HTML retrieved locally and live |
| GPTBot | OpenAI model-development/training crawler | Existing wildcard permission retained | Policy evaluated; not needed for ChatGPT Search eligibility |
| ClaudeBot | Anthropic model-development crawler | Existing wildcard permission retained | Policy evaluated; not a search-visibility prerequisite |

Search and training preferences were kept separate conceptually and no new training preference was imposed. No provider IP ranges were guessed or hardcoded. Requests used simulated agent strings; they show server behavior from this test connection, **not** genuine provider traffic, verified IP identity, visits, indexing, ranking or citations.

No authentication, WAF, CAPTCHA or other security protection was disabled. Hostinger/CDN/WAF configuration and real access logs were inaccessible. To investigate real crawler failures, use current provider verification data and logs; never trust the agent name alone.

References: [OpenAI crawlers](https://developers.openai.com/api/docs/bots), [Perplexity crawlers](https://docs.perplexity.ai/docs/resources/perplexity-crawlers), [Anthropic crawlers](https://support.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler), [Google AI features](https://developers.google.com/search/docs/appearance/ai-features).

## HTTP and HTML evidence

The verifier inspects the response body without running page JavaScript. Every sitemap URL is fetched, rather than inferred from source filenames.

| Coverage | Local production result | Live result |
| --- | --- | --- |
| Homepage, blog index, 7 services, 9 truck types, 4 articles | All 22 return 200 HTML | All 22 return 200 HTML |
| `/robots.txt`, `/sitemap.xml` | 200 with expected text/XML content types | 200 with expected content types |
| Five search agents plus three retrieval agents on every page | 176/176 response/content checks pass | 176/176 pass |
| Essential main text | Present in initial response, one H1 each | Present in initial response, one H1 each |
| Public meta robots / X-Robots-Tag | No noindex/nosnippet blocking public pages | No such blocking detected |
| Unknown URL / unpublished Lahore landing page | 404 / 404, draft excluded from sitemap | 404 / 404 |
| Unauthenticated `/admin` | Redirects to login | Redirects to login |
| Incomplete enquiry POST `{}` | 400; no carrier lead inserted | 400; no carrier lead inserted |
| Internal route/fragment discovery | All tested targets and cross-page inbound links pass | Current live discovery checks pass |

For example, the local dispatch page returns **3,578 characters** of extracted main text and **13 H2/H3 headings**; the Lahore buyer guide returns **5,139 characters** and **9 H2/H3 headings**. The homepage answer section is included in returned HTML despite being composed inside the interactive homepage shell. No login, cookie acceptance, hidden-tab interaction or client API request is required for that content.

The local homepage canonical may be serialized by Next.js as `https://www.fleetmanagementus.com` while the sitemap uses the root slash. Those are the same root URL after standard URL normalization. Different hosts, paths or query strings are not treated as equivalent by the verifier.

For local hostname tests, Node's `http.request` is used because Node fetch ignored a supplied Host header during QA. The checker now exercises the actual Next.js redirect with `Host: fleetmanagementus.com`, and tests query preservation plus a single 200 destination. This corrected a test-harness false failure, rather than weakening the redirect requirement.

## Semantic content and entity clarity

- US carrier/owner-operator positioning remains the homepage's commercial focus.
- All seven service pages explain their role, users, workflow/questions, limitations and next steps. Dispatch, load research, rate discussions, broker communication, paperwork, fee structures and carrier approval are described without a fabricated operating location, rate guarantee or performance result.
- The informational Lahore comparison guide explains criteria for choosing providers and distinguishes jobs/training from carrier services. It does not rank Fleet Management US or claim a Lahore office.
- The local commercial landing page is **unpublished** pending the owner's details. Its full content/metadata review draft is in `docs/truck-dispatch-services-lahore.draft.md`.
- Contact values are consistent with existing editor-updated public cards. They are not claimed to have been independently verified by a call/email. The existing US address remains a business-supplied value awaiting confirmation and is omitted from schema.
- Seed reviews are pending moderation; no review/rating schema was created. Experience, volume, rate and deadline claims lacking evidence were removed from public presentation.
- Homepage Q&A, contextual service/equipment links and the two new guides use ordinary HTML anchors. Existing blog and equipment URLs remain discoverable.

## Structured data

Local returned HTML contains `Organization`, `WebSite`, `Service`, `BreadcrumbList` and `BlogPosting` as appropriate. Organization IDs and page IDs consistently use the preferred www origin. The existing JSON serializer escapes `<` to preserve script safety. Business attribution is typed as `Organization`, and no fictional personal author is supplied.

All local JSON-LD parses successfully. The verifier also rejects the unverified local/rating/founding-date types/properties removed in this implementation. It does **not** claim to implement the entire Schema.org vocabulary or Google's eligibility validator.

The Google Rich Results Test was attempted for the live dispatch page. The UI reported **“Could not connect to the reCAPTCHA service.”** No CAPTCHA was solved or bypassed, and there is no successful Google validation result to report. Repeat this test after deployment. A Service schema object does not itself imply a Google rich-result feature, and FAQ markup was not used as a rich-result or AI-ranking promise.

No `llms.txt`, speculative AI schema or AI SEO package was added. Google's official guidance states that normal search eligibility and helpful, accessible content remain relevant for its AI features.

## Mobile and functional QA

Connected Chrome was used with explicit narrow viewports. The homepage was visually inspected at **390×844** and **320×740**. At 320 pixels, the 12 additional pages recorded in `.local/mobile-qa.json` each had one main H1, a fitting H1, document width equal to client width and no completed image with zero natural width. Those pages include all seven services, box-truck detail, blog index, both new guides and the existing empty-mile article. This is representative browser QA in addition to the viewport/lang checks on all 22 HTTP responses.

Evidence image: `docs/seo-mobile-qa.png` (existing empty-mile article). Mobile menu open/close and agreement modal open/close were exercised. The modal's print/copy/enquiry controls remained rendered; actual printing, clipboard export and a successful customer submission were not used as production tests. The existing submission and validation tests pass, and an incomplete HTTP request correctly returns 400.

The browser tool later stalled during evidence export/reconnection; the screenshot and geometry log had already been saved. No additional browser check from the stalled call is counted as completed. The later viewport reset attempt reported that the debugger was detached; no persistent browser setting change is claimed.

PageSpeed's public API returned **429 quota exceeded**. Core Web Vitals and performance gains are therefore **not measured** in this delivery. Use Search Console field data and a successful mobile Lighthouse/PageSpeed run after deployment. Responsive markup and a local screenshot are not a substitute for field performance measurement.

## Tests and repeatable gate

| Check | Result |
| --- | --- |
| `npm run lint` | Pass |
| `npm run typecheck` | Pass |
| `npm test` | 15 tests pass, including metadata, breadcrumb/description, robots grouping and HTML/JSON-LD parsing checks |
| `npm run build` | Production webpack build passes; 29 generated routes include public pages, metadata and application routes |
| `npm run db:verify` | 8 CMS checks pass, including preserved route identity/order and seeded reviews held for verification |
| `npm run db:verify:blog` with HTTP fixture mode disabled | Transaction-only draft/publish/edit/archive/duplicate-slug workflow passes and rolls back |
| CMS update repeated dry run | 0 updates; no duplicates |
| CMS restore dry run | All 44 updates / 2 new articles checked; no restore applied |
| Local HTTP gate | 22 pages; 2,410 pass / 0 fail |
| Live HTTP gate | 22 pages; 2,284 pass / 35 fail pending source deployment |

No publicly committed verification testimonials or dummy carrier lead submissions were used. The optional older HTTP fixture scripts that publish temporary content were not run.

```powershell
npm run build
npm run start -- --hostname 127.0.0.1 --port 3100
npm run seo:verify -- --base=http://127.0.0.1:3100 --output=.local/local-final.json
npm run seo:verify -- --base=https://www.fleetmanagementus.com --output=.local/live-final.json
```

`scripts/verify-ai-search-readiness.mjs` exits nonzero if its gate fails. Its tests cover robots specificity, merged groups, empty directives, wildcard/terminal paths, Allow ties, HTML attribute order, hydration-script exclusion, malformed JSON-LD and root-URL/query normalization. No additional dependency was installed.

## Deployment actions still required

1. Deploy the checked repository source to the Hostinger Node.js application. Preserve the configured database/auth/media environment. The CMS content update is already applied to the configured database; do not reseed or reset it.
2. Confirm that the original Host reaches Next.js. If not, implement the same permanent apex→www redirect at Hostinger's domain layer, preserving path/query. Do not add a conflicting www→apex redirect or unnecessary chain.
3. Clear/revalidate the relevant hosting cache after deployment and rerun the **live** verification command. Clearance requires zero live failures, not merely a local pass.
4. Repeat Google Rich Results Test and Search Console URL Inspection. Check Google's selected canonicals and submit the www sitemap. No Search Console/Bing account result is asserted without access.
5. Review genuine provider traffic in logs using current official verification guidance. Only adjust WAF rules if verified traffic is blocked; agent-string-only requests cannot establish that.
6. Supply and approve Lahore operational details, business identity/address, authority/insurance records, current fees, real coverage hours and evidence for trust claims before publishing them.

The full keyword mapping, content changes, file inventory, rollback instructions and 30-day measurement plan are in `SEO_AEO_IMPLEMENTATION_REPORT.md`. No instant ranking, indexing or AI-citation guarantee is made.
