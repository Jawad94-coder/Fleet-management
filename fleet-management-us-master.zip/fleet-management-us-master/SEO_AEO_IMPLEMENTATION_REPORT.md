# SEO, AEO and GEO implementation

Date: 19 October 2026. Repository: `E:\fleet-management-us`. Preferred origin: `https://www.fleetmanagementus.com`.

## Delivery status

Implementation covers the original SEO request, the supplied AI crawlability task and the final verification gate. Source changes require a Hostinger deployment. CMS content was updated separately through a guarded transaction; see the content and rollback section. This report does not equate a local build with a deployed release, or crawl permission with indexing or AI citations.

The owner will provide business details later. The Lahore commercial landing page remains a complete review draft in `docs/truck-dispatch-services-lahore.draft.md`; there is no public route or sitemap entry for it. The informational Lahore buyer guide does not claim a Fleet Management US office in Lahore.

## Original problems verified

- Next.js **16.3.6**, React 19.2.8, App Router, TypeScript, Tailwind and PostgreSQL/Drizzle CMS. Public routes use server data and 300-second revalidation. Admin authentication uses Supabase. The installed Next.js metadata, server/client and redirect guides were read before implementation.
- Live non-www root, service and blog paths returned **200**, with no permanent redirect. Both hostnames could serve the same content.
- Homepage and blog listing had no self-referencing canonical. Many detail pages had correct canonicals already; these were retained.
- Twitter metadata inherited the general company title instead of the page-specific title. The blog listing title could repeat the brand. Metadata origin could drift with a deployment environment variable.
- Homepage schema included `LocalBusiness`, a seed address and a founding year without evidence sufficient for those entity claims. A business author was marked as a `Person` in article schema.
- CMS settings showed `(888) 555-0142`, while the editor-updated contact card showed `(929) 622 7250`. The email card displayed `hadi@fleetmanagementus.com` but linked to `dispatch@fleetmanagementus.com`.
- Company/about copy conflicted: Brooklyn contact address, Chicago establishment badge, 2014 founding claim, and different experience counts. No Lahore evidence was present in the repository or audited public CMS.
- Published general fees differed from service-specific percentages. Copy also promised funding, dispatch, response and onboarding deadlines, and presented weekly gross targets without supporting records.
- Public cards contained edit indicators and template instructions. Six published testimonials originated from the seed and had no supplied authenticity evidence.
- Several service pages had very little explanatory content. Related links existed but were limited to the first four other records rather than contextual next steps.
- Blog architecture was functional and contained two substantive articles. Their bodies lacked relevant commercial links. Sitemap article `lastmod` used publication rather than modification time.
- The homepage uses a client component for navigation, modals and forms, but its content **was already prerendered in the HTTP response**. This was not treated as a client-rendering defect. New answer content is supplied as server-rendered children.
- Existing images already used `next/image`, local WebP files, dimensions/reserved containers, and a narrow Cloudinary allowlist. The older `docs/seo-audit-report.md` described earlier code and was not treated as current evidence.
- Wildcard robots permitted the documented search crawlers. `/admin/` was excluded, but bare `/admin` was not. Robots exclusions were never treated as authentication.

## Changes implemented

### Metadata, redirects and indexing

- Centralized the production origin in `src/lib/seo.ts`. Added a small shared page-metadata helper for canonical, Open Graph and Twitter consistency. Existing CMS title/description editing remains functional.
- Added a hostname-scoped permanent **308** redirect in `next.config.ts`. It maps only the apex hostname to www, preserving path and query. Localhost and www do not match the rule.
- Added unique homepage and blog-index canonicals; retained service, equipment and article canonicals. Each public page has its own title, description and social title/URL.
- Preserved the wildcard robots policy and sitemap reference, expanded the admin exclusion to include the root, and added admin/API `X-Robots-Tag: noindex, nofollow`. Protected dashboard metadata also uses noindex. Authentication and API validation remain intact.
- Retained all seven service URLs, nine equipment URLs, both existing blog articles and the blog index. Two new article URLs bring the intended sitemap to **22** pages. Article `lastmod` now uses the CMS update timestamp. No invented current-time `lastmod` is assigned where an authoritative page update timestamp is unavailable.

### Helpful content and conversion

- Reworked all seven service records with distinct titles, descriptions, answer-first introductions, scope, buyer questions, eligibility/limitations and relevant next steps. MC lease-on copy no longer represents an MC number as rentable authority or a truck VIN as changeable.
- Replaced unsupported fees and revenue/response promises with requests for written terms. Pricing models are explained without publishing an invented company rate.
- Homepage H1 now describes dispatch for US owner-operators. The existing dark/orange visual system, navigation, hero slideshow, equipment cards, modal, animations, contact form, review administration and backend are retained. Longer headings receive appropriate line height and sizing.
- Added a server-rendered dispatch Q&A section with contextual service/article links. Removed public edit badges and template instructions.
- Unified phone and email using the **existing editor-updated public contact cards**. This is evidence of the business's supplied values, not proof of telephone delivery or inbox operation. Both remain subject to owner confirmation.
- Removed unsupported history/volume badges, weekly revenue targets and authority badges from public display. Seeded reviews were moved to **pending**, not deleted; the carousel and review workflow remain available for verified content.
- Replaced the unapproved public agreement sample's fixed legal/payment claims with an agreement discussion checklist. The modal, print, copy-link and enquiry controls remain. This does not amend any executed customer agreement or constitute legal approval.

### Blog work

Published through the existing CMS and `/blogs/[slug]` renderer:

1. `/blogs/choose-truck-dispatch-company-lahore`: objective buying criteria, mixed search intent, remote working questions, approval rights, fees and document security. Explicitly states it establishes no Fleet Management US Lahore office or provider ranking.
2. `/blogs/owner-operator-dispatch-pricing-responsibilities`: percentage/weekly/per-load structures, fee bases, inclusions, carrier responsibilities, broker questions and onboarding checklist.
3. Improved existing `/blogs/reduce-empty-miles-with-dispatch-planning`: direct opening answer, consistent empty-mile/total-mile calculations, actual-record measurement and service links. Retained its established URL and useful existing content.

Also linked the existing fleet checklist to dispatch, back-office and onboarding services. No personal author was invented. Existing business attribution uses `Organization`; new articles omit unknown author identity while identifying the business as publisher.

## Keyword evidence and search intent

All phrases below are **research candidates**, not verified high-volume keywords. No volume, difficulty, CPC, ranking, popularity or trend percentage is asserted.

Research on 19 October 2026 included a direct Google browser search for `truck dispatch services Lahore` and supplemental web research for Lahore/Pakistan dispatch providers. The Google view identified Lahore and stated that results were personalized; it is a qualitative sample, not a neutral ranking benchmark. It mixed training-oriented Places listings, recruiting pages, freelance hiring and commercial services. Suggestions included salary and jobs themes as well as price. This supports an intent distinction; it does not quantify market demand.

Primary competitor-page observations:

- [We Dispatch Logics about page](https://wedispatchlogics.pk/about/): its own copy discusses a Lahore team serving US carriers, while the Google result emphasizes recruiting. This illustrates mixed employment/commercial intent; its business claims were not independently validated or transferred to this site.
- [Starco Logistics service page](https://www.starcologistics.com.pk/our-services/): trucking dispatch appears alongside broad domestic logistics/courier offerings. A result mentioning dispatch is not automatically a comparable US-carrier specialist.
- PSP Dispatch appeared in the observed Google results, but its website could not be fetched with the research tool. No verified competitive performance claim is made.
- [Track N Truck](https://www.trackntruck.us/) appeared in supplemental research with US-carrier positioning and Pakistan location content. This is a research lead, not a recommendation or validated ranking.

Google Trends could not be retrieved through the research tool. No Keyword Planner or Search Console dataset/account access was supplied. Consequently, **all supplied local, national, US-commercial and long-tail candidates remain unvalidated quantitatively**. Search-result presence is not search volume.

### Page mapping — one primary topic per page

| Page | Primary keyword candidate | Supporting topics / intent |
| --- | --- | --- |
| `/` | truck dispatch services USA | US owner-operator/fleet service discovery; brand overview |
| `/services/dispatch-services` | independent truck dispatch services | owner-operators, broker communication, rate discussions, dispatch scope |
| `/services/mc-leasing` | MC lease-on support | operating carrier verification, written deductions, eligibility |
| `/services/load-assistance` | truck load booking assistance | freight research, backhauls, equipment fit, total-mile planning |
| `/services/factoring-support` | freight factoring paperwork support | invoice/POD submission, provider coordination; no credit guarantee |
| `/services/insurance-support` | trucking insurance coordination support | certificates, coverage questions, renewal records; no binding claim |
| `/services/back-office-support` | trucking back-office support | document organization, settlements, administrative scope |
| `/services/carrier-setup-assistance` | carrier onboarding assistance | carrier packets, registration questions, broker requirements |
| `/truck-types/box-truck` | box truck dispatch services | dimensions, payload, liftgate and regional freight |
| `/truck-types/dry-van` | dry van dispatch services | enclosed non-temperature-controlled freight |
| `/truck-types/reefer` | reefer dispatch services | temperature requirements, appointments, washouts |
| `/truck-types/flatbed` | flatbed dispatch services | securement, dimensions, tarping |
| `/truck-types/hotshot` | hotshot dispatch services | capacity, ratings, urgent smaller freight |
| Other existing equipment URLs | equipment-specific dispatch support | retain semi-truck, straight-truck, step-deck and other configurations |
| `/blogs` | truck dispatch guides | informational discovery |
| Lahore buying guide | how to choose a truck dispatch company in Lahore | comparative criteria, remote arrangements; no city-office claim |
| Owner-operator pricing guide | owner-operator dispatch pricing | percentage/flat/per-load structures and questions |
| Existing empty-mile article | reduce empty miles with dispatch planning | trip economics, measurement and return planning |
| Existing fleet checklist | fleet management checklist | operational records, maintenance and administration |
| Lahore landing page — **unpublished** | truck dispatch services Lahore | verified local commercial operation, only after facts supplied |

Homepage and dispatch detail intentionally serve different levels of the buying journey: broad service discovery versus independent dispatch scope. Monitor actual query/URL overlap before splitting or consolidating further.

### Lahore candidates

| Candidate | Intended intent / destination |
| --- | --- |
| best truck dispatch company in Lahore | comparative buyer research; objective buying guide, no self-awarded ranking |
| truck dispatch company in Lahore | local commercial discovery; draft landing page after verification |
| truck dispatch services Lahore | local commercial service; draft page's primary topic |
| best dispatch company in Lahore | ambiguous comparative; qualify US trucking, exclude taxi/courier/training |
| truck dispatching company Lahore | mixed commercial/employment; qualify carrier support |
| USA truck dispatch company in Lahore | local operation serving US carriers; draft after verification |
| freight dispatch services Lahore | ambiguous freight market; explain US-carrier context |
| trucking dispatch services Lahore | commercial/local candidate; check jobs contamination |
| professional truck dispatchers Lahore | provider comparison or hiring; assess actual lead intent |
| truck dispatch agency Lahore | local provider discovery; verify the operating relationship |

Pakistan candidates: `truck dispatch company Pakistan`, `US truck dispatch services Pakistan`, `best truck dispatch company in Pakistan`, `freight dispatch company Pakistan`, `trucking dispatch services Pakistan`, `remote truck dispatch services Pakistan`, `US logistics dispatch company Pakistan`, `truck dispatch outsourcing Pakistan`. Treat these as national commercial/outsourcing or comparative candidates; use the buyer guide and, only after verification, the Lahore page's remote-operations explanation. Do not create a thin Pakistan near-duplicate page. Exclude jobs, salaries, courses, vacancies, training, taxi dispatch and domestic courier intent from commercial lead reporting.

US candidates: homepage/dispatch pages cover owner-operator and independent-dispatch themes; equipment pages cover box truck, dry van, reefer, flatbed and hotshot; load assistance covers booking; the pricing article covers rates/cost structures; back-office covers administrative support. “Best truck dispatch service for owner operators” is comparative intent, not permission to claim superiority.

Long-tail answers are distributed by topic: choosing a Lahore provider and remote Pakistan support → Lahore buyer guide; dispatcher role, broker distinction and documents → dispatch/onboarding; cost → pricing guide; finding loads → load assistance; empty miles → retained planning article; box-truck suitability → equipment page and dispatch links. Do not duplicate the same answer across multiple location pages.

## Homepage and Lahore metadata

Homepage title: **Truck Dispatch Services for US Carriers | Fleet Management US**.

Homepage description: **Truck dispatch support for US owner-operators and fleets. Explore load planning, broker communication, carrier onboarding and back-office services.**

Homepage H1: **Professional Truck Dispatch Services for US Owner-Operators**. CMS SEO settings remain editable.

The Lahore draft contains the proposed title, description and H1 from the request, eight purchase-objection FAQs, service/equipment links, process, remote-operation review notes and the working `/#contact` path. Its metadata is **not emitted publicly**. No verified local operating statement has been added to the homepage.

## Structured data and discovery

- Homepage: `Organization`, `WebSite`, `BreadcrumbList`; stable organization/website IDs under the www origin. Omitted unsupported legal name, founding date, address and contact schema claims.
- Seven services and nine equipment pages: retained `Service` and `BreadcrumbList`, aligned descriptions with rendered CMS content and canonical URLs.
- Blog listing: added `BreadcrumbList`.
- Articles: retained `BlogPosting` and breadcrumbs; corrected organization author typing, omitted unknown personal attribution, preserved actual publication/update dates.
- JSON-LD serializer retains its `<` escaping. No `LocalBusiness`, fake reviews/aggregate rating, invented hours, geographic metadata, unsupported AI schema, `llms.txt` or FAQ rich-result claim was added.
- Added ordinary crawlable links among homepage answers, dispatch, onboarding, load assistance, back-office, equipment and educational articles. The unverified location page has no public links.

## CMS application and rollback

`npm run seo:content` is a dry run by default. `npm run seo:content -- --apply` applied **44** guarded updates and inserted **2** articles against the configured CMS. Every field had to match the captured audit baseline or its already-updated value; conflicts cause a transaction rollback. No lead, account, private document or credential table was selected or modified.

Backup: `.local/seo-content-backup-1792377196716.json`. A subsequent content dry run reported **0** changes, demonstrating idempotency for the audited state. A rollback dry run successfully checked all 44 updates and both inserted articles. Actual rollback was not performed.

```powershell
node scripts/restore-seo-content.mjs --backup=.local/seo-content-backup-1792377196716.json
# Add --apply only to restore the old public copy and move new articles to draft.
```

Rollback refuses to overwrite later editorial changes. Seeded reviews remain recoverable in moderation. The checked-in baseline contains the selected public CMS copy only; `.local` backups and QA artifacts are ignored by Git. Existing database-backed pages may reflect content updates after revalidation even before the source deployment; metadata/redirect/component fixes require the new build.

## Validation and remaining release gate

See `AI_SEARCH_CRAWLABILITY_REPORT.md` and `docs/seo-verification-summary.json` for final run counts, route-level evidence and deployment differences. Commands:

```powershell
npm run lint
npm run typecheck
npm test
npm run build
npm run start -- --hostname 127.0.0.1 --port 3100
npm run seo:verify -- --base=http://127.0.0.1:3100 --output=.local/local-final.json
npm run seo:verify -- --base=https://www.fleetmanagementus.com --output=.local/live-final.json
```

The HTTP checker inspects every sitemap entry, initial HTML, one H1, unique metadata, canonicals, JSON syntax, mobile viewport signals, eight simulated search/retrieval agents, robots access, discovery links, anchors, host redirects/query preservation, admin restrictions, 404s and invalid enquiry submission. Simulated user agents are not verified provider traffic. No genuine customer lead was submitted as a test.

PageSpeed's public API returned **429 quota exceeded**. No Core Web Vitals score or measured improvement is claimed. Existing hero image is 1600×900 WebP, about 46 KiB; the largest local equipment asset is the hotshot WebP, about 506 KiB, delivered through the existing responsive optimizer. Hero slideshow effects, fixed noise layer, external images that bypass optimization, font loading and long pages remain performance considerations to measure with field data. Google's Rich Results Test UI failed to connect to reCAPTCHA; no successful Google validation is claimed.

## Business facts still requiring confirmation

1. Lahore team/office existence, actual location and whether visits are accepted; relationship between Pakistani operations, US contracting entity and carrier customers.
2. Approved US legal identity/address, founding date and experience statements. The existing Brooklyn contact address is retained as supplied, but has not been independently validated. The obsolete Chicago establishment badge was removed.
3. Working phone and email ownership/deliverability. Unified existing values are `(929) 622 7250` and `hadi@fleetmanagementus.com`; no phone call or test email was sent.
4. Current operating carrier/authority and USDOT/MC details, lease availability, insurance obligations and qualified review of dispatch-versus-broker activities. No claim that the retained admin identifiers have been validated.
5. Real fees, fee bases, deductions, termination terms, provider relationships, service coverage, working hours and escalation arrangements.
6. Documentary support and publication consent for testimonials, customer/truck/load counts, outcome claims, guarantees or awards before republishing any of them.
7. Appropriate legal/privacy terms for form/SMS consent. Existing submission logic and consent choice were preserved; no legal compliance certification is offered.

## External account and Hostinger actions

- Deploy the checked source to the Hostinger Node.js application with the existing environment and production build/start commands. There is no verified Hostinger deployment/WAF configuration or deployment credential in this workspace; no hosting setting was changed.
- Ensure Hostinger forwards the original hostname to Next.js. If its proxy normalizes Host before the app, implement the same apex→www 301/308 at the domain layer, retaining path/query. Remove conflicting rules and rerun the live gate; do not create www→apex or multi-hop redirects.
- Inspect genuine crawler requests in access/CDN logs using the providers' current verification guidance. Do not allowlist solely by user-agent or disable WAF/authentication.
- Obtain Search Console, Bing Webmaster Tools, analytics and Keyword Planner access/export as needed. No account configuration, disavow, bulk URL submission or Business Profile creation was performed.
- After a successful deployment, rerun live HTTP checks and Google Rich Results Test, and use URL Inspection on representative homepage/service/equipment/article pages. Schema syntax checks do not establish Google rich-result eligibility.

## Search Console submission

1. Use the verified domain property for `fleetmanagementus.com` (or verify DNS with the property owner). Review existing properties before adding another.
2. After the live host redirect passes, submit `https://www.fleetmanagementus.com/sitemap.xml` under Sitemaps.
3. Inspect the www homepage, dispatch page, one equipment page and both new guides. Compare user-declared and Google-selected canonicals; request indexing for these key URLs where appropriate.
4. Review Page indexing, Crawl stats, Manual actions, Security issues and Core Web Vitals. A submitted sitemap does not guarantee indexing.
5. Publish/submit the Lahore landing page only after factual review, mobile QA, contextual links and its sitemap entry are complete.

## Realistic 30-day measurement plan

| Period | Work and evidence |
| --- | --- |
| Days 1–3 after deployment | Save release date and HTTP gate results. Export a comparable prior 28-day Search Console baseline by query, page, country and device. Record indexed pages and current canonical selection. Verify analytics consent and existing enquiry reporting. |
| Days 4–7 | Check discovery/indexing of the 22 intended URLs, sitemap processing, 404s and redirects. Review server errors and genuine crawler logs. Recheck the contact workflow without generating fake leads. |
| Days 8–14 | Compare impressions/clicks for commercial US queries versus Lahore/Pakistan buyer queries. Separate employment/training terms. Record query/URL overlap, device differences and enquiry quality; do not treat isolated position changes as a trend. |
| Days 15–21 | Improve an underperforming page only from actual query/lead evidence. Obtain the pending business facts. Validate the local page before deciding to publish; avoid city-page duplication. |
| Days 22–30 | Compare equivalent periods and annotate deployment/indexing lag. Report relevant impressions, organic clicks, query-level position changes, indexed pages, organic enquiry submissions and qualified owner-operator leads. Review US visibility independently from Pakistan/Lahore visibility. |

Use CRM/admin qualification alongside analytics attribution to distinguish a submitted form from a qualified carrier lead. Configure a successful-submission event only with an approved analytics/consent setup; none was invented here. Search Console's Web performance includes Google's AI-feature traffic and does not supply a guaranteed standalone AI-citation metric. Track independently observed referral/citation evidence without treating simulated crawls as visibility.

## Files changed or created

- Metadata/routing: `src/lib/seo.ts`, `app/layout.tsx`, `app/page.tsx`, `app/robots.ts`, `app/sitemap.ts`, `next.config.ts`, `app/admin/(dashboard)/layout.tsx`.
- Public routes: `app/services/[slug]/page.tsx`, `app/truck-types/[slug]/page.tsx`, `app/blogs/page.tsx`, `app/blogs/[slug]/page.tsx`; article timestamp query in `src/lib/blog-queries.ts`.
- Components: `src/components/HomePage.tsx`, `src/components/sections/DispatchAnswers.tsx`, `Hero.tsx`, `Contact.tsx`, `TruckTypes.tsx`, `AgreementPricing.tsx`, `src/components/layout/Footer.tsx`, `src/components/layout/Navbar.tsx`, `src/components/modals/AgreementModal.tsx`.
- Content: `src/data/content.ts`, `src/data/service-copy.ts`, `src/data/seo-articles.ts`, `src/data/section-copy.ts`, `src/data/agreement.ts`, `scripts/seed-cms.ts`.
- Migration/QA: `scripts/seo-content-baseline.json`, `scripts/update-seo-content.ts`, `scripts/restore-seo-content.mjs`, `scripts/verify-ai-search-readiness.mjs`, its test, `scripts/verify-cms.ts`, `src/lib/seo.test.ts`, `package.json`, `.gitignore`.
- Delivery: this report, `AI_SEARCH_CRAWLABILITY_REPORT.md`, `docs/seo-verification-summary.json`, `docs/seo-mobile-qa.png`, `docs/truck-dispatch-services-lahore.draft.md`, and README verification instructions.

## Official guidance used

- [Google SEO starter guide](https://developers.google.com/search/docs/fundamentals/seo-starter-guide)
- [Google AI features and websites](https://developers.google.com/search/docs/appearance/ai-features)
- [Google structured-data introduction](https://developers.google.com/search/docs/appearance/structured-data/intro-structured-data)
- [Google canonical consolidation](https://developers.google.com/search/docs/crawling-indexing/consolidate-duplicate-urls)
- [Google sitemap overview](https://developers.google.com/search/docs/crawling-indexing/sitemaps/overview)
- [OpenAI crawler documentation](https://developers.openai.com/api/docs/bots)
- [Perplexity crawler documentation](https://docs.perplexity.ai/docs/resources/perplexity-crawlers)
- [Anthropic crawler documentation](https://support.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler)
- [FMCSA broker/bona fide agent guidance announcement](https://www.fmcsa.dot.gov/newsroom/fmcsa-issues-final-guidance-clarifying-broker-and-bona-fide-agents-definitions) and [registration resources](https://www.fmcsa.dot.gov/registration)

No ranking, first-position, indexing, revenue, Core Web Vitals or AI-answer inclusion guarantee is made.
